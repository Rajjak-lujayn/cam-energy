(function($){
    "use strict";

 	ShowTabsLayoutOptions($('.rmszi-tabs-layout'));

    $('.rmszi-table-style').on('change', '.rmszi-tabs-layout', function() {
    	ShowTabsLayoutOptions($(this));
    });

    function ShowTabsLayoutOptions(elem) {
    	var layout = elem.val();

        $('.rmszi-tab-style').hide();  
        
        if (layout == 'tabs-arrow-alt') {       	
        	$('.rmszi-tab-arrow-alt-style').show();
        } else if (layout == 'tabs-progress-bar') {      	
        	$('.rmszi-tab-progress-bar-style').show(); 
		} else if (layout == 'tabs-outline') {      	
        	$('.rmszi-tab-outline-style').show();
        } else {	
        	$('.rmszi-tab-default-style').show();
        }
        
    }

})(jQuery);

function rmsziHideReviewRequestNotice(elem){
	var wrapper = jQuery(elem).closest('div.thpladmin-notice');
	var nonce = wrapper.data("nonce");
	var data = {
		rmszi_security_review_notice: nonce,
		action: 'skip_rmszi_review_request_notice',
	};
	jQuery.post( ajaxurl, data, function() {

	});
	jQuery(wrapper).hide(50);
};

jQuery( document ).on( 'click', '.thpladmin-notice .notice-dismiss', function($) {
	var wrapper = $(this).closest('div.thpladmin-notice');
	var nonce = wrapper.data("nonce");
	var action = wrapper.data("action");
	var data = {
		rmszi_security_review_notice: nonce,
		action: action,
	};
	$.post( ajaxurl, data, function() {

	});
})

jQuery(document).ready(function($){
	setTimeout(function(){
	   $("#rmszi_review_request_notice").fadeIn(500);
	}, 2000);
 });