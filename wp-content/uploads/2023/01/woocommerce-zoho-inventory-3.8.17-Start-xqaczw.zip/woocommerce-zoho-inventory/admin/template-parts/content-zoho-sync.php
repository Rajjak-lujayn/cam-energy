<?php
/**
 * This file for ZOHO inventory connect.
 *
 * @package     WooZo Inventory
 * @category    Zoho configuration
 * @author      Roadmap Studios
 * @link        https://roadmapstudios.com
 */

// WordPress Database Object.
global $wpdb;

// zoho organisation Id.
$zoho_inventory_oid = get_option('zoho_inventory_oid');
// Zoho inventory URL.
$zoho_inventory_url = get_option('zoho_inventory_url');
$zoho_sync_status = get_option('zoho_sync_status');

// Zoho stock sync status to enable or disable stock sync.
$zi_stock_sync = get_option('zoho_stock_sync_status');

// Status of product details sync status.
$zi_enable_details_sync_status = get_option('zoho_enable_details_sync_status');

// Sync Attributes of Variable Products
$zi_enable_attributes_sync = get_option('zoho_enable_attributes_sync_status');

// Accounting Stock mode
$zi_enable_accounting_stock = get_option('zoho_enable_accounting_stock_status');

?>
<script type="text/javascript" defer="defer">

/**
 * @description function for calling async ajax request.
 * @params action_type - type of ation to pass for ajax call.
 */
function sync_ajax(action_type) {

let table_root= "<table class='wp-list-table widefat fixed striped posts'><thead><tr><th class='item_id'>Action</th><th>Woocommerce Id</th><th>Log messages</th></tr></thead><tbody>";
let table_foot='</tbody></table>';

	let $status_area=document.getElementById("request_status");
	let $log_area=document.getElementById("log_area");
	document.getElementById("order_log").innerHTML='';
	$log_area.innerHTML='';

	let ischecked=jQuery("#from_zoho").prop('checked');
	//to check if checkbox is selected or not.
	let action_name='';
	if(action_type==='item' && ischecked){
		/* Hook will be : wp_ajax_zoho_ajax_call_item_from_zoho */
		action_name='zoho_ajax_call_'+jQuery("#from_zoho").val();
	}else if(action_type==='composite_item' && ischecked){

		// Hook will be : wp_ajax_zoho_ajax_call_composite_item_from_zoho
		action_name='zoho_ajax_call_composite_'+jQuery("#from_zoho").val();
	}else if(action_type==='variable_item' && ischecked){

		// Hook will be : wp_ajax_zoho_ajax_call_variable_item_from_zoho
		action_name='zoho_ajax_call_variable_'+jQuery("#from_zoho").val();
	} else if(action_type === 'contact' && ischecked){
		showLoader();
		console.log(action_type);
		import_zoho_contacts();
		return false;
	}else{
		action_name='zoho_ajax_call_'+action_type;
	}

		var data = {
			'action': action_name,
		};

		// Show different loader based on request
		if((action_type==='item' && !ischecked) || (action_type==='composite_item' && !ischecked)){
			// Show loader for background process.
			$status_area.innerHTML='<i>Synchronization started in the background. Feel free to check other tabs. Once the process is completed you will receive the email.</i>';
			setTimeout(() => {
				hideLoader();
			}, 5000);
		}else{
			// Show loader for zoho item sync.
			$status_area.innerHTML='<i>Synchronization started. Max 50 items will be imported. For more items, please use Cronjob</i>';
			setTimeout(() => {
				hideLoader();
			}, 5000);
		}

		showLoader();
		setTimeout(() => {
				hideLoader();
		}, 95000);

		jQuery.post(ajaxurl, data, function(response) {
			hideLoader();
			$status_area.innerHTML='';
			$table_body='';
			if(response){
				if(JSON.parse(response).length) {
					(JSON.parse(response)).forEach((logs)=>{
					$table_body+='<tr><td class="item_id">'+logs.resp_id+'</td><td>'+logs.woo_prod_id+'</td><td>'+logs.message+'</td></tr>';
					});
					$log_area.innerHTML=table_root+$table_body+table_foot;
				}
			}
		});
	}

	function import_zoho_contacts(){
		var data = {
			'action': 'import_zoho_contacts',
		};
		console.log("import_zoho_contacts");
		jQuery.post(ajaxurl, data, function(response) {
			if(response){
				console.log(response+' IN');
			}
		});
		hideLoader();
	}

	/**
	 * @description function for showing loader
	 */
	function showLoader(){
		jQuery("#loader_class").addClass("loader");
	}

	/**
	 * @description function to hide loader.
	 */
	function hideLoader(){
		jQuery("#loader_class").removeClass("loader");
	}

	/**
	 * function to disable order sync
	 *
	 * @return void
	 */
	function disableSync(action_key){
		let action_name=jQuery("#"+action_key).val();
		//isSelected is true or false with checking of data.
		let isSelected=jQuery("#"+action_key).prop('checked');
		let request_data = {
			'action': action_name,
			'sync_status': isSelected,
			'sync_option_key' : 'zoho_'+action_name+'_status',
		};
		// enable_order_status
		jQuery.post(ajaxurl, request_data, function(data,status) {
			console.log(status);
            if(status === 'success'){
				swal("Settings saved!", {
					icon: "success",
				});
			}else{
                Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Something went wrong!',
				footer: '<a href="https://roadmapstudios.com/contact">Get Support</a>'
				})
            }
		});
	}
</script>

<!--Settings page starts here-->
<?php if ($zoho_inventory_oid && $zoho_inventory_url) {?>
<h1 style="text-align:center;">Zoho Inventory Sync </h1>
<div class="zi-col-4">
<div style="padding-left:15px;"><a href="https://www.youtube.com/watch?v=fTRgHWHUtPk" target="_blank" style="font-size:14px">Watch the Tutorial<span class="dashicons dashicons-video-alt3"></span></a></div>
<div class="notice"><b>Step 1 - Category sync : </b>Syncing categories from WooCommerce to Zoho and vice versa. PLEASE DO THIS FIRST! If you haven't enabled categories in Zoho, please <a target="blank" href="<?php echo $zoho_inventory_url; ?>app#/settings/preferences/items">click here</a> and enable it.</div>
<div class="notice"><b>Step 2 - Category select : </b> Visit Cron Configuration to allow the categories.</div>
<div class="notice"><b>Step 3 - Item Sync : </b>  Syncing inventory item from WooCommerce to zoho. Or import from Zoho to WooCommerce via the checkbox.</div>
</div>
<form action="" method="post">
<div class="row zoho_row">
<div class="from-zoho">
	<input type="checkbox" name="item_from" id="from_zoho" value="item_from_zoho" >Import from Zoho Inventory

<!-- Code to enable/disable stock sync -->
	<input type="checkbox" name="disable_stock_sync" id="disable_stock_sync" value="stock_sync" onclick="disableSync('disable_stock_sync')"
	<?php
if ($zi_stock_sync == 'true') {
    echo 'checked';
}
    ?>
	>Disable Stock Sync
<!-- Code to enable/disable product attributes sync -->
<input type="checkbox" id="enable_attributes_sync" value="enable_attributes_sync" onclick="disableSync('enable_attributes_sync')"
	<?php
if ($zi_enable_attributes_sync == 'true') {
        echo 'checked';
    }
    ?>
	>Sync Variable Product Attributes
<!-- Code to enable/disable product attributes sync -->
<input type="checkbox" id="enable_accounting_stock" value="enable_accounting_stock" onclick="disableSync('enable_accounting_stock')"
	<?php
if ($zi_enable_accounting_stock == 'true') {
        echo 'checked';
    }
    ?>
	>Switch to Accounting Stock Mode
</div>

<input type="button" class="button button-primary button-large" style="float: left;" value="Categories Sync" onclick="sync_ajax('category')"/>
<input type="button" class="button button-primary button-large" style="float: left;" value="Sub Categories Sync" onclick="sync_ajax('subcategory')"/>

<input
type="button" class="button button-primary button-large"
style="float: left;" value="Items Sync" onclick="sync_ajax('item')"/>

<!-- Variable Item sync button open -->
<input
type="button" class="button button-primary button-large"
style="float: left;" value="Variable Items Sync" onclick="sync_ajax('variable_item')"/>

<!-- Variable Item Sync button close -->

<!-- Composite Item sync button open -->
	<?php
global $zi_plugin_prod_id;
    if (20832 === $zi_plugin_prod_id && class_exists('WC_Bundles')) {
        ?>
<input
type="button" class="button button-primary button-large" style="float: left;" value="Composite Items Sync" onclick="sync_ajax('composite_item')"/>
	<?php }?>
<!-- Composite Item Sync button close -->

<input type="button" class="button button-primary button-large" style="float: left;" value="Contacts Sync" onclick="sync_ajax('contact')"/>

</div>
</form>

<div class="loader-area">
<div id="request_status"></div>
<center><div id='loader_class'></div></center>
</div>
</div>

<div class="row zoho_row">
<div id="log_area"></div>
<div id="order_log"></div>
	<?php
} else {
    echo '<div class="notice notice-error zi-notice-large">Connect with zoho inventory first.</div>';
}
?>
<style>
/* .zoho_row{ width:650px; margin:0 auto;} */
.zoho_row{ display:inline-block;}
.zoho_row label{width: 25%;}
.zoho_row input[type="text"],
.zoho_row select {width: 65%;}
.zoho_row input[type="submit"]{width: 100px; margin: 20px auto; display: block;
}
.zoho_row input[type="button"]{width: 100px; margin: 20px 5px; display: block;
}
.button{
	min-width: 165px !important;
	margin-left:10px !important;
}
.item_id {
	width	:25%;
}
.from-zoho{
	margin-top: 18px;
	margin-left: 10px;
}
.zi-col-4{
	/* width:25%;
	float:left; */
}
.loader-area{
	/* margin-left:25%; */
}
#request_status {
	text-align:center;
}
/* CSS for Loader */
.loader {
 border: 5px solid #ffffff;
 border-radius: 50%;
 border-top: 5px solid #000000;
 width: 20px;
 height: 20px;
 -webkit-animation: spin 2s linear infinite; /* Safari */
 animation: spin 2s linear infinite;
 /* margin-left: 35%; */
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
/* Close CSS Loader */
</style>
