<?php

/**
 * This file for ZOHO inventory extra field mapping.
 *
 * @package     WooZo Inventory
 */

// WordPress Database Object.
global $wpdb;
// zoho organisation Id.
$zoho_inventory_oid = get_option('zoho_inventory_oid');
// Zoho inventory URL.
$zoho_inventory_url = get_option('zoho_inventory_url');
?>
<script type="text/javascript">
	/**
	 * @description function for showing loader
	 */
	function showLoader() {
		jQuery("#request_status").text('Please wait while processing...');
		jQuery("#loader_class").addClass("loader");
	}

	/**
	 * @description function to hide loader.
	 */
	function hideLoader() {
		jQuery("#loader_class").removeClass("loader");
	}

	function saveMappedField() {
		const keys = [];
		const values = [];
		const mappedField = {};

		jQuery("input[name='custom_field_key[]']").each(function() {
			if (jQuery(this).val()) {
				keys.push(jQuery(this).val());
			}
		});

		jQuery("input[name='custom_field_value[]']").each(function() {
			values.push(jQuery(this).val());
		});

		keys.forEach((key, index) => {
			mappedField[key] = values[index];
		});
		showLoader();
		const wp_ajax_data = {
			'action': 'map_custom_field',
			'data': mappedField
		};
		jQuery.post(ajaxurl, wp_ajax_data, function(response) {
			hideLoader();
			if (response) {
				hideLoader();
				const ajax_resp = JSON.parse(response);
				console.log('Response', response);
				jQuery("#request_status").text(ajax_resp.message);
			}

		});
	}

	// remove particular form field.
	function removeItem(index) {
		jQuery(`#${index}`).remove();
	}

	// function for calling async ajax request.
	// action_type - type of ation to pass for ajax call.
	function addMoreField() {

		jQuery("input[name='custom_field_button[]']").each(function() {
			console.log(jQuery(this).val())
			// values.push(jQuery(this).val());
		});
		const divId = Math.random().toString(16).substring(2, 15);
		const form_field = `<div id="${divId}" class="zi-dynamic-field-group">
		<div class="col-6">
			<input type="text" value="" name="custom_field_key[]" required />
		</div>
		<div class="col-6">
			<input type="text" value="" name="custom_field_value[]" required />
		</div>
		<button type="button" name="custom_field_button[]" onclick="removeItem('${divId}')" class="zi-dynamic-remove">remove</button>
	</div>`;
		jQuery("#form-field").append(form_field);
	}
</script>

<?php
if ($zoho_inventory_oid && $zoho_inventory_url) {
	$getmappedfield = get_option('wootozoho_custom_fields');
?>
	<!--Settings page starts here-->
	<h1 style="padding: 20px 0px;">
		<center>Custom Sales Order Fields</center>
	</h1>
	<div class="notice zi-success">Please read the documentation <a target="blank" href="https://support.roadmapstudios.com/portal/en/kb/articles/custom-fields-orders">here</a></div>

	<form action="" method="post">
		<div class="row zoho_row">
			<input type="button" class="button button-primary button-large" name="zoho_submit" value="Add field" onclick="addMoreField()" />
		</div>
		<div class="row zoho_row">
			<div class="col-6"> <label for="zoho_inventory_key"><b>Woo Field : </b></label> </div>
			<div class="col-6"> <label for="zoho_inventory_key" class="zi-zoho-field-label"><b>Zoho CF ID : </b></label></div>
		</div>
		<div id="form-field" class="row zoho_row">
			<?php
			if ($getmappedfield && count($getmappedfield) > 0) {
				foreach ($getmappedfield as $key => $value) {
					$rand_no = dechex(mt_rand());
			?>
					<div id="<?php echo $rand_no; ?>" class="zi-dynamic-field-group">
						<div class="col-6">
							<input type="text" value="<?php echo $key; ?>" name="custom_field_key[]" required />
						</div>
						<div class="col-6">
							<input type="text" value="<?php echo $value; ?>" name="custom_field_value[]" required />
						</div>
						<button type="button" name="custom_field_button[]" onclick="removeItem('<?php echo $rand_no; ?>')" class="zi-dynamic-remove">remove</button>
					</div>
				<?php
				}
			} else {
				$rand_div_id = dechex(mt_rand());
				?>
				<div id="<?php echo $rand_div_id; ?>" class="zi-dynamic-field-group">
					<div class="col-6">
						<input type="text" value="" name="custom_field_key[]" required />
					</div>
					<div class="col-6">
						<input type="text" value="" name="custom_field_value[]" required />
					</div>
					<button type="button" name="custom_field_button[]" onclick="removeItem('<?php echo $rand_div_id; ?>')" class="zi-dynamic-remove">remove</button>
				</div>
		</div>
	</form>
<?php
			}
?>
</div>
<div class="row zoho_row">
	<div id="request_status"></div>
	<center>
		<div id='loader_class'></div>
	</center>
</div>

<div class="row zoho_row">
	<input type="button" class="button button-primary button-large" name="zoho_submit" value="Save" onclick="saveMappedField()" />
</div>
<?php } else { ?>
	<div class="notice notice-error zi-notice-large">Connect with zoho inventory.</div>
<?php } ?>

<style>
	@media only screen and (min-width: 780px) {
		.zoho_row label {
			width: 200px;
		}
	}

	@media only screen and (max-width:780px) {
		.zoho_row label {
			width: 240px;
		}
	}

	.zi-dynamic-remove {
		background-color: #007cba;
		color: #ffffff;
		display: inline;
		font-size: 18px;
		padding: 8px;
	}

	.zi-dynamic-field-group {
		margin-bottom: 8px;
	}


	.zoho_row input[type="text"] {
		padding: 8px;
	}

	.zoho_row label {
		display: inline-block;
		padding: 10px;
		font-size: 18px;
		font-style: italic;
	}

	.col-6 {
		display: inline;
	}

	.zoho_row input[type="button"] {
		width: 100px;
		margin: 20px 5px;
		display: block;
	}

	.button {
		margin-left: 10px !important;
	}

	#request_status {
		text-align: center;
		font-weight: 600;
		font-size: 20px;
	}

	.loader {
		border: 5px solid #ffffff;
		border-radius: 50%;
		border-top: 5px solid #000000;
		width: 20px;
		height: 20px;
		-webkit-animation: spin 2s linear infinite;
		animation: spin 2s linear infinite;
	}

	@-webkit-keyframes spin {
		0% {
			-webkit-transform: rotate(0deg);
		}

		100% {
			-webkit-transform: rotate(360deg);
		}
	}

	@keyframes spin {
		0% {
			transform: rotate(0deg);
		}

		100% {
			transform: rotate(360deg);
		}
	}
</style>