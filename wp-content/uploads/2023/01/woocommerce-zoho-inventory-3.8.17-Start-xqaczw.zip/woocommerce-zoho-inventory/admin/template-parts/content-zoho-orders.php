<?php

/**
 * This file for ZOHO inventory connect.
 *
 * @package     WooZo Inventory
 */

// WordPress Database Object.
global $wpdb;

// zoho organisation Id.
$zoho_inventory_oid = get_option( 'zoho_inventory_oid' );
// Zoho inventory URL.
$zoho_inventory_url = get_option( 'zoho_inventory_url' );
$zoho_sync_status   = get_option( 'zoho_sync_status' );

// package status
$zoho_package_status   = get_option( 'zoho_package_zoho_sync_status' );
// Zoho Enable Auto Order Number.
$zi_enable_auto_order_no     = get_option( 'zoho_enable_auto_no_status' );
// Zoho send orders as confirmed
$zi_enable_order_sync_status = get_option( 'zoho_enable_order_status' );
// multi-currency support
$zi_enable_multicurrency = get_option( 'zoho_enable_multicurrency_status' );


// Zoho custom registration field
$registration_label_on_checkout = get_option( 'registration_label_on_checkout' );
if ( isset( $_POST['save_field'] ) ) {
	update_option( 'registration_label_on_checkout', $_POST['registration_label_on_checkout'] );
}

function get_zoho_warehouses() {
	
	$zoho_inventory_oid     = get_option( 'zoho_inventory_oid' );
	$zoho_inventory_url = get_option( 'zoho_inventory_url' );
	
	$url = $zoho_inventory_url . 'api/v1/settings/warehouses?organization_id=' . $zoho_inventory_oid;

	$executeCurlCallHandle = new ExecutecallClass();
	$json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
	$json2 = json_encode($json);
	
	return json_decode( $json2, true );
}

if ( $zoho_inventory_oid && $zoho_inventory_url ) {
	$zoho_tax_warehouses    = get_zoho_warehouses();
}

if(isset($_POST['btnSaveWarehouse'])){
	update_option('zoho_warehouse_id',$_POST['zoho_inventory_warehouses']);
}

if(isset($_POST['btnResetWarehouse'])){
	
	$warehouse_id = get_option('zoho_warehouse_id');
	
	if(!empty($warehouse_id)){
		delete_option('zoho_warehouse_id'); 
	}
}

if(isset($_POST['order_prefix'])){
	$prefix = trim($_POST['order_prefix']);
	update_option('order-prefix',$prefix);
}

?>
<script type="text/javascript" defer="defer">
	/**
	 * function to disable order sync
	 *
	 * @return void
	 */
	function disableSync(action_key){
		let action_name = jQuery("#"+action_key).val();
		//isSelected is true or false with checking of data.
		let isSelected=jQuery("#"+action_key).prop('checked');
		let request_data = {
			'action': action_name,
			'sync_status': isSelected,
			'sync_option_key' : 'zoho_'+action_name+'_status',
		};
		// enable_order_status
		jQuery.post(ajaxurl, request_data, function(data,status) {
			console.log(status);
            if(status === 'success'){
				swal("Settings saved!", {
					icon: "success",
				});
			}else{
                Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Something went wrong!',
				footer: '<a href="https://roadmapstudios.com/contact">Get Support</a>'
				})
            }
			if(jQuery("#enable_auto_number").is(':checked')){
				jQuery('.order-prefix').css('display','block');
			}else{
				jQuery('.order-prefix').css('display','none');
			}
			
			if(jQuery("#enable_multicurrency").is(':checked')){
				jQuery('.checkout_reg_field').css('display','block');
			}else{
				jQuery('.checkout_reg_field').css('display','none');
			}
			
		});
		
	}
</script>

<!--Settings page starts here-->
<?php if ( $zoho_inventory_oid && $zoho_inventory_url ) { ?>
<h1 style="text-align:center;">Orders Sync Settings </h1>
<form action="" method="post">
<div class="row zoho_row">

	<!-- Code to enable/disable package sync -->
	<?php
	global $zi_plugin_prod_id;
    if ( 26532 != $zi_plugin_prod_id ) {
	?>
	<input type="checkbox" name="package_sync" id="package_sync" value="package_zoho_sync" onclick="disableSync('package_sync')"
	
  <?php
	if ( $zoho_package_status == 'true' ) {
	echo 'checked';
	}
	?>
	
  >Create Package
  <?php } ?>
  
<!-- Code to enable/disable order sync -->
	<input type="checkbox" name="disable_sync" id="disable_sync" value="disable_zoho_sync" onclick="disableSync('disable_sync')"
	<?php
	if ( $zoho_sync_status == 'true' ) {
	echo 'checked';
	}
	?>
	>Disable order sync

<!-- Code to enable/disable auto sales order number sync -->
<input type="checkbox" id="enable_auto_number" value="enable_auto_no" onclick="disableSync('enable_auto_number')"
	<?php
	if ( $zi_enable_auto_order_no == 'true' ) {
		echo 'checked';
	}
	?>
	>Enable auto sales order number
	<!-- Code to enable/disable order status as confirm -->
<input type="checkbox" id="enable_order_status" value="enable_order" onclick="disableSync('enable_order_status')"
	<?php
	if ( $zi_enable_order_sync_status == 'true' ) {
		echo 'checked';
	}
	?> 
	>Send all Orders as Draft
	<!-- Code to enable/disable multicurrency support -->
	<br>
<input type="checkbox" id="enable_multicurrency" value="enable_multicurrency" onclick="disableSync('enable_multicurrency')"
	<?php
	if ( $zi_enable_multicurrency == 'true' ) {
		echo 'checked';
	}
	?> 
	>Enable Multicurrency Support
</div>

<div class="order-prefix zoho_row" <?php if ( $zi_enable_auto_order_no != 'true' ) { ?> style="display:none;" <?php } ?>> 
	<label for="zoho_inventory_tax">Order Prefix</label>
	<input type="text" style="width: 28%;" class="order-prefix-field" name="order_prefix" placeholder="Set Order Prefix like WC" <?php if(!empty(get_option('order-prefix'))){ ?> value=" <?php echo get_option('order-prefix'); ?>" <?php } ?> />
	<input type="submit" name="add_orderprefix" Value="Save Prefix" style="width:auto;margin:0;display: initial;" />
</div>

</form>
<form action="" method='POST'>
<div>

  <div class="row zoho_row">

	<label for="zoho_inventory_tax">Warehouses List</label>

	<select name="zoho_inventory_warehouses" required="required" class="tax-select">
		<option value="">Select a Warehouse (optional)</option>
		<?php foreach ( $zoho_tax_warehouses['warehouses'] as $key => $value ) { ?>
		
		<?php 
		  $warehouse_id = get_option('zoho_warehouse_id');
		?>
		<option <?php if($warehouse_id == $value['warehouse_id']){ echo 'selected="selected"'; }?> value="<?php echo $value['warehouse_id']; ?>" ><?php echo ucwords($value['warehouse_name']); ?></option>

				<?php } ?>
  </select>
  </div>
	  <div class="row zoho_row">
		<?php if(intval(get_option('zoho_warehouse_id')) > 0 ){ ?>
			<input type="submit" name="btnSaveWarehouse" class="button button-primary" value="Re-save Warehouse" style="margin-left: 26%;float: left;">
			<input type="submit" name="btnResetWarehouse" class="button button-primary" value="Reset" style="margin-left: 10%;float: left;">
		<?php }else{ ?>
			<input type="submit" name="btnSaveWarehouse" class="button button-primary" value="Save Warehouse" style="margin-left: 26%;float: left;">
		<?php } ?>
	</div>
 </div>
 </form>

<br> 
<div class="checkout_reg_field" <?php if ( $zi_enable_multicurrency != 'true' ) { ?> style="display:none;" <?php } ?>>
<form action="" method="post">
<div class="row zoho_row_label">
<label for="registration_label_on_checkout" style="font-weight: 700;">Registration Label on Checkout: </label>
<p><em>Note: enabling multicurrency support will force registration before customers can see the checkout page. You can create a label here below to improve the user experience.</em></p>
<textarea name="registration_label_on_checkout" id="registration_label_on_checkout" placeholder="To ensure your order gets processed quickly, please enter your email address to continue :)"><?php echo $registration_label_on_checkout; ?></textarea>
</div>
<div class="row zoho_row">
<input
type="submit" class="button button-primary button-large" name="save_field" style="margin: 10px auto !important;" value="Save" /> </div>
</form>
</div>
 
<style>
.zoho_row{ width:650px; margin:0 auto; margin-top: 20px;}

.zoho_row label{width: 25%; display: inline-block;}
.zoho_row input[type="text"]{width: 65%;}
.zoho_row select {width: 65%;}
.zoho_row input[type="submit"]{width: auto; margin: 20px auto; display: block;
}
.tax-select{ width:25%; }

.zoho_row_label{ width:650px; margin:0 auto;}
.zoho_row_label label {
    width: 100%;
    text-align: left;
    display: inline-block;
}
.zoho_row_label textarea {
    width: 100%;
    height: 70px;
    margin-top: 10px;
}

</style>
<?php } ?>