<?php

/**
 * File for ZOHO inventory cron integration.
 *
 * @package  WooZo Inventory
 */

require_once RMS_DIR_PATH . 'data-sync.php';

// On form button to remove categories.
if (isset($_POST['btnCatRemove'])) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'options';
    $sql = $wpdb->get_results('SELECT * FROM ' . $table_name . ' WHERE option_name LIKE "%zoho_id_for_term_id_%"');
    foreach ($sql as $key => $row) {
        $option_name = $row->option_name;
        delete_option($option_name);
    }
    delete_option('zoho_item_category');

    $msg = 'Categories are no longer mapped with Zoho. Please resync categories';
    echo '<script>alert("' . $msg . '")</script>';
}

// On form get submitted to save categories.
if (isset($_POST['btnCatSave'])) {
    $zi_category = $_POST['category'];
    if ($zi_category) {
        save_category($zi_category);
    } else {
        $errmsg = 'Please select at least one category to save changes.';
    }
}

/**
 * Function to set category in local
 *
 * @return void
 */
function save_category($zi_category)
{
    if ($zi_category) {
        $cat_serealised = serialize($zi_category);
    } else {
        $cat_serealised = '';
    }
    //To use this option unserealise the option data.
    update_option('zoho_item_category', $cat_serealised);
}

// Validating whether user is having url added or not.
$zi_oid = get_option('zoho_inventory_oid');
$zi_api_url = get_option('zoho_inventory_url');
$zi_cron_is_active = get_option('zi_cron_isactive');

$opt_category = get_option('zoho_item_category');
if ($opt_category) {
    $opt_category = unserialize($opt_category);
} else {
    $opt_category = array();
}

// disable item name for sync-from-zoho cron
$zi_disable_itemname_sync = get_option('zoho_disable_itemname_sync_status');
// disable item price for sync-from-zoho cron
$zi_disable_itemprice_sync = get_option('zoho_disable_itemprice_sync_status');
// disable item image for sync-from-zoho cron
$zi_disable_itemimage_sync = get_option('zoho_disable_itemimage_sync_status');
if (empty($zi_disable_itemimage_sync)) {
    add_option('zoho_disable_itemimage_sync_status', 'false');
}
// disable item description sync
$zi_disable_itemdescription_sync = get_option('zoho_disable_itemdescription_sync_status');
// disable new group item sync
$zi_disable_groupitem_sync = get_option('zoho_disable_groupitem_sync_status');

if ($zi_oid && $zi_api_url) {
    // get_zoho_item_categories function declared in data-sync.php initially it was in same folder.
    $zoho_item_categories = get_zoho_item_categories();
    ?>

<script type="text/javascript" defer="defer">
	/**
	 * function to disable order sync
	 *
	 * @return void
	 */
	function disableSync(action_key){
		let action_name=jQuery("#"+action_key).val();
		//isSelected is true or false with checking of data.
		let isSelected=jQuery("#"+action_key).prop('checked');
		let request_data = {
			'action': action_name,
			'sync_status': isSelected,
			'sync_option_key' : 'zoho_'+action_name+'_status',
		};
		// enable/disable option
		jQuery.post(ajaxurl, request_data, function(data,status) {
			console.log(status);
            if(status === 'success'){
				swal("Settings saved!", {
					icon: "success",
				});
			}else{
                Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Something went wrong!',
				footer: '<a href="https://roadmapstudios.com/contact">Get Support</a>'
				})
            }
		});
	}

	//check all boxes
	jQuery(document).ready(function() {
		jQuery('.chk_boxes').click(function(){
			if(jQuery(this).prop("checked") == true){
				jQuery('.chk_boxes1').prop('checked', true);
			}else{
				jQuery('.chk_boxes1').prop('checked', false);
			}
		});
	});
</script>

<style>
.zoho_row{ width:550px; margin:0 auto;}
.zoho_row label{width: 25%; display: inline-block;}
.zoho_row input[type="text"]{width: 65%;}
.zoho_row select {width: 65%;}
.zoho_row input[type="submit"]{margin: 20px auto; display: inline-block;
}
.act-interval{
	background: #fff;
	border-left: 4px solid #fff;
	box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
	padding: 10px;
	color: red;
}
</style>

<h1><center>Zoho Cron Configuration
</center></h1>
<br>
<?php global $zi_plugin_prod_id;
    if (26532 == $zi_plugin_prod_id) {
        ?>
	<div style="padding: 15px;" class="notice notice-error">Automatic Bi-directional is not included in this version. Please upgrade to Connect or Pro to take advantage of this feature. <a target="blank" href="https://roadmapstudios.com/account">Upgrade</a></div>
<?php } else {?>
	<div style="padding: 15px;" class="notice notice-error">Please make sure the Cron Interval is set to once or twice per day.</div>
<div style="padding: 15px;" class="notice notice-error">Please read the Cronjob documentation <a target="blank" href="https://support.roadmapstudios.com/portal/en/kb/articles/cron-configuration">here</a>.</div>
<?php }?>

<p><center><strong>This setting page allows you to tell the plugin which Item categories it should sync.</strong></center></p>
<br>
<form method='POST'>
	<div class="row zoho_row">
	<div class="from-zoho">
	<!-- Code to enable/disable product details sync status -->
	<input type="checkbox" id="disable_itemname_sync" value="disable_itemname_sync" onclick="disableSync('disable_itemname_sync')"
	<?php
if ($zi_disable_itemname_sync == 'true') {
        echo 'checked';
    }
    ?>
	>Disable Item Name Sync for Cron
	<!-- Code to enable/disable product price sync status -->
	<input type="checkbox" id="disable_itemprice_sync" value="disable_itemprice_sync" onclick="disableSync('disable_itemprice_sync')"
	<?php
if ($zi_disable_itemprice_sync == 'true') {
        echo 'checked';
    }
    ?>
	>Disable Price Sync for Cron
	<!-- Code to enable/disable product image sync status -->
	<input type="checkbox" id="disable_itemimage_sync" value="disable_itemimage_sync" onclick="disableSync('disable_itemimage_sync')"
	<?php

    if ($zi_disable_itemimage_sync == 'true') {
        echo 'checked';
    }
    ?>
	>Disable Featured Image Sync for Webhook
	</br>
	<!-- Code to enable/disable product description sync status -->
	<input type="checkbox" id="disable_itemdescription_sync" value="disable_itemdescription_sync" onclick="disableSync('disable_itemdescription_sync')"
	<?php

    if ($zi_disable_itemdescription_sync == 'true') {
        echo 'checked';
    }
    ?>
	>Disable Product Description Sync for Webhook
	<!-- Code to enable/disable group item sync status -->
	<input type="checkbox" id="disable_groupitem_sync" value="disable_groupitem_sync" onclick="disableSync('disable_groupitem_sync')"
	<?php
if ($zi_disable_groupitem_sync == 'true') {
        echo 'checked';
    }
    ?>
	>Disable Group Item Sync for Cron
	</div>
	<hr>
	<p>Please select one or more categories to enable sync:</p>
	<input type="checkbox" class="chk_boxes" label="check all" /><strong>Check All</strong>
	</br>
	</br>
		<?php
foreach ($zoho_item_categories['categories'] as $category) {
        if ($category['category_id'] != '-1' && $category['category_id'] > 0) {
            $category_name = $category['name'];
            $category_id = $category['category_id'];
            ?>
				<input
				type="checkbox"
				name="category[]"
				class="chk_boxes1"
				value="<?php echo $category_id; ?>"
				<?php
if (in_array($category_id, $opt_category)) {
                echo 'checked';
            }
            ?>
				>
				<?php echo $category_name; ?> <br>
				<?php
}
    }
    ?>

	</div>
	<div class="row zoho_row">
	<input type="submit" name="btnCatSave" class="button button-primary" value="Save Category" style=" margin-top: 10px;">
	<?php if (!empty($opt_category)) {?>
	<input type="submit" name="btnCatRemove" class="button button-primary" value="Reset Categories" style=" margin-top: 10px;">
	<?php }?>
	</div>
</form>
<?php } else {
    echo '<div class="notice notice-error zi-notice-large">Connect with zoho inventory first.</div>';
}?>