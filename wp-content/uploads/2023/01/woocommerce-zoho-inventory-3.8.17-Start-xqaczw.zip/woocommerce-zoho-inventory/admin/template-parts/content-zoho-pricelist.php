<?php

/**
 * File for ZOHO inventory Pricelist integration.
 *
 * @package  WooZo Inventory
 * @category Zoho Pricelist Content
 * @author   Roadmap Studios
 * @link     https://roadmapstudios.com
 */

if (!defined('ABSPATH')) {
	exit;
}


/**
 * Function for getting zoho taxes
 */

// Getting API credentials
$zoho_inventory_oid     = get_option('zoho_inventory_oid');
$zoho_inventory_url = get_option('zoho_inventory_url');

/**
 * Function to check if role based price exists
 */
function zi_check_role_based_price_exists($postmetaArr, $role)
{
	foreach ($postmetaArr as $postmeta) {
		if ($postmeta['user_role'] === $role) {
			return true;
		} else {
			return false;
		}
	}
}


function get_zoho_pricelist()
{
	$zoho_inventory_oid     = get_option('zoho_inventory_oid');
	$zoho_inventory_url = get_option('zoho_inventory_url');

	$url                = $zoho_inventory_url . 'api/v1/pricebooks?organization_id=' . $zoho_inventory_oid;

	$executeCurlCallHandle = new ExecutecallClass();
	$json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
	$json2 = json_encode($json);
	return json_decode($json2, true);
}

function get_pricelist($pricebook_id)
{
	$zoho_inventory_oid     = get_option('zoho_inventory_oid');
	$zoho_inventory_url = get_option('zoho_inventory_url');

	$url                = $zoho_inventory_url . 'api/v1/pricebooks/' . $pricebook_id . '?organization_id=' . $zoho_inventory_oid;

	$executeCurlCallHandle = new ExecutecallClass();
	$json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
	$json2 = json_encode($json);

	$data = json_decode($json2, true);
	return $data;
}


function apply_zoho_pricelist($post)
{
	$zoho_inventory_oid     = get_option('zoho_inventory_oid');
	$zoho_inventory_url = get_option('zoho_inventory_url');

	$pricelist_id = $post['zoho_inventory_pricelist'];
	update_option('zoho_pricelist_id', $pricelist_id);
	$data = get_pricelist($pricelist_id);
	$pricebook_type = $data['pricebook']['pricebook_type'];

	if (!empty($data)) {
		if ($pricebook_type == 'fixed_percentage') {
			$percentage = $data['pricebook']['percentage'];
			$is_increase = $data['pricebook']['is_increase'];
			$query = new WC_Product_Query(array(
				'limit' => -1,
				'return' => 'ids',
			));
			$ids = $query->get_products();
			$percentage_order = '';
			if ($is_increase == true) {
				$percentage_order = 'percentage_increase';
			} else {
				$percentage_order = 'percentage_decrease';
			}
			$newpricelists['orderby'] = $percentage_order;
			foreach ($ids as $id) {
				$zi_item_id = intval(get_post_meta($id, 'zi_item_id', true));
				if ($zi_item_id > 0) {
					$newpricelists['ids'][$zi_item_id] = $percentage;
				}
			}
		} else {
			$newpricelists['orderby'] = 'fixed_price';
			foreach ($data['pricebook']['pricebook_items'] as $itemlist) {
				if(is_array($itemlist['price_brackets']) && !empty($itemlist['price_brackets'])){
					$newpricelists['ids'][$itemlist['item_id']] = $itemlist['price_brackets'][0]['pricebook_rate'];
				}else{
					$newpricelists['ids'][$itemlist['item_id']] = $itemlist['pricebook_rate'];
				}
			}
		}
	}
	return $newpricelists;
}

if ($zoho_inventory_oid && $zoho_inventory_url) {
	$zoho_pricebooks    = get_zoho_pricelist();
}

if (isset($_POST['btnSavePricelist'])) {
	$zoho_pricelists_ids    = apply_zoho_pricelist($_POST);
	global $wpdb;
	$array_keys = array_keys($zoho_pricelists_ids['ids']);
	foreach ($array_keys as $key) {
		$zoho_pricelists_price = $zoho_pricelists_ids['ids'][$key];
		$tbl = $wpdb->prefix;
		$res = $wpdb->get_row('SELECT * FROM ' . $tbl . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $key . "'");
		$formatted_price = wc_get_price_decimal_separator();
		$zoho_pricelists_price2 = str_replace('.', $formatted_price, $zoho_pricelists_price);
		if ($res->post_id > 0) {
			$postmetaArr = get_post_meta($res->post_id, '_role_base_price', true);
			$rolewise_price_meta = array();

			$metavalue = array(
				'discount_type' => $zoho_pricelists_ids['orderby']
			);
			$metavalue['discount_type'] = $zoho_pricelists_ids['orderby'];
			$metavalue['discount_value'] = $zoho_pricelists_price2;
			$metavalue['min_qty'] = '';
			$metavalue['max_qty'] = '';
			$metavalue['user_role'] = $_POST['wp_user_role'];

			if (count($postmetaArr) > 0 && $postmetaArr[0]) {
				// Copy all existing meta to new array.
				foreach ($postmetaArr as $postmeta) {
					array_push($rolewise_price_meta, $postmeta);
				}
				// Push new meta if doesn't exists.
				$zi_is_rolebased_price = zi_check_role_based_price_exists($postmetaArr, $_POST['wp_user_role']);
				if (!$zi_is_rolebased_price) {
					array_push($rolewise_price_meta, $metavalue);
				}
			} else {
				array_push($rolewise_price_meta, $metavalue);
			}
			update_post_meta($res->post_id, '_role_base_price', $rolewise_price_meta);
			// exit();
		}
	}
}

if (isset($_POST['btnResetPricelist'])) {

	// remove _role_base_price postmeta of all products - loop 
	global $wpdb;
	$table_name = $wpdb->prefix . 'postmeta';
	$res = $wpdb->get_results('SELECT * FROM ' . $table_name . ' WHERE meta_key="_role_base_price"');
	// echo print_r($res, true);
	foreach ($res as $key => $row) {
		delete_post_meta($row->post_id, '_role_base_price');
	}

	$pricebook_id = get_option('zoho_pricelist_id');
	if (!empty($pricebook_id)) {
		//	delete_option('zoho_pricelist_id');
	}
}

?>

<h1>
	<center>Zoho Inventory Pricelist</center>
</h1>
<div style="padding: 15px;" class="notice notice-error">Please read the documentation <a target="blank" href="https://support.roadmapstudios.com/portal/en/kb/articles/pricelist">here</a>.</div>


<?php
global $zi_plugin_prod_id;
if (26532 != $zi_plugin_prod_id && class_exists('Addify_B2B_Plugin')) { ?>
	<form action="" method='POST'>
		<div>

			<div class="row zoho_row">

				<label for="zoho_inventory_tax">Zoho Price List</label>

				<select name="zoho_inventory_pricelist" required="required" class="tax-select">
					<option value="">Select Price List</option>
					<?php foreach ($zoho_pricebooks['pricebooks'] as $key => $value) { ?>

						<?php
						$pricebook_id = get_option('zoho_pricelist_id');
						?>
						<option <?php if ($pricebook_id == $value['pricebook_id']) {
									echo 'selected="selected"';
								} ?> value="<?php echo $value['pricebook_id']; ?>"><?php echo ucwords($value['name']); ?></option>

					<?php } ?>
				</select>
			</div>
			<?php
			global $wp_roles;
			$roles = $wp_roles->get_names();
			?>
			<div class="row zoho_row">
				<label for="zoho_inventory_tax">Users Role</label>
				<select name="wp_user_role" class="tax-select">
					<option value="">Select Users Role</option>
					<?php foreach ($roles as $key => $role) { ?>

						<option <?php
								?> value="<?php echo $key; ?>"><?php echo ucwords($role); ?></option>

					<?php } ?>
				</select>
			</div>


		</div>
		<div class="row zoho_row">
			<?php if (intval(get_option('zoho_pricelist_id')) > 0) { ?>
				<input type="submit" name="btnSavePricelist" class="button button-primary" value="Re-apply Price" style="margin-left: 26%;float: left;">
				<input type="submit" name="btnResetPricelist" class="button button-primary" value="Reset" style="margin-left: 10%;float: left;">
			<?php } else { ?>
				<input type="submit" name="btnSavePricelist" class="button button-primary" value="Apply Price" style="margin-left: 26%;float: left;">
			<?php } ?>
		</div>
	</form>
<?php } else {
	echo '<div class="notice notice-error zi-notice-large">Please upgrade your plan for this feature and/or ensure the B2B plugin is active</div>';
}
?>
<style>
	.zoho_row {
		width: 550px;
		margin: 0 auto;
		margin-bottom: 20px;
	}

	.zoho_row label {
		width: 25%;
		display: inline-block;
	}

	.zoho_row input[type="text"] {
		width: 65%;
	}

	.zoho_row select {
		width: 65%;
	}

	.zoho_row input[type="submit"] {
		width: auto;
		margin: 20px auto;
		display: block;
	}

	.tax-select {
		width: 25%;
	}
</style>