<?php
/**
 * File for ZOHO inventory tax integration.
 *
 * @package  WooZo Inventory
 * @category Zoho Tax Content
 * @author   Roadmap Studios
 * @link     https://roadmapstudios.com
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Function for getting all tax slabs available in local database.
 */
function zi_get_all_wc_tax_rate_ids()
{

    $wc_tax_array = array();
    $tax_classes = WC_Tax::get_tax_classes(); // Retrieve all tax classes.
    if (!in_array('', $tax_classes)) { // Make sure "Standard rate" (empty class name) is present.
        array_unshift($tax_classes, '');
    }

    foreach ($tax_classes as $tax_class) { // For each tax class, get all rates.
        $taxes = WC_Tax::get_rates_for_tax_class($tax_class);

        // echo '<pre>'.print_r($taxes, true).'</pre>';

        foreach ($taxes as $key => $tax) {
            $taxarray = (array) $tax;
            $taxarray['id'] = $key;
            array_push($wc_tax_array, $taxarray);
        }

    }

    return $wc_tax_array;
}

/**
 * Function for getting zoho taxes
 */
function get_zoho_tax_rates()
{
    // $fd = fopen(__DIR__.'/tax-mapping.txt','w+');

    $zoho_inventory_oid = get_option('zoho_inventory_oid');
    $zoho_inventory_url = get_option('zoho_inventory_url');
    $url = $zoho_inventory_url . 'api/v1/settings/taxes?organization_id=' . $zoho_inventory_oid;

    $headers = array(
        'Content-Type' => 'application/json;charset=UTF-8',
    );

    $executeCurlCallHandle = new ExecutecallClass();
    $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
    $code = $json->code;
    $json2 = json_encode($json);

    // fwrite($fd, PHP_EOL. $json2); //logging response
    // fclose($fd); //end of logging

    if ($code != 0) {
        echo '<pre>';
        print_r($json2);
    } else {
        return json_decode($json2, true);
    }
}

// Validating whether user tax endpoint is working
$zoho_tax_rates = get_zoho_tax_rates();

if (is_array($zoho_tax_rates)) {
    $woocommerce_taxes = zi_get_all_wc_tax_rate_ids();

    // On form get submitted.
    if (isset($_POST['btnSave'])) {
        $cnt = count($woocommerce_taxes);
        for ($j = 0; $j < $cnt; $j++) {
            $val = $_POST['zoho_inventory_tax_' . $j];
            $valarray = explode('^^', $val);
            update_option('zoho_inventory_tax_rate_' . $valarray[0], $valarray[1]);
        }

        if (!empty($_POST['zi_vat_exempt'])) {

            $zi_vat_exempt = $_POST['zi_vat_exempt'];
            update_option('zi_vat_exempt', $zi_vat_exempt);
        }
    }

    ?>

<style>
.zoho_row{ width:550px; margin:0 auto;}
.zoho_row label{width: 25%; display: inline-block;}
.zoho_row input[type="text"]{width: 65%;}
.zoho_row select {width: 65%;}
.zoho_row input[type="submit"]{width: 100px; margin: 20px auto; display: block;
}
.tax-select{ width:25%; }
</style>

<h1><center>Zoho Inventory Tax Mapping</center></h1>

<div style="padding: 15px;" class="notice notice-error">Please read the Tax Mapping documentation <a target="blank" href="https://support.roadmapstudios.com/portal/en/kb/articles/tax-mapping">here</a></div>

<?php if (wc_tax_enabled() && $woocommerce_taxes) {?>

<script>
    /**
	 * Function to make ajax call to enable or disable log.
	 *
	 * @return void
	 */
	function doAjaxRequest(action_key) {
		let action_name=jQuery("#"+action_key).val();
		//isSelected is true or false with checking of data.
		let isSelected=jQuery("#"+action_key).prop('checked');
		let request_data = {
			'action': action_name,
			'sync_status': isSelected,
			'sync_option_key' : 'zoho_'+action_name+'_status',
		};

		jQuery.post(ajaxurl, request_data, function(data,status) {
			console.log(status);
            if(status === 'success'){
				swal("Settings saved!", {
					icon: "success",
				});
			}else{
                Swal.fire({
				icon: 'error',
				title: 'Oops...',
				text: 'Something went wrong!',
				footer: '<a href="https://roadmapstudios.com/contact">Get Support</a>'
				})
            }
		});
	}
</script>
<br>
<div class="row zoho_row">
    <!-- Code to enable/disable Decimal Tax Support -->
<br/>
    <input type="checkbox" name="enable_decimal_tax" id="enable_decimal_tax" value="enable_decimal_tax" onclick="doAjaxRequest('enable_decimal_tax')"
    <?php
$zoho_enable_decimal_tax = get_option('zoho_enable_decimal_tax_status');
if ($zoho_enable_decimal_tax == 'true') {
    echo 'checked';
}
?>
    >Please check to enable support for Decimal Tax (e.g.: 9.25%).
</div>

<form method='POST'>
<div>
	<?php
$i = 0;
        foreach ($woocommerce_taxes as $wc_tax_rate) {
            $selected_tax_rate = get_option('zoho_inventory_tax_rate_' . $wc_tax_rate['id']);
            $selected_vat_exempt = get_option('zi_vat_exempt');

            ?>
  <div class="row zoho_row">

	<label for="zoho_inventory_tax"><?php echo $wc_tax_rate['tax_rate_name']; ?> </label>

	<select name="zoho_inventory_tax_<?php echo $i; ?>" class="tax-select">
		<?php
foreach ($zoho_tax_rates['taxes'] as $key => $value) {
                $json_encode_tax = $value['tax_id'] . '##' . str_replace(' ', '@@', $value['tax_name']) . '##' . str_replace(' ', '@@', $value['tax_type']) . '##' . $value['tax_percentage'];
                ?>

	<option
	value="<?php echo $wc_tax_rate['id'] . '^^' . $json_encode_tax; ?>"
			<?php
if ($selected_tax_rate == $json_encode_tax) {
                    echo ' selected ';}
                ?>
		>
			<?php echo $value['tax_name']; ?>
	</option>

			<?php }?>
  </select>
  </div>

<?php $i++;}?>

  <div class="row zoho_row">

	<label for="zi_vat_exempt">Vat Exempt</label>

	<select name="zi_vat_exempt" class="tax-select">
		<?php
$selected_vat_exempt = get_option('zi_vat_exempt');
        foreach ($zoho_tax_rates['taxes'] as $key => $value) {
            $tax_id = $value['tax_id'];
            ?>

	<option
	value="<?php echo $tax_id; ?>"
			<?php
if ($selected_vat_exempt == $tax_id) {
                echo ' selected ';}
            ?>
		>
			<?php echo $value['tax_name']; ?>
	</option>

			<?php }?>
  </select>
  </div>


	</div>
	<div class="row zoho_row">
		<input type="submit" name="btnSave" class="button button-primary" value="Save Changes" style="margin-left: 26%; margin-top: 10px;">
	</div>
</form>
<?php } else {
        $tax_settings_url = site_url('/wp-admin/admin.php?page=wc-settings');
        echo '<div class="notice notice-error zi-notice-large">Please enable Taxes in <a href="' . $tax_settings_url . '">WC Settings</a> with <strong>at least</strong> the Standard rate configured. Tax Mapping is <strong>required</strong> to sync Items.</div>';
    }?>
<?php } else {
    echo '<div class="notice notice-error zi-notice-large">Connection is not made properly. Please check Organization ID.</div>';
}
?>
