<?php
/**
 * File for ZOHO inventory.
 *
 * @package  WooZo Inventory
 * @category Zoho Content
 * @author   Roadmap Studios
 * @link     https://roadmapstudios.com
 */
if (!defined('ABSPATH')) {
    exit;
}

// zoho subscription id
$zoho_subscription_id = get_option('zoho_subscription_id');
// zoho domain.
$zoho_inventory_domain = get_option('zoho_inventory_domain');

$customer_name = get_option('zi_customer_name', true);
$customer_email = get_option('zi_customer_email', true);
$customer_review = get_option('zi_customer_review');

/**
 * Function placing review of product.
 */
if (isset($_POST['submit_review'])) {

  // $fd = fopen(__DIR__.'/submit_review.txt','w+');
  update_option('zi_customer_review', $_REQUEST['review']);

    $body = array(
      'subscription_id' => $zoho_subscription_id,
      "product_id" => '12447',
      "review" => $_REQUEST['review'],
      "reviewer" => $customer_name,
      "reviewer_email" => $customer_email
    );

    $args = array(
      'method'      => 'POST',
      'timeout'     => 45,
      'sslverify'   => false,
      'headers'     => array(
          'Content-Type'  => 'application/json',
      ),
      'body'        => json_encode($body),
  );

    // fwrite($fd, PHP_EOL. 'Data: ' . print_r($args, true));
    $request = wp_remote_post( 'https://roadmapstudios.com/wp-json/zoho/v1/reviews', $args);   
    if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) != 200 ) {
      error_log( print_r( $request, true ) );
    }

    $response = wp_remote_retrieve_body( $request );

    // fwrite($fd, PHP_EOL. 'Response: '. print_r($response, true)); //logging response
    // fclose($fd); //end of logging

}

?>

<h1 style="padding: 10px 0px;"><center>Review this integration with 5-stars and get 25% off!</center></h1>
<p><center>You will get 25% on your next renewal payment immediately!</center></p>

<?php if ($zoho_subscription_id) {?>

<?php if (!$customer_review) {?>
<div class="cont">
<div class="stars">
<form method="post" action="">
  <input class="star star-5" id="star-5-2" type="radio" name="star"/>
  <label class="star star-5" for="star-5-2"></label>
  <input class="star star-4" id="star-4-2" type="radio" name="star"/>
  <label class="star star-4" for="star-4-2"></label>
  <input class="star star-3" id="star-3-2" type="radio" name="star"/>
  <label class="star star-3" for="star-3-2"></label>
  <input class="star star-2" id="star-2-2" type="radio" name="star"/>
  <label class="star star-2" for="star-2-2"></label>
  <input class="star star-1" id="star-1-2" type="radio" name="star"/>
  <label class="star star-1" for="star-1-2"></label>
  <br>
  <text><?php echo 'Name: ' . $customer_name; ?></text><br>
  <text><?php echo 'Email: ' . $customer_email; ?></text><br>
  <div class="rev-box">
    <textarea class="review" col="30" name="review" placeholder="Please explain why"></textarea>
	<input
	type="submit" class="button button-primary button-large"
	name="submit_review"  value="Submit Review" />
  </div>
</form>
</div>
</div>
<?php } else {?>
<div><h3><center>Thank you for the review! :)</center></h3></div>
<?php }?>

<?php } else {echo '<h3 style="color:red;text-align:center;">Please save your Subscription ID first on the Connect Tab to see the Review Form!</center></h3>';}?>

<?php if ('eu' == $zoho_inventory_domain) {?>
<!--<br>
<div class="partnertag">
<h2 style="color:red;text-align:center;">Want even more Discount? Tag us as Zoho Partner and get 50% recurring discount!</h2>
<p><center>Tag us and get 50% off on the annual subscription payment as long as we are tagged. This requires a paid Zoho plan.</center></p>
<center><a href="https://payments.zoho.eu/html/store/tagyourpartner.html?partnerid=0a352d8940e34357b4d595898e028fb5" class="button" target="_blank">Tag us now</a><center>
<p><center>Send us an email via our <a href="https://roadmapstudios.com/contact" target="_blank">contact page</a> once you have Tagged us as parter.</center></p>

</div>-->

<?php }?>

<div style="text-align:center;">
<a href="https://siteground.com/woocommerce-hosting.htm?afimagecode=d920d0941621d9b9e7ecd5f6671b6c72" target="_blank">
  <img border="0" src="<?php echo RMS_DIR_URL . 'assets/img/general_EN_woocommerce-square-violet.jpg'; ?>">
</a>
</div>

<style>
.cont{
  width: 93%;
  max-width: 350px;
  text-align: center;
  margin: 4% auto;
  padding: 30px 0;
  background: #111;
  color: #EEE;
  border-radius: 5px;
  border: thin solid #444;
  overflow: hidden;
}

hr{
  margin: 20px;
  border: none;
  border-bottom: thin solid rgba(255,255,255,.1);
}

div.title{
  font-size: 2em;
}

h1 span{
  font-weight: 300;
  color: #Fd4;
}

div.stars{
  width: 270px;
  display: inline-block;
}

input.star{
  display: none;
}

label.star {
  float: right;
  padding: 10px;
  font-size: 36px;
  color: #444;
  transition: all .2s;
}

input.star:checked ~ label.star:before {
  content:'\f005';
  color: #FD4;
  transition: all .25s;
}


input.star-5:checked ~ label.star:before {
  color:#FE7;
  text-shadow: 0 0 20px #952;
}

input.star-1:checked ~ label.star:before {
  color: #F62;
}

label.star:hover{
  transform: rotate(-15deg) scale(1.3);
}

label.star:before{
  content:'\f006';
  font-family: FontAwesome;
}

.rev-box{
  overflow: hidden;
  height: 0;
  width: 100%;
  transition: all .25s;
}

textarea.review{
  background: #222;
  border: none;
  width: 100%;
  max-width: 100%;
  height: 100px;
  padding: 10px;
  box-sizing: border-box;
  color: #EEE;
}

label.review{
  display: block;
  transition:opacity .25s;
}



input.star:checked ~ .rev-box{
  height: 125px;
  overflow: visible;
}
</style>