<?php

/**
 * This file for ZOHO inventory connect.
 *
 * @package     WooZo Inventory
 * @category    Zoho configuration
 * @author      Roadmap Studios
 * @link        https://roadmapstudios.com
 */

use Automattic\WooCommerce\Client;
use Automattic\WooCommerce\HttpClient\HttpClientException;

global $wpdb;
global $errmessage;
$save_status = '';
$zoho_api_urls = array(
    'https://inventory.zoho.com/',
    'https://inventory.zoho.eu/',
    'https://inventory.zoho.in/',
    'https://inventory.zoho.com.au/',
);

$zoho_api_domains = array(
    'com',
    'eu',
    'in',
    'com.au',
);

// Access Code
if (isset($_GET['code'])) {

    $handlefunction2 = new Classfunctions;

    $respoAtJs = $handlefunction2->GetServiceZIAccessToken($_GET['code']);

    update_option('zoho_inventory_auth_code', $_GET['code']);
    update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
    update_option('zoho_inventory_refresh_token', $respoAtJs['refresh_token']);
    update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);

}

// Save Keys and details Action.
if (isset($_POST['zoho_submit'])) {

    $nonce = sanitize_text_field($_REQUEST['_wpnonce']);

    if (!wp_verify_nonce($nonce, 'zoho_inventory_settings_nonce')) {

        echo '<div class="error"><p><strong>' . esc_html__('Reload the page again') . '</strong></p></div>' . "\n";

    } else {

        update_option('zoho_inventory_domain', $_POST['zoho_inventory_domain']);
        update_option('zoho_inventory_oid', $_POST['zoho_inventory_oid']);
        update_option('zoho_inventory_cid', $_POST['zoho_inventory_cid']);
        update_option('zoho_inventory_cs', $_POST['zoho_inventory_cs']);
        update_option('zoho_inventory_url', $_POST['zoho_inventory_url']);
        update_option('authorization_redirect_uri', $_POST['authorization_redirect_uri']);
        $save_status = 'Zoho connection details stored.';

        ?>
		<head> <meta http-equiv="refresh" content="0; url=<?php $completeRedirectUrl = get_option('authorization_redirect_uri');
        $state = wp_create_nonce('redirect_url');
        $test = esc_url("https://accounts.zoho." . get_option('zoho_inventory_domain') . "/oauth/v2/auth?response_type=code&client_id=" . get_option('zoho_inventory_cid') . "&scope=ZohoInventory.FullAccess.all&redirect_uri=" . $completeRedirectUrl . "&prompt=consent&access_type=offline&state=" . $state);
        echo $test;?>"/> </head>
		<?php
}
}

if (isset($_POST['remove_connection'])) {
    $options = [
        'zoho_inventory_domain',
        'zoho_inventory_oid',
        'zoho_inventory_cid',
        'zoho_inventory_cs',
        'zoho_inventory_url',
    ];
    foreach ($options as $zi_option) {
        delete_option($zi_option);
    }
}

// zoho subscription id
$zoho_subscription_id = get_option('zoho_subscription_id');
// zoho domain.
$zoho_inventory_domain = get_option('zoho_inventory_domain');
// zoho organisation Id.
$zoho_inventory_oid = get_option('zoho_inventory_oid');
// zoho client Id.
$zoho_inventory_cid = get_option('zoho_inventory_cid');
// zoho client secret.
$zoho_inventory_cs = get_option('zoho_inventory_cs');
// Zoho inventory URL.
$zoho_inventory_url = get_option('zoho_inventory_url');
// Zoho authorization URL.
$authorization_redirect_uri = get_option('authorization_redirect_uri');

// Check connection status
if ($zoho_inventory_cs) {
    $url = $zoho_inventory_url . 'api/v1/organizations/?organization_id=' . $zoho_inventory_oid;

    $executeCurlCallHandle = new ExecutecallClass();
    $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
    $message = $json->message;
}

// Save Zoho Subscription ID
if (isset($_POST['save_subscription'])) {
    $fd = fopen(__DIR__.'/zoho-domain.txt','w+');

    update_option('zoho_subscription_id', $_POST['zoho_subscription_id']);

    $woocommerce = new Client(
        'https://roadmapstudios.com',
        'ck_6ade6d03f447f22d1ca34d3a3987936d57055302',
        'cs_e79f4189b2a4fdff560ec44583e2a36ab33a2ea9',
        [
            'version' => 'wc/v1',
            'query_string_auth' => true,
        ]
    );
    $zoho_subid = get_option('zoho_subscription_id');
    $endpoint = 'subscriptions/' . $zoho_subid;
    // $data = '{"zoho_domain_url": "' . $zoho_inventory_domain . '"}';
    try {
        $response = $woocommerce->get($endpoint);
        $result = $response->billing;

		fwrite($fd, PHP_EOL. print_r($response, true));
        fclose($fd);

        $customer_fname = $result->first_name;
        $customer_lname = $result->last_name;
        $customer_name = $customer_fname . ' ' . $customer_lname;
        $customer_email = $result->email;
        update_option('zi_customer_name', $customer_name);
        update_option('zi_customer_email', $customer_email);
    } catch (HttpClientException $e) {
        $errmessage = $e->getMessage();
        echo '<script>alert("' . $errmessage . '")</script>';
        // echo '<pre><code>' . print_r( $e->getRequest(), true ) . '</code><pre>'; // Last request data.
        // echo '<pre><code>' . print_r( $e->getResponse(), true ) . '</code><pre>'; // Last response data.
    }

}

$customername = get_option('zi_customer_name');

?>

<script>
	/**
	 * Function to show Rules popup.
	 *
	 */

	function readRules(){
		var htmlrules = document.createElement("body");
		htmlrules.innerHTML = '<strong>1. Never duplicate products.</strong><br><strong>2. When you remove a product in WooCommerce, also ensure you remove it in Zoho! Unless it has transactions, then ensure you set the product in “Draft” mode on both platforms. </strong><br><strong>3. Ensure all products have a Tax Rate before syncing, even if its 0% tax. Its required by the Zoho API.</strong></div>';
		htmlrules.classList.add("readrules");
		swal({
				icon: 'info',
				title: 'Rules to prevent issues',
				content: htmlrules,
			})

	}

</script>

<!--Settings page starts here-->
<h1 style="padding: 20px 0px;" ><center>Connect</center></h1>
<center><button id="readRules" class="button read-rules-animate" style="margin: 0px auto !important;" onclick="readRules()">Read Rules</button></center>

<div style="padding: 15px;" class="notice notice-error">Please read the documentation <a target="blank" href="https://support.roadmapstudios.com/portal/en/kb/zoho-inventory-woocommerce">here</a> first before you use this plugin and make sure to enable automatic updates for this plugin!
</div>

<?php
if (empty($zoho_inventory_cs)) {
    ?>
<div style="padding: 15px;" class="notice notice-error">Please visit the <a class="zm_a" href="https://accounts.zoho.com/developerconsole" target="_blank" rel="noopener">Zoho OAuth Creation</a> documentation page for usage instructions.</div>

<div class="notice" style="padding: 15px;">
<label for=""><h3>Organization ID: </h3></label>
<div>
	1. <a target="blank" href="https://inventory.zoho.com/app#/organizations">Get Org.id of .com account</a> <br/>
	2. <a target="blank" href="https://inventory.zoho.eu/app#/organizations">Get Org.id of .eu account</a>
</div>
</div>
<?php }?>

<?php
if ($zoho_inventory_oid && $zoho_inventory_cid && $zoho_inventory_cs) {
    ?>
<div style="padding: 15px;" class="notice zi-success">Connection Status: <?php echo $message; ?></div>
<?php } else {?>
	<div class="notice notice-error zi-notice-large">Connect with zoho inventory.</div>
<?php }?>


<form action="" method="post">
<div style="padding: 15px;" class="notice zi-success">Subscription ID:
<input type="text" value="<?php echo $zoho_subscription_id; ?>" name="zoho_subscription_id" id="zoho_subscription_id" placeholder="digits only" required />
<input
type="submit" class="button button-primary button-large" name="save_subscription" style="margin: 0px auto !important;" value="Save" />
<a href="https://roadmapstudios.com/account/subscriptions" target="_blank">Get ID here</a><br>
<?php if (empty($customername)) {?>
<em>This must be filled in to receive support!</em>
<?php }?>
<?php if ($errmessage) {echo $errmessage;}?>
</div>

<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<?php wp_nonce_field('zoho_inventory_settings_nonce');?>

<div class="row zoho_row">
<label for="zoho_inventory_domain">Domain </label>

<select name="zoho_inventory_domain" id="">
<?php foreach ($zoho_api_domains as $zoho_domain) {?>
<option
value="<?php echo $zoho_domain; ?>"
	<?php
if ($zoho_inventory_domain === $zoho_domain) {
    echo 'selected';}
    ?>
><?php echo '.' . $zoho_domain; ?></option>
<?php }
;?>
</select>

</div>
<div class="row zoho_row">
<label for="zoho_inventory_oid">Organization ID </label>
<input type="text" value="<?php echo $zoho_inventory_oid; ?>" name="zoho_inventory_oid" id="zoho_inventory_oid" required />
</div>
<div class="row zoho_row">
<label for="zoho_inventory_cid">Client ID </label>
<input type="text" value="<?php echo $zoho_inventory_cid; ?>" name="zoho_inventory_cid" id="zoho_inventory_cid" required />
</div>
<div class="row zoho_row">
<label for="zoho_inventory_cs">Client Secret </label>
<input type="text" value="<?php echo $zoho_inventory_cs; ?>" name="zoho_inventory_cs" id="zoho_inventory_cs" required />
</div>

<div class="row zoho_row">
<label for="zoho_inventory_url">Datacenter url </label>

<select name="zoho_inventory_url" id="">
<option value=""><--Select URL--></option>
<?php foreach ($zoho_api_urls as $zoho_url) {?>
<option
value="<?php echo $zoho_url; ?>"
	<?php
if ($zoho_inventory_url === $zoho_url) {
    echo 'selected';}
    ?>
><?php echo $zoho_url; ?></option>
<?php }
;?>
</select>

</div>
<div class="row zoho_row">
<label for="authorization_redirect_uri">Authorization Redirect URI </label>
<input type="text" value="<?php echo admin_url(); ?>admin.php?page=zoho-inventory" readonly="readonly" name="authorization_redirect_uri" id="authorization_redirect_uri" required /><br>
<i>Copy this URL into Redirect URI field of your Client Id creation</i>
</div>
<div class="row zoho_row">
<input
type="submit" class="button button-primary button-large"
name="zoho_submit" style="margin-left: 26% !important; float: left;" value="Authorize" />

<input
type="submit" class="button button-primary button-large"
name="remove_connection" style="margin-left: 16px; float: left;" value="Remove Connection" />
</div>
</form>

<div style="clear:both;"></div>

<style>
.swal-content {
  background-color: #FEFAE3;
  padding: 17px;
  border: 1px solid #F0E1A1;
  display: block;
  margin: 22px;
  text-align: center;
  color: #61534e;
}

.readrules {
	background-color: transparent;
	min-width: auto;
}

.read-rules-animate{
	animation: readRules 1s 3 ease-in-out;
}

@keyframes readRules{
	0% {
		background-color: red;
    	color: #ffffff;
    	border-color: red;
    	width: 86px;
    	height: 30px;
	}
	50% {
		color: #000000;
	}
	100% {
		color: #2271b1;
		border-color: #2271b1;
		background: #f6f7f7;
	}
}

.zoho_row{ width:550px; margin:0 auto;}
.zoho_row label {
    width: 100%;
    display: inline-block;
    font-weight: 700;
    margin: 12px 0px 8px;
}
.zoho_row input[type="text"],
.zoho_row select {width: 100%; max-width: 100%;}
.zoho_row input[type="submit"]{width: auto; margin: 20px auto; display: block;
}
.zoho_row input[type="button"]{width: auto; margin: 20px 5px; display: block;
}
.button{
	margin-left:10px !important;
}
.item_id {
	width	:25%;
}
#request_status {
	text-align:center;
}
/* CSS for Loader */
.loader {
 border: 5px solid #ffffff;
 border-radius: 50%;
 border-top: 5px solid #000000;
 width: 20px;
 height: 20px;
 -webkit-animation: spin 2s linear infinite; /* Safari */
 animation: spin 2s linear infinite;
 /* margin-left: 35%; */
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
/* Close CSS Loader */
</style>
