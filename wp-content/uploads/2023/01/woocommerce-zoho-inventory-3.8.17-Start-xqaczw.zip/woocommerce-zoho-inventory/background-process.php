<?php

/**
 * Here we load our custom Class for background queue
 *
 * @category Zoho_Integration
 * @package  WooZo_Inventory
 * @author   Roadmap Studios <info@roadmapstudios.com>
 * @license  GNU General Public License v3.0
 * @link     https://roadmapstudios.com
 */
require RMS_DIR_PATH . 'lib/wp-background-process/wp-background-processing.php';
require_once WP_PLUGIN_DIR . DIRECTORY_SEPARATOR . 'woocommerce/woocommerce.php';

if (!class_exists('WP_Zoho_Background_Process')) {
    class WP_Zoho_Background_Process extends WP_Background_Process_new
    {
        /**
         * @var string
         */
        protected $action = 'zoho_background_process';

        /**
         * Type of synchronization
         *
         * @var string item/contact
         */
        protected $sync_type = '';

        /**
         * Initiate new background process
         */
        public function __construct($type)
        {
            parent::__construct($type);
            $this->sync_type = $type;
        }

        /**
         * Function to get product dimensions.
         *
         * @param object $product - Product objects.
         * @return mixed - array of dimensions or false.
         */
        protected function getProductdimensions($product)
        {
            $details_sync_status = get_option('zoho_enable_details_sync_status');
            if ($details_sync_status) {
                $dimensions = (object) array();
                $dimensions->length = $product->get_length();
                $dimensions->width = $product->get_width();
                $dimensions->height = $product->get_height();
                $dimensions->weight = $product->get_weight();
                return $dimensions;
            } else {
                return false;
            }
        }

        /**
         * Task
         *
         * Override this method to perform any actions required on each
         * queue item. Return the modified item for further processing
         * in the next pass through. Or, return false to remove the
         * item from the queue.
         *
         * @param mixed $item Queue item to iterate over.d
         *
         * @return mixed
         */
        protected function task($item)
        {
            // $fd = fopen(__DIR__.'/task.txt','a+');
            $response = (object) array(
                'code' => 400,
                'status' => false,
                'message' => 'SUCCESS',
            );
            // fwrite($fd,PHP_EOL.'Task : '.print_r($item, true));
            if (!($item instanceof WP_Post)) {
                return $response;
            }
            // Actions to perform
            if ($item && !$item->ID) {
                $response->message = 'Item Id not found';
                return $response;
            }

            $proid = $item->ID;
            $product = wc_get_product($proid);

            if ($product->is_type('variable')) {
                $response->message = $this->zi_find_matching_product_variation($proid);
            } else {

                //$image         = wp_get_attachment_image_src( get_post_thumbnail_id( $item->ID ), 'single-post-thumbnail' );
                $val['priceR'] = get_post_meta($proid, '_regular_price', true);
                $val['priceS'] = get_post_meta($proid, '_sale_price', true);
                //$val['image']  = $image[0];
                //$val['ext']    = pathinfo( $image[0], PATHINFO_EXTENSION );

                $item_name = $product->get_title();
                $name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);
                $sku = $item->_sku;
                // fwrite($fd,PHP_EOL.'$name : '. $name);
                if ($product->is_virtual('yes')) {
                    $product_type = 'service';
                    $item_type = 'sales';
                } else {
                    $product_type = 'goods';
                    $item_type = 'inventory';
                }

                $tax_rates = array();
                $tax_rates = WC_Tax::get_base_tax_rates($product->get_tax_class());
                $tax_id_key = '';
                foreach ($tax_rates as $tax_key => $tax_value) {
                    $tax_id_key = $tax_key;
                    break;
                }
                $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
                $tax_id = explode('##', $tax_option)[0];

                if (!empty($tax_rates)) {
                    $tax_rate = reset($tax_rates);
                }

                if ($val['priceS']) {
                    $rate = $val['priceS'];
                } else {
                    $rate = $val['priceR'];
                }

                //$image = $val['image'];
                //$ext   = $val['ext'];

                $pdt1 = '{"name" : "' . $name . '", "product_type" : "' . $product_type . '","tax_id" : "' . $tax_id . '","rate" : "' . $rate . '","sku" : "' . $sku . '","item_type" : "' . $item_type . '","unit" : "pcs"';
                // If zoho category id is not mapped to product, then assign mapped product category with zoho

                $in_stock = $product->get_stock_quantity();
                if ($in_stock > 0) {
                    $pdt1 .= ',"initial_stock" : "' . $in_stock . '"';
                    $pdt1 .= ',"initial_stock_rate" : "' . $in_stock . '"';
                }

                $zi_category_id = $this->get_prod_updated_category($proid);
                if ($zi_category_id) {
                    $pdt1 .= ',"category_id" : "' . $zi_category_id . '"';
                }

                // Dimensions data append to update call.
                $product_dimensions = $this->getProductdimensions($product);
                if ($product_dimensions) {
                    $pdt1 .= ',"package_details" : ' . json_encode($product_dimensions);
                }

                $pdt1 .= '}';
                $handlefunction = new Classfunctions;
                $zoho_inventory_oid = get_option('zoho_inventory_oid');
                $zoho_inventory_url = get_option('zoho_inventory_url');
                $zoho_inventory_access_token = get_option('zoho_inventory_access_token');
                $zoho_inventory_refresh_token = get_option('zoho_inventory_refresh_token');
                $zoho_inventory_timestamp = get_option('zoho_inventory_timestamp');
                $current_time = strtotime(date('Y-m-d H:i:s'));

                if ($zoho_inventory_timestamp < $current_time) {

                    $respoAtJs = $handlefunction->GetServiceZIRefreshToken($zoho_inventory_refresh_token);

                    $zoho_inventory_access_token = $respoAtJs['access_token'];
                    update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
                    update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);
                }

                $data = array(
                    'JSONString' => $pdt1,
                    'organization_id' => $zoho_inventory_oid,
                );
                $zoho_itemId = get_post_meta($proid, 'zi_item_id', true);

                if (!empty($zoho_itemId)) {
                    $pdt3 = '"rate" : "' . $rate . '",';
                    $pdt3 .= '"tax_id" : "' . $tax_id . '",';
                    $pdt3 .= '"name" : "' . $name . '"';
                    $zi_category_id = $this->get_prod_updated_category($proid);
                    if ($zi_category_id) {
                        // If zoho category id mapped to woo product then pass same category id for api call.
                        $pdt3 = '"category_id" : "' . $zi_category_id . '",' . $pdt3;
                    } else {
                        // If zoho category id is not mapped to product, then assign mapped product category with zoho.
                        $zi_category_id = get_post_meta($proid, 'zi_category_id', true);
                        if ($zi_category_id) {
                            $pdt3 .= '"category_id" : "' . $zi_category_id . '",' . $pdt3;
                        }
                    }
                    // dimensions data append to add call.
                    if ($product_dimensions) {
                        $pdt3 = '"package_details" : ' . json_encode($product_dimensions) . ',' . $pdt3;
                    }
                    $update_resp = $this->product_zoho_update_inventory_post($proid, $zoho_itemId, $pdt3);
                    $response->message = $update_resp->message;
                    $response->code = $update_resp->code;
                    $errmsg = $update_resp->message;
                    update_post_meta($proid, 'zi_product_errmsg', $errmsg);
                } else {
                    $url = $zoho_inventory_url . 'api/v1/items';
                    $curl = curl_init($url);

                    curl_setopt_array(
                        $curl,
                        array(
                            CURLOPT_POST => 1,
                            CURLOPT_POSTFIELDS => $data,
                            CURLOPT_HTTPHEADER => array(
                                "Authorization: Bearer " . $zoho_inventory_access_token,
                                'Content-Type:multipart/form-data',
                            ),
                            CURLOPT_RETURNTRANSFER => true,
                        )
                    );

                    $result = curl_exec($curl);

                    $json = json_decode($result);
                    $code = $json->code;
                    $response->message = $json->message;
                    $errmsg = $json->message;
                    update_post_meta($proid, 'zi_product_errmsg', $errmsg);

                    if ($code == '0' || 0 == $code) {
                        $this->add_item_meta_data($json->item, $proid);
                    }
                    // Checking if item with same sku is available in zoho inventory.
                    if ($code == '1001' || $code == 1001) {
                        $sku_check = str_replace(" ", "+", $sku);
                        $url = $zoho_inventory_url . 'api/v1/items?organization_id=' . $zoho_inventory_oid . '&search_text=' . $sku_check;

                        $curl = curl_init($url);
                        curl_setopt_array(
                            $curl,
                            array(
                                CURLOPT_HTTPHEADER => array(
                                    "Authorization: Bearer " . $zoho_inventory_access_token,
                                    'Content-Type:multipart/form-data',
                                ),
                                CURLOPT_RETURNTRANSFER => true,
                            )
                        );

                        $result = curl_exec($curl);
                        $json = json_decode($result);
                        if ($code == '0' || $code == 0) {
                            // $json->items[0]: first item of items array because filter with sku is always having one item.
                            $this->add_item_meta_data($json->composite_items[0], $proid);
                        }
                        $response->message = $json->message;
                        $errmsg = $json->message;
                        update_post_meta($proid, 'zi_product_errmsg', $errmsg);
                    }
                    $response->code = $json->code;
                }
            } //variable product end
            // fwrite($fd,PHP_EOL.'Response : '.print_r($response, true));
            // fclose($fd);
            return $response;
        }

        /**
         * Find matching product variation
         *
         * @param WC_Product $product - Woo Product object.
         * @param array      $attributes - Filter attribute.
         * @return int Matching variation ID or 0.
         */
        protected function zi_find_matching_product_variation($post_id)
        {
            $product_variable = wc_get_product($post_id);
            $item_name = $product_variable->get_title();
            $name = preg_replace('/[^A-Za-z0-9\-]/', '', $item_name);

            $tax_rates = WC_Tax::get_base_tax_rates($product_variable->get_tax_class());
            $tax_id_key = '';
            foreach ($tax_rates as $tax_key => $tax_value) {
                $tax_id_key = $tax_key;
                break;
            }
            $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
            $tax_id = explode('##', $tax_option)[0];

            $zi_category_id = $this->get_prod_updated_category($post_id);

            $zidata = '"group_name" : "' . $name . '", "unit" : "pcs", "tax_id" : "' . $tax_id . '","category_id" : "' . $zi_category_id . '",';

            // attributes
            $zi_enable_attributes_sync = get_option('zoho_enable_attributes_sync_status');
            if ($zi_enable_attributes_sync) {
                $attributes = $product_variable->get_attributes();
                $attributeName1 = '';
                $attributeName2 = '';
                $attributeName3 = '';
                foreach ($attributes as $attribute) {
                    $attrname = $attribute->get_name();
                    // If attrname is not empty.
                    if (!empty($attrname)) {
                        if (empty($attributeName1)) {
                            $attributeName1 = $attrname;
                        } elseif (empty($attributeName2)) {
                            $attributeName2 = $attrname;
                        } elseif (empty($attributeName3)) {
                            $attributeName3 = $attrname;
                        }
                    }
                }

                if (!empty($attributeName1)) {
                    $zidata = $zidata . '"attribute_name1": "' . $attributeName1 . '",';
                }
                if (!empty($attributeName2)) {
                    $zidata = $zidata . '"attribute_name2": "' . $attributeName2 . '",';
                }
                if (!empty($attributeName3)) {
                    $zidata = $zidata . '"attribute_name3": "' . $attributeName3 . '",';
                }
            } // end of check attributes

            $available_variations = $product_variable->get_available_variations();
            if (count($available_variations) > 0) {
                foreach ($available_variations as $child_data) {

                    $product_variable = wc_get_product($child_data['variation_id']);
                    $product_name = $product_variable->get_name();
                    $items[] = $this->sync_variants_products($product_variable, $child_data['variation_id'], $attributeName1, $attributeName2, $attributeName3);
                }
            }

            $zidata .= '"items" :[' . implode(',', $items) . ']';

            $handlefunction = new Classfunctions;
            $zoho_inventory_oid = get_option('zoho_inventory_oid');
            $zoho_inventory_url = get_option('zoho_inventory_url');
            $zoho_inventory_access_token = get_option('zoho_inventory_access_token');
            $zoho_inventory_refresh_token = get_option('zoho_inventory_refresh_token');
            $zoho_inventory_timestamp = get_option('zoho_inventory_timestamp');
            $current_time = strtotime(date('Y-m-d H:i:s'));

            if ($zoho_inventory_timestamp < $current_time) {
                $respoAtJs = $handlefunction->GetServiceZIRefreshToken($zoho_inventory_refresh_token);
                $zoho_inventory_access_token = $respoAtJs['access_token'];
                update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
                update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);
            }

            $data = array(
                'JSONString' => '{' . $zidata . '}',
                'organization_id' => $zoho_inventory_oid,
            );

            $zoho_groupId = get_post_meta($post_id, 'zi_item_id', true);

            if (!empty($zoho_groupId)) {

                $item_name = $product_variable->get_title();
                $name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);

                $url = $zoho_inventory_url . 'api/v1/itemgroups/' . $zoho_groupId;
                curl_setopt_array($curl_p, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "PUT",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer " . $zoho_inventory_access_token,
                        "cache-control: no-cache",
                        "postman-token: eb4923f2-b761-1fda-0e78-1b6abe47af9a",
                    ),
                ));

                $response = curl_exec($curl_p);
                $err = curl_error($curl_p);
                curl_close($curl_p);
                if ($err) {
                    $json_p = json_decode($err);
                } else {
                    $json_p = json_decode($response);
                }
                $code = $json_p->code;
                $errmsg = $json_p->message;
                update_post_meta($post_id, 'zi_product_errmsg', $errmsg);
            } else {
                $url = $zoho_inventory_url . 'api/v1/itemgroups';
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer " . $zoho_inventory_access_token,
                        "cache-control: no-cache",
                        "postman-token: a0c7db82-e7c6-9936-9012-b07c32e26e36",
                    ),
                ));

                $result = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);
                if ($err) {
                    $json = json_decode($err);
                } else {
                    $json = json_decode($result);
                }

                $code = $json->code;
                $errmsg = $json->message;
                update_post_meta($post_id, 'zi_product_errmsg', $errmsg);
                if ($code == '0' || $code == 0) {
                    $childItems = array();
                    foreach ($json->item_group as $key => $value) {
                        if ($key == 'group_id') {
                            $group_id = $value;
                        }
                        if ($key == 'items') {
                            foreach ($value as $key2 => $val2) {
                                $zi_name = str_replace(' ', '-', $val2->name);
                                $zi_name = $val2->name;
                                $childItems[$zi_name] = $val2->item_id;
                            }
                        }
                    }
                    if (!empty($group_id)) {
                        update_post_meta($post_id, 'zi_item_id', $group_id);
                    }

                    foreach ($available_variations as $child_data) {
                        $product_variable = wc_get_product($child_data['variation_id']);
                        $pname = '';
                        foreach ($product_variable->get_variation_attributes() as $taxonomy => $terms_slug) {
                            $pname .= $terms_slug;
                        }
                        $product_name = $product_variable->get_name();
                        $vname = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                        $product_key = $vname . '-' . $pname;
                        update_post_meta($child_data['variation_id'], 'zi_item_id', $childItems[$product_key]);
                    }
                }
            } // end of new grouped item
        }

        protected function sync_variants_products($product_variable, $post_id, $attr1 = '', $attr2 = '', $attr3 = '')
        {

            $zi_enable_attributes_sync = get_option('zoho_enable_attributes_sync_status');

            $attributes = $product_variable->get_variation_attributes();
            $arrtibuteString = '';
            if (!empty($attr1)) {
                $attr_key = strtolower($attr1);
                $attr_key = 'attribute_' . $attr_key;
                $arrtibuteString .= '"attribute_option_name1": "' . $attributes[$attr_key] . '",';
            }
            if (!empty($attr2)) {
                $attr_key = strtolower($attr2);
                $attr_key = 'attribute_' . $attr_key;
                $arrtibuteString .= '"attribute_option_name2": "' . $attributes[$attr_key] . '",';
            }
            if (!empty($attr3)) {
                $attr_key = strtolower($attr3);
                $attr_key = 'attribute_' . $attr_key;
                $arrtibuteString .= '"attribute_option_name3": "' . $attributes[$attr_key] . '",';
            }

            $pname = '';
            foreach ($product_variable->get_variation_attributes() as $taxonomy => $terms_slug) {

                $pname .= $terms_slug;
            }

            $item_name = $product_variable->get_name();
            $vname = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);
            if ($zi_enable_attributes_sync) {
                $name = $vname;
            } else {
                $name = $vname . '-' . $pname;
            }
            $rateR = $product_variable->get_regular_price();
            $rateS = $product_variable->get_sale_price();
            if ($product_variable->is_virtual('yes')) {
                $product_type = 'service';
                $item_type = 'sales';
            } else {
                $product_type = 'goods';
                $item_type = 'inventory';
            }
            $sku = $product_variable->get_sku();
            $in_stock = $product_variable->get_stock_quantity();

            if ($rateS) {
                $rate = $rateS;
            } else {
                $rate = $rateR;
            }

            $tax_rates = WC_Tax::get_base_tax_rates($product_variable->get_tax_class());
            $tax_id_key = '';
            foreach ($tax_rates as $tax_key => $tax_value) {
                $tax_id_key = $tax_key;
                break;
            }
            $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
            $tax_id = explode('##', $tax_option)[0];

            $zi_status = ('publish' === get_post_status($post_id)) ? 'active' : 'inactive';

            $zoho_itemId = get_post_meta($post_id, 'zi_item_id', true);

            // request data for adding/updating value to zoho.
            $zidata = '';
            if (!empty($arrtibuteString) && $zi_enable_attributes_sync) {
                $zidata .= $arrtibuteString;
            }
            $zidata .= '"name" : "' . $name . '",';
            $zidata .= '"product_type" : "' . $product_type . '",';
            $zidata .= '"sku" : "' . $sku . '",';
            $zidata .= '"item_type" : "' . $item_type . '",';
            $zidata .= '"unit" : "pcs",';
            $zidata .= '"status" : "' . $zi_status . '",';
            $zidata .= '"rate" : "' . $rate . '",';
            $zidata .= '"tax_id" : "' . $tax_id . '",';
            if (empty($zoho_itemId) && $in_stock > 0) {
                $zidata .= '"purchase_rate" : "1",';
                $zidata .= '"initial_stock" : ' . $in_stock . ',';
                $zidata .= '"initial_stock_rate" : ' . $in_stock . ',';
            }

            // dimensions
            $details_sync_status = get_option('zoho_enable_details_sync_status');
            if ($details_sync_status) {
                $dimensions = (object) array();
                $dimensions->length = $product_variable->get_length();
                $dimensions->width = $product_variable->get_width();
                $dimensions->height = $product_variable->get_height();
                $dimensions->weight = $product_variable->get_weight();
                if (!empty($dimensions)) {
                    $zidata .= '"package_details" : ' . json_encode($dimensions);
                }
            }
            if (!empty($zoho_itemId)) {
                $update_error_msg = $this->product_zoho_update_inventory_post($post_id, $zoho_itemId, $zidata);
                $zidataa = '';
                return $zidataa .= '{' . $zidata . '}';
            } else {
                $zidataa = '';
                return $zidataa .= '{' . $zidata . '}';
            }

        }

        /**
         * Function to get zoho category id from option value of category (terms) assigned to woocommerce product.
         *
         * @return void
         */
        protected function get_prod_updated_category($product_id)
        {
            // Check if product category already synced.
            $terms = array();
            $terms = get_the_terms($product_id, 'product_cat');
            if (count($terms) > 0) {
                foreach ($terms as $term) {
                    $product_cat_id = $term->term_id;
                    $zoho_cat_id = get_option("zoho_id_for_term_id_{$product_cat_id}");
                    if ($zoho_cat_id) {
                        break;
                    }
                }
            }
            // Check if product has already mapped category.
            if (empty($zoho_cat_id)) {
                $zoho_cat_id = get_post_meta($product_id, 'zi_category_id', true);
            }

            if ($zoho_cat_id) {
                return $zoho_cat_id;
            } else {
                return false;
            }
        }
        /**
         * Function for adding/updating metadata of item
         *
         * @param [object] $item Object of item return by zoho.
         * @param [string] $proid Product id of woocommerce to add metadata of it.
         * @return void
         */
        private function add_item_meta_data($item, $proid)
        {
            foreach ($item as $key => $value) {
                if ($key == 'item_id' || $key == 'composite_item_id' || $key == 'group_id') {
                    $item_id = $value;
                }
                if ($key == 'purchase_account_id') {
                    $purchase_account_id = $value;
                }
                if ($key == 'account_id') {
                    $account_id = $value;
                }
                if ($key == 'account_name') {
                    $account_name = $value;
                }
                if ($key == 'inventory_account_id') {
                    $inventory_account_id = $value;
                }
                if ($key == 'category_id' && !empty($value)) {
                    update_post_meta($proid, 'zi_category_id', $value);
                }
            }

            update_post_meta($proid, 'zi_item_id', $item_id);
            update_post_meta($proid, 'zi_purchase_account_id', $purchase_account_id);
            update_post_meta($proid, 'zi_account_id', $account_id);
            update_post_meta($proid, 'zi_account_name', $account_name);
            update_post_meta($proid, 'zi_inventory_account_id', $inventory_account_id);
        }

        /**
         * Update zoho composite item
         *
         * @param string $comp_item_id - Composite item id to update.
         * @param string $item_data - JSON string of composite item data.
         * @return string - zoho response message.
         */
        protected function update_composite_item_to_zoho($comp_item_id, $item_data)
        {
            $handlefunction = new Classfunctions;
            $zoho_inventory_oid = get_option('zoho_inventory_oid');
            $zoho_inventory_url = get_option('zoho_inventory_url');
            $zoho_inventory_access_token = get_option('zoho_inventory_access_token');
            $zoho_inventory_refresh_token = get_option('zoho_inventory_refresh_token');
            $zoho_inventory_timestamp = get_option('zoho_inventory_timestamp');
            $current_time = strtotime(date('Y-m-d H:i:s'));

            if ($zoho_inventory_timestamp < $current_time) {

                $respoAtJs = $handlefunction->GetServiceZIRefreshToken($zoho_inventory_refresh_token);

                $zoho_inventory_access_token = $respoAtJs['access_token'];
                update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
                update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);
            }

            $url = $zoho_inventory_url . 'api/v1/compositeitems/' . $comp_item_id;
            $data = array(
                'JSONString' => $item_data,
                'organization_id' => $zoho_inventory_oid,
            );
            $curl = curl_init($url);

            curl_setopt_array(
                $curl,
                array(
                    CURLOPT_POSTFIELDS => $data,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer " . $zoho_inventory_access_token,
                    ),
                )
            );

            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
            $put = curl_exec($curl);
            $json = json_decode($put);
            return $json;
        }

        /**
         * Function to update zoho item if already exists.
         *
         * @param number $proid - product number.
         * @param number $item_id - zoho item id.
         * @param mixed  $pdt3 - Zoho item object for post request.
         * @return string
         */
        protected function product_zoho_update_inventory_post($proid, $item_id, $pdt3)
        {
            $handlefunction = new Classfunctions;
            $zoho_inventory_oid = get_option('zoho_inventory_oid');
            $zoho_inventory_url = get_option('zoho_inventory_url');
            $zoho_inventory_access_token = get_option('zoho_inventory_access_token');
            $zoho_inventory_refresh_token = get_option('zoho_inventory_refresh_token');
            $zoho_inventory_timestamp = get_option('zoho_inventory_timestamp');
            $current_time = strtotime(date('Y-m-d H:i:s'));

            if ($zoho_inventory_timestamp < $current_time) {

                $respoAtJs = $handlefunction->GetServiceZIRefreshToken($zoho_inventory_refresh_token);

                $zoho_inventory_access_token = $respoAtJs['access_token'];
                update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
                update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);
            }
            $url_p = $zoho_inventory_url . 'api/v1/items/' . $item_id;
            $data_p = array(
                'JSONString' => '{' . $pdt3 . '}',
                'organization_id' => $zoho_inventory_oid,
            );
            $curl_p = curl_init($url_p);

            curl_setopt_array(
                $curl_p,
                array(
                    CURLOPT_POSTFIELDS => $data_p,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer " . $zoho_inventory_access_token,
                    ),
                    CURLOPT_RETURNTRANSFER => true,
                )
            );

            curl_setopt($curl_p, CURLOPT_CUSTOMREQUEST, 'PUT');
            $put = curl_exec($curl_p);
            $json_p = json_decode($put);
            return $json_p;
        }

        /**
         * Complete
         *
         * Override if applicable, but ensure that the below actions are
         * performed, or, call parent::complete().
         */
        protected function complete()
        {
            parent::complete();
            // Show notice to user or perform some other arbitrary task...
        }

        /**
         * Function to sync contact from woocommerce to zoho.
         *
         * @param mixed $user - user object to sync with zoho.
         * @return mixed
         */
        protected function syncContact($user)
        {
            $response_obj = (object) array(
                'code' => 400,
                'status' => false,
                'message' => 'SUCCESS',
            );
            if ($user && !$user->ID) {
                $response_obj->message = 'Contact id not found';
                return $response_obj;
            }
            $userid = $user->ID;
            $fname = get_user_meta($userid, 'first_name', true);
            $lname = get_user_meta($userid, 'last_name', true);
            $display_name = $user->display_name;
            $name = $fname . ' ' . $lname;
            $contact_name = ($name) ? $name : $display_name;
            $company_name = get_user_meta($userid, 'billing_company', true);
            $website = $user->user_url;
            $billing_address = get_user_meta($userid, 'billing_address_1', true);
            $billing_city = get_user_meta($userid, 'billing_city', true);
            $billing_state = get_user_meta($userid, 'billing_state', true);
            $billing_postcode = get_user_meta($userid, 'billing_postcode', true);
            $billing_country = get_user_meta($userid, 'billing_country', true);
            $shipping_address = get_user_meta($userid, 'shipping_address_1', true);
            $shipping_city = get_user_meta($userid, 'shipping_city', true);
            $shipping_state = get_user_meta($userid, 'shipping_state', true);
            $shipping_postcode = get_user_meta($userid, 'shipping_postcode', true);
            $shipping_country = get_user_meta($userid, 'shipping_country', true);
            $first_name = get_user_meta($userid, 'billing_first_name', true);
            $last_name = get_user_meta($userid, 'billing_last_name', true);
            $email = get_user_meta($userid, 'billing_email', true);
            $mobile = get_user_meta($userid, 'billing_phone', true);
            $is_primary_contact = 'true';
            $note = 'As a Customer';

            $user_details = get_user_meta($userid, 'zi_contact_id', true);

            if (!empty($user_details)) {
                $pdt2 = '"contact_name": "' . $contact_name . '","company_name": "' . $company_name . '","billing_address": { "address": "' . $billing_address . '","city": "' . $billing_city . '","state": "' . $billing_state . '","zip": "' . $billing_postcode . '","country": "' . $billing_country . '"},"shipping_address": { "address": "' . $shipping_address . '","city": "' . $shipping_city . '","state": "' . $shipping_state . '","zip": "' . $shipping_postcode . '","country": "' . $shipping_country . '"},"contact_persons": [{"first_name": "' . $first_name . '","last_name": "' . $last_name . '","phone": "' . $mobile . '","mobile": "' . $mobile . '","is_primary_contact": "' . $is_primary_contact . '"}],"notes": "' . $note . '"';
                $update_obj = $this->contact_zoho_user_infomation_update($user_details, $pdt2, $userid);

                $response_obj->message = $update_obj->message;
                $response_obj->code = $update_obj->code;
            } else {
                $handlefunction = new Classfunctions;
                $zoho_inventory_oid = get_option('zoho_inventory_oid');
                $zoho_inventory_url = get_option('zoho_inventory_url');
                $zoho_inventory_access_token = get_option('zoho_inventory_access_token');
                $zoho_inventory_refresh_token = get_option('zoho_inventory_refresh_token');
                $zoho_inventory_timestamp = get_option('zoho_inventory_timestamp');
                $current_time = strtotime(date('Y-m-d H:i:s'));

                if ($zoho_inventory_timestamp < $current_time) {

                    $respoAtJs = $handlefunction->GetServiceZIRefreshToken($zoho_inventory_refresh_token);

                    $zoho_inventory_access_token = $respoAtJs['access_token'];
                    update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
                    update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);
                }

                $pdt1 = '"contact_name": "' . $contact_name . '","company_name": "' . $company_name . '","billing_address": { "address": "' . $billing_address . '","city": "' . $billing_city . '","state": "' . $billing_state . '","zip": "' . $billing_postcode . '","country": "' . $billing_country . '"},"shipping_address": { "address": "' . $shipping_address . '","city": "' . $shipping_city . '","state": "' . $shipping_state . '","zip": "' . $shipping_postcode . '","country": "' . $shipping_country . '"},"contact_persons": [{"salutation": "Mr","first_name": "' . $first_name . '","last_name": "' . $last_name . '","email": "' . $email . '","phone": "' . $mobile . '","mobile": "' . $mobile . '","is_primary_contact": "' . $is_primary_contact . '"}],"notes": "' . $note . '"';

                $data = array(
                    'JSONString' => '{' . $pdt1 . '}',
                    'organization_id' => $zoho_inventory_oid,
                );
                $url = $zoho_inventory_url . 'api/v1/contacts';
                $curl = curl_init($url);
                curl_setopt_array(
                    $curl,
                    array(
                        CURLOPT_POST => 1,
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization: Bearer " . $zoho_inventory_access_token,
                        ),
                    )
                );

                $response = curl_exec($curl);

                $json = json_decode($response);

                $code = $json->code;
                $response_obj->code = $json->code;
                if ('0' == $code || 0 == $code) {
                    $this->update_customer_meta($json->contact, $userid);
                }
                $response_obj->message = $json->message;
            }
            return $response_obj;
        }

        /**
         * Function to update user metadata.
         *
         * @param mixed  $contact - zoho contact object to update user contact.
         * @param number $userid - woocommerce user id to update user meta.
         * @return void
         */
        protected function update_customer_meta($contact, $userid)
        {
            foreach ($contact as $key => $value) {
                if ($key == 'contact_id') {
                    $res['zi_contact_id'] = $value;
                }
                if ($key == 'primary_contact_id') {
                    $res['zi_primary_contact_id'] = $value;
                }
                if ($key == 'created_time') {
                    $res['zi_created_time'] = $value;
                }
                if ($key == 'last_modified_time') {
                    $res['zi_last_modified_time'] = $value;
                }
                if ($key == 'billing_address') {
                    $res['zi_billing_address_id'] = $value->address_id;
                }
                if ($key == 'shipping_address') {
                    $res['zi_shipping_address_id'] = $value->address_id;
                }
                if ($key == 'contact_persons') {
                    $res['zi_contact_persons_id'] = $value[0]->contact_person_id;
                }
            }

            foreach ($res as $key => $val) {
                update_user_meta($userid, $key, $val);
            }
        }

        /**
         * Zoho contact update
         *
         * @param number $customer_id - zoho customer id.
         * @param string $pdt4 - request data.
         * @param number $wc_userid - user id of woocommerce to update user.
         * @return string
         */
        protected function contact_zoho_user_infomation_update($customer_id, $pdt4, $wc_userid)
        {
            $handlefunction = new Classfunctions;

            $zoho_inventory_oid = get_option('zoho_inventory_oid');
            $zoho_inventory_url = get_option('zoho_inventory_url');
            $zoho_inventory_access_token = get_option('zoho_inventory_access_token');
            $zoho_inventory_refresh_token = get_option('zoho_inventory_refresh_token');
            $zoho_inventory_timestamp = get_option('zoho_inventory_timestamp');
            $current_time = strtotime(date('Y-m-d H:i:s'));

            if ($zoho_inventory_timestamp < $current_time) {

                $respoAtJs = $handlefunction->GetServiceZIRefreshToken($zoho_inventory_refresh_token);

                $zoho_inventory_access_token = $respoAtJs['access_token'];
                update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
                update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);
            }
            $url_u = $zoho_inventory_url . 'api/v1/contacts/' . $customer_id;

            $data_u = array(
                'JSONString' => '{' . $pdt4 . '}',
                'organization_id' => $zoho_inventory_oid,
            );

            $curl_u = curl_init($url_u);

            curl_setopt_array(
                $curl_u,
                array(
                    CURLOPT_POSTFIELDS => $data_u,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer " . $zoho_inventory_access_token,
                    ),
                )
            );

            curl_setopt($curl_u, CURLOPT_CUSTOMREQUEST, 'PUT');
            $putt = curl_exec($curl_u);

            $json_u = json_decode($putt);
            $code = $json_u->code;

            if ('0' == $code || 0 == $code) {
                $this->update_customer_meta($json_u->contact, $wc_userid);
            }

            return $json_u;
        }

        /**
         * syncBundleItem
         *
         * Override this method to perform any actions required on each
         * queue item. Return the modified item for further processing
         * in the next pass through. Or, return false to remove the
         * item from the queue.
         *
         * @param mixed $item Queue  bundle item to iterate over.
         *
         * @return mixed
         */
        protected function syncBundleItem($item)
        {
            $response = (object) array(
                'code' => 400,
                'status' => false,
                'message' => 'SUCCESS',
            );
            // Actions to perform
            if ($item && !$item->ID) {
                $response->message = 'ID not found';
                return $response;
            }
            $child_items = $this->getBundleChildToSync($item->ID);
            $val['priceR'] = get_post_meta($item->ID, '_regular_price', true);
            $val['priceS'] = get_post_meta($item->ID, '_sale_price', true);
            /*
            $image         = wp_get_attachment_image_src( get_post_thumbnail_id( $item->ID ), 'single-post-thumbnail' );
            $val['image']  = $image[0];
            $val['ext']    = pathinfo( $image[0], PATHINFO_EXTENSION );
             */
            $proid = $item->ID;
            $item_name = $item->post_title;
            $name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);
            $sku = $item->_sku;
            $product = wc_get_product($proid);
            if ($product->is_virtual('yes')) {
                $product_type = 'service';
                $item_type = 'sales';
            } else {
                $product_type = 'goods';
                $item_type = 'inventory';
            }
            $tax_rates = WC_Tax::get_base_tax_rates($product->get_tax_class());
            $tax_id_key = '';
            foreach ($tax_rates as $tax_key => $tax_value) {
                $tax_id_key = $tax_key;
                break;
            }
            $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
            $tax_id = explode('##', $tax_option)[0];
            if (!empty($tax_rates)) {
                $tax_rate = reset($tax_rates);
            }
            $in_stock = ($product->get_stock_quantity()) ? $product->get_stock_quantity() : 0;
            if ($val['priceS']) {
                $rate = $val['priceS'];
            } else {
                $rate = $val['priceR'];
            }

            //$image = $val['image'];
            //$ext   = $val['ext'];

            $pdt1 = '{"name" : "' . $name . '","mapped_items":' . json_encode($child_items) . ', "product_type" : "' . $product_type . '","tax_id" : "' . $tax_id . '","rate" : "' . $rate . '","sku" : "' . $sku . '","unit" : "pcs","item_type" : "' . $item_type . '"';
            // If zoho category id is not mapped to product, then assign mapped product category with zoho.
            $zi_category_id = $this->get_prod_updated_category($proid);

            if ($zi_category_id) {
                $pdt1 .= ',"category_id" : "' . $zi_category_id . '"';
            }

            $pdt1 .= ',"initial_stock" : "' . $in_stock . '"';
            $pdt1 .= ',"initial_stock_rate" : "' . $in_stock . '"';

            // Dimensions data append to update call.
            $product_dimensions = $this->getProductdimensions($product);
            if ($product_dimensions) {
                $pdt1 .= ',"package_details" : ' . json_encode($product_dimensions);
            }

            $pdt1 .= '}';
            $handlefunction = new Classfunctions;

            $zoho_inventory_oid = get_option('zoho_inventory_oid');
            $zoho_inventory_url = get_option('zoho_inventory_url');
            $zoho_inventory_access_token = get_option('zoho_inventory_access_token');
            $zoho_inventory_refresh_token = get_option('zoho_inventory_refresh_token');
            $zoho_inventory_timestamp = get_option('zoho_inventory_timestamp');
            $current_time = strtotime(date('Y-m-d H:i:s'));

            if ($zoho_inventory_timestamp < $current_time) {

                $respoAtJs = $handlefunction->GetServiceZIRefreshToken($zoho_inventory_refresh_token);

                $zoho_inventory_access_token = $respoAtJs['access_token'];
                update_option('zoho_inventory_access_token', $respoAtJs['access_token']);
                update_option('zoho_inventory_timestamp', strtotime(date('Y-m-d H:i:s')) + $respoAtJs['expires_in']);
            }
            $data = array(
                'JSONString' => $pdt1,
                'organization_id' => $zoho_inventory_oid,
            );
            $zoho_item_id = get_post_meta($proid, 'zi_item_id', true);
            if (!empty($zoho_item_id)) {
                $update_data_obj = (object) array(
                    'name' => $name,
                    'mapped_items' => $child_items,
                    'rate' => $rate,
                    'tax_id' => $tax_id,
                );
                $zi_category_id = $this->get_prod_updated_category($proid);
                if ($zi_category_id) {
                    // If zoho category id mapped to woo product then pass same category id for api call.
                    $update_data_obj->category_id = $zi_category_id;
                } else {
                    // If zoho category id is not mapped to product, then assign mapped product category with zoho.
                    $zi_category_id = get_post_meta($proid, 'zi_category_id', true);
                    if ($zi_category_id) {
                        $update_data_obj->category_id = $zi_category_id;
                    }
                }

                // Dimensions data append to composite item update call.
                if ($product_dimensions) {
                    $update_data_obj->package_details = $product_dimensions;
                }

                $update_resp = $this->update_composite_item_to_zoho($zoho_item_id, json_encode($update_data_obj));
                $response->code = $update_resp->code;
                $response->message = $update_resp->message;
            } else {
                $url = $zoho_inventory_url . 'api/v1/compositeitems';
                $curl = curl_init($url);
                $headers = array('Content-Type:multipart/form-data');
                curl_setopt_array(
                    $curl,
                    array(
                        CURLOPT_POST => 1,
                        CURLOPT_POSTFIELDS => $data,
                        CURLOPT_HTTPHEADER => array(
                            "Authorization: Bearer " . $zoho_inventory_access_token,
                            "Content-Type:multipart/form-data",
                        ),
                        CURLOPT_RETURNTRANSFER => true,
                    )
                );

                $result = curl_exec($curl);

                $json = json_decode($result);
                $code = $json->code;
                if ($code == '0' || 0 == $code) {
                    $response->code = 200;
                    $this->add_item_meta_data($json->composite_item, $proid);
                } else {
                    // Checking if item with same sku is available in zoho inventory.
                    if ($code == '1001' || $code == 1001) {
                        $url = $zoho_inventory_url . 'api/v1/compositeitems?authtoken=' . $zoho_inventory_key . '&organization_id=' . $zoho_inventory_oid . '&sku=' . $sku;
                        $json = $this->execute_get_curl_call($url);
                        $code = $json->code;

                        if ($code == '0' || $code == 0) {
                            $composite_item_id = $json->composite_items[0]->composite_item_id;
                            $url = "{$zoho_inventory_url}api/v1/compositeitems/$composite_item_id?authtoken=$zoho_inventory_key&organization_id=$zoho_inventory_oid";
                            $json = $this->execute_get_curl_call($url);
                            if ($json->code == '0' || 0 == $json->code) {
                                $response->code = 200;
                                $metadata = (object) array(
                                    'composite_item_id' => $json->composite_item->composite_item_id,
                                    'purchase_account_id' => $json->composite_item->purchase_account_id,
                                    'account_id' => $json->composite_item->account_id,
                                    'account_name' => $json->composite_item->account_name,
                                    'inventory_account_id' => $json->composite_item->inventory_account_id,
                                );
                                $this->add_item_meta_data($metadata, $proid);
                            }
                        }
                    }
                }
                $response->code = $json->code;
                $response->message = $json->message;
            }
            return $response;
        }

        /**
         * Execute curl call and return response as json.
         *
         * @param string $url - URL to execute.
         * @return object
         */
        protected function execute_get_curl_call($url)
        {
            $curl = curl_init($url);
            curl_setopt_array(
                $curl,
                array(
                    CURLOPT_RETURNTRANSFER => true,
                )
            );

            $result = curl_exec($curl);
            return json_decode($result);
        }

        /**
         * Get child product of for given product id.
         *
         * @param number $bundle_id - Bundle id for given product
         * @return mixed false on failed else return success.
         */
        protected function getBundleChildToSync($bundle_id)
        {
            $bundle_childs = WC_PB_DB::query_bundled_items(
                array(
                    'return' => 'id=>product_id',
                    'bundle_id' => array($bundle_id),
                )
            );
            $child_array = array();
            foreach ($bundle_childs as $child_id) {
                $meta_value = $this->zi_get_bundle_item_meta($child_id, $bundle_id, 'quantity_max');
                $zi_child_id = get_post_meta($child_id, 'zi_item_id', true);
                $json_child = (object) array(
                    'item_id' => $zi_child_id,
                    'quantity' => $meta_value[0]->meta_value,
                );
                array_push($child_array, $json_child);
            }
            return $child_array;
        }
        /**
         * Get array of metadata.
         *
         * @param number $bundle_item_id bundle item id.
         * @return mixed metadata.
         */
        private function zi_get_bundle_item_meta($bundle_item_id, $bundle_id, $meta_key = '')
        {
            global $wpdb;
            $table_meta = $wpdb->prefix . 'woocommerce_bundled_itemmeta';
            $table_item = $wpdb->prefix . 'woocommerce_bundled_items';
            if ('' !== $meta_key) {
                $meta_key = "AND meta_key='$meta_key'";
            }
            $metadata = $wpdb->get_results("SELECT meta_key, meta_value FROM $table_meta, $table_item WHERE $table_meta.bundled_item_id = $table_item.bundled_item_id AND product_id=$bundle_item_id AND bundle_id = $bundle_id $meta_key");

            if (count($metadata) > 0) {
                return $metadata;
            } else {
                false;
            }
        }

        protected function orderSync($jsonData)
        {
            // $fd = fopen(__DIR__.'/test.txt','a+');
            // fwrite($fd,PHP_EOL.'----------------------------------------');
            // fwrite($fd,PHP_EOL.'Time to Start:'.date('h:i:s'));
            // fwrite($fd,PHP_EOL.'BG Process started');
            // if(is_object($jsonData)){
            //     fwrite($fd,PHP_EOL.'Request Body : '.print_r($jsonData,true));
            // }
            // If order Id is blank return
            if (empty($jsonData) || empty($jsonData->JSONData) || empty($jsonData->userId)) {
                return;
            }
            $pdt1 = $jsonData->JSONData;
            $userid = $jsonData->userId;
            $orderid = $jsonData->orderid;
            $zoho_order_id = get_post_meta($orderid, 'zi_salesorder_id', true);
            if (!empty($zoho_order_id)) {
                return;
            }
            // fwrite($fd,PHP_EOL.'Request Body : '.print_r($jsonData,true));
            $zoho_inventory_oid = get_option('zoho_inventory_oid');
            $zoho_inventory_url = get_option('zoho_inventory_url');
            $enabled_auto_no = get_option('zoho_enable_auto_no_status');
            $ignore_auto_no = ('true' === $enabled_auto_no) ? 'false' : 'true';
            $data = array(
                'JSONString' => '{' . $pdt1 . '}',
                'organization_id' => $zoho_inventory_oid,
            );
            // fwrite($fd,PHP_EOL.'Request Body : '.'{' . $pdt1 . '}');
            $url = $zoho_inventory_url . 'api/v1/salesorders?ignore_auto_number_generation=' . $ignore_auto_no;

            $executeCurlCallHandle = new ExecutecallClass();
            $json = $executeCurlCallHandle->ExecuteCurlCallPost($url, $data);

            $code = $json->code;
            $notes = 'Zoho Order Sync: ' . $json->message;
            // fwrite($fd,PHP_EOL.'JSON Respoonse : '.print_r($json,true));
            $order = wc_get_order($orderid);
            if ($code == '0' || $code == 0) {
                foreach ($json->salesorder as $key => $value) {
                    if ($key == 'salesorder_id') {
                        $salesorder_id = $value;
                        $res['zi_salesorder_id'] = $value;
                        update_post_meta($orderid, 'zi_salesorder_id', $value);
                    }
                    if ($key == 'customer_id') {
                        $res['zi_customer_id'] = $value;
                    }
                }
            } else {
                // API request not processed properly add notes and return.
                $order->add_order_note($notes);
                $order->save();
                return;
            }
            // saleorder package code
            $zoho_package_status = get_option('zoho_package_zoho_sync_status');
            if ('true' == $zoho_package_status) {
                $packageCurlCallHandle = new PackageClass();
                $package_json = $packageCurlCallHandle->PackageCreateFunction($orderid, $json);
            }

            $order->add_order_note($notes);
            $order->save();
            // $errmsg = $json->message . ' WooCommerce  Order Id is : ' . $orderid . '<br/>';

            $zoho_enable_log = get_option('zoho_enable_log_status');
            if ($zoho_enable_log == 'true') {
                global $wpdb;
                $messages_table = $wpdb->prefix . 'zoho_ordersale_error';
                $timestamp = time();

                $logger = new WC_Logger();
                $logger->add('woozo-inventory-connect-salesorders', "{$orderid} {$json->message}");

                $order_log_array = array(
                    'user_id' => $userid,
                    'order_id' => $orderid,
                    'error_message' => $json->message,
                    'order_timestamp' => $timestamp,
                    'status' => 1,
                );
                $wpdb->insert(
                    $messages_table, $order_log_array, array('%d', '%d', '%s', '%s', '%d')
                );
            }
            //start logging
            // fclose($fd);
            // Return if process complete.
            return;
        }
    }}
