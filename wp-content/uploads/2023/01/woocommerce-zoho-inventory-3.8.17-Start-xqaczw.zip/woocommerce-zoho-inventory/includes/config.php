<?php
/**
 * The product_id for license activation
 */
$zi_plugin_prod_id = 26532; 
$zi_plugin_version = '3.8.17';
// Pro 20832; 
// Connect 12448;
// Start 26532;