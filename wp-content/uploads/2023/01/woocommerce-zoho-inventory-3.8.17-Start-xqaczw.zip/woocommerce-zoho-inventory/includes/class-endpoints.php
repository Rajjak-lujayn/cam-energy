<?php

/**
 * All Custom Enpdpoints are Here.
 *
 * @package  WooZo Inventory
 */

if (!defined('ABSPATH')) {
    exit;
}

global $zi_plugin_prod_id;
if (26532 === $zi_plugin_prod_id) {
    exit;
}

// If product class not exists then import that class.
if (!class_exists('ProductClass')) {
    require_once __DIR__ . '/classes/product-class.php';
}
if (!class_exists('ZI_CommonClass')) {
    require_once __DIR__ . '/classes/class-common.php';
}

/**
 * @description: endpoint to receive shipping status and process it in wpdb
 * @requires: wc custom order statuses plugin
 * @last_modified: 11-06-2020
 */

if (class_exists('Alg_WC_Custom_Order_Statuses')) {

    function zi_shipping_status_init_hook_function()
    {
        /* Add Enpoints for syncing */
        add_action('rest_api_init', 'receive_zoho_shipping_status');
    }
    add_action('init', 'zi_shipping_status_init_hook_function');

    function receive_zoho_shipping_status()
    {
        register_rest_route(
            'v2',
            '/zoho-shipping-status/',
            array(
                'methods' => WP_REST_Server::CREATABLE/* WP_REST_Server::READABLE */,
                'callback' => 'wp_get_zoho_order_data',
                'permission_callback' => '__return_true',
            )
        );
    }

    function wp_get_zoho_order_data()
    {
        $dir = dirname(plugin_dir_path(__FILE__), 1);
        $postdata = '';
        if ($_POST["JSONString"]) {
            $postdata = str_replace('\\', '', $_POST["JSONString"]);
            file_put_contents($dir . '/zi_shipping_status.txt', $postdata);
        } elseif ($_POST) {
            $postdata = str_replace('\\', '', $_POST);
            file_put_contents($dir . '/zi_shipping_status.txt', $postdata);
        }
        /*     $postdata = json_encode(file_get_contents('test_Data.txt')); */

        if (!empty($postdata)) {
            process_shipping_status($postdata);
            return new WP_REST_Response( 'Shipping Status Updated', 200 );
        } else {
            return array("code" => 500, "response" => "Error receiving webhook response");
        }
    }

    function process_shipping_status($postdata)
    {
        // start logging
        // $fd  = fopen(__DIR__ . '/shipping-status-webhook.txt', 'w+');

        $order_data = json_decode($postdata);
        if (!is_object($order_data) && !is_array($order_data)) {
            $order_data = json_decode($order_data);
        }

        if (!empty($order_data->salesorder)) {
            $salesorder = $order_data->salesorder;
            /* Getting Salesorder id */

            $salesorder_id = $salesorder->salesorder_id;
            $formatted_status = trim($salesorder->shipped_status_formatted);
            $ship_status = strtolower($formatted_status);
            // fwrite($fd, PHP_EOL . 'Ship status: '. $ship_status);
            $packages = $salesorder->packages;

            /* Customer Query to get Order Id */
            $order_statuses = wc_get_order_statuses();
            // fwrite($fd, PHP_EOL . 'WC Order Statuses: '. print_r($order_statuses, true));
            $args = array(
                'post_type' => 'shop_order',
                'post_status' => $order_statuses,
                'meta_query' => array(
                    array(
                        'key' => 'zi_salesorder_id',
                        'value' => $salesorder_id,
                    ),
                ),
            );
            $woo_order = new WP_Query($args);
            if (!empty($woo_order->posts)) {
                foreach ($woo_order->posts as $curr_order) {
                    $post_id = $curr_order->ID;
                }
            }

            /* Getting Packages if empty in response */
            if (empty($packages) && !empty($post_id)) {
                $zoho_inventory_oid = get_option('zoho_inventory_oid');
                $zoho_inventory_url = get_option('zoho_inventory_url');
                $package_url = $zoho_inventory_url . "api/v1/packages?organization_id=" . $zoho_inventory_oid;
                $executeCurlCallHandle = new ExecutecallClass();
                $json = $executeCurlCallHandle->ExecuteCurlCallGet($package_url);
                if ($json->code == 0 || $json->code == '0') {
                    $all_packages = $json->packages;
                    foreach ($all_packages as $packs) {
                        $order_id = $packs->salesorder_id;
                        if (trim($order_id) == trim($salesorder_id)) {
                            // $package_id = $packs->package_id;
                            $tracking_number = $packs->tracking_number;
                            if (empty($ship_status)) {
                                $ship_status = trim($packs->status);
                            }
                            update_post_meta($post_id, 'zi_tracking_number', $tracking_number);
                        }
                    }
                }
            } elseif (!empty($packages) && !empty($post_id)) {
                foreach ($packages as $package) {
                    /* getting all ship and trace data from package */
                    $tracking_number = $package->tracking_number;
                    // $package_number = $package->package_number;
                    $carrier = $package->carrier;
                    $status = $package->status;
                }
                if (empty($ship_status)) {
                    $ship_status = trim($status);
                }
                update_post_meta($post_id, 'zi_tracking_number', $tracking_number);
                update_post_meta($post_id, 'zi_shipping_carrier', $carrier);
            } else {
                if (!empty($post_id)) {
                    $error = 'Post id not available for this ' . $salesorder_id . ' sales order';
                }
                /* Sending_ordererror_email($salesorder_id,$error); */
                return array("code" => 300, "response" => "Failed", "error_message" => $error);
            }

            // process cancelled zoho orders
            if ('void' == trim($salesorder->status)) {
                $order = wc_get_order($post_id);
                $order->update_status('cancelled');
            }

            // process shipped status
            if (!empty($ship_status) && $post_id) {
                 $order_statuses = array_map('strtolower', $order_statuses);
                // fwrite($fd, PHP_EOL . 'process order_statuses: '. print_r($order_statuses, true));
                if (in_array($ship_status, $order_statuses)) {
                    $ship_status = remove_accents( $ship_status );
                    update_post_meta($post_id, 'zi_shipping_status', $ship_status);
                    $order = wc_get_order($post_id);
                    $order->update_status($ship_status);
                    // fwrite($fd, PHP_EOL . 'Done Process Ship Status: '. $ship_status);
                } else {
                    update_post_meta($post_id, 'zi_shipping_status', $ship_status);
                }
            }
            // fclose($fd);
            return array("code" => 200, "response" => "Success add tracking id and update shipped status");
        } else {
            return array("code" => 300, "response" => "No sales order response there");
        }
    }

    // Display the tracking number on My Order Detail page
    add_action('woocommerce_order_details_after_order_table', 'action_order_details_after_order_table', 10, 4);
    function action_order_details_after_order_table($order, $sent_to_admin = '', $plain_text = '', $email = '')
    {
        // Only on "My Account" > "Order View"
        if (is_wc_endpoint_url('view-order')) {
            $tracking_number = get_post_meta($order->get_id(), 'zi_tracking_number', true);
            $carrier = get_post_meta($order->get_id(), 'zi_shipping_carrier', true);
            if ($tracking_number) {
                printf(
                    '<p class="shipping-info">' .
                    __("Your Shipping Tracking Number is: %s", "woocommerce"),
                    '<strong>' . $tracking_number . '</strong><br>' . __("Carrier: ", "woocommerce") . '<strong>' . $carrier . '</strong></p>'
                );
            } else {
                return;
            }
        }
    }
} // end of shipping status endpoint

/**
 * @description: endpoint to receive product data and process it in wpdb
 * @last_modified: 11-06-2020
 */

function zi_productdata_init_hook_function()
{
    /* Add Enpoints for syncing */
    add_action('rest_api_init', 'receive_zoho_product_data');
}
add_action('init', 'zi_productdata_init_hook_function');

function receive_zoho_product_data()
{
    register_rest_route(
        'v2',
        '/zoho-product/',
        array(
            'methods' => WP_REST_Server::CREATABLE/* WP_REST_Server::READABLE */,
            'callback' => 'wp_get_zoho_product_data',
            'permission_callback' => '__return_true',
        )
    );
}

function wp_get_zoho_product_data()
{
    $dir = dirname(plugin_dir_path(__FILE__), 1);
    $postdata = '';
    if ($_POST["JSONString"]) {
        $postdata = str_replace('\\', '', $_POST["JSONString"]);
        file_put_contents($dir . '/zoho-product.txt', $postdata);
    } elseif ($_POST) {
        $postdata = str_replace('\\', '', $_POST);
        file_put_contents($dir . '/zoho-product.txt', $postdata);
    }
    if (!empty($postdata)) {
        zi_process_product_response($postdata);
    } else {
        return array("code" => 500, "response" => "Error receiving webhook response");
    }
}

function zi_process_product_response($postdata)
{

    // $fd = fopen(__DIR__ . '/webhook.txt', 'w+');
    // fwrite($fd, PHP_EOL . '------------------------------');
    $product_data = json_decode($postdata);
    // fwrite($fd, PHP_EOL . 'Row $group_id : ' . print_r($product_data, true));

    if (!is_object($product_data) && !is_array($product_data)) {
        $product_data = json_decode($product_data);
    }

    // Accounting stock mode check
    $accounting_stock = get_option('zoho_enable_accounting_stock_status');

    // variable item sync
    if (!empty($product_data->item)) {
        $item = $product_data->item;
        $item_id = $item->item_id;
        $item_name = $item->name;
        $item_price = $item->rate;
        $item_sku = $item->sku;
        $item_description = $item->description;
        $item_brand = $item->brand;
        $item_tags_hash = $item->custom_field_hash;
        $item_tags = $item_tags_hash->cf_tags;
        // fwrite($fd, PHP_EOL . '$item_tags_hash : ' . print_r($item_tags_hash, true));
        // Stock mode check
        if ($accounting_stock) {
            $item_stock = $item->available_for_sale_stock;
        } else {
            $item_stock = $item->actual_available_for_sale_stock;
        }
        $item_image = $item->image_name;
        $group_name = $item->group_name;
        $item_category = $item->category_name;
        $groupid = $item->group_id;
        // item package details
        $details = $item->package_details;
        $weight = floatval($details->weight);
        $length = floatval($details->length);
        $width = floatval($details->width);
        $height = floatval($details->height);

        // getting the admin user ID
        $query = new WP_User_Query(
            [
                'role' => 'Administrator',
                'count_total' => false,
            ]
        );
        $users = $query->get_results();
        if ($users) {
            $admin_author_id = $users[0]->ID;
        } else {
            $admin_author_id = '1';
        }

        global $wpdb;
        // fwrite($fd, PHP_EOL . '$groupid : ' . $groupid);
        if (!empty($groupid)) {
            $zi_disable_itemdescription_sync = get_option('zoho_disable_itemdescription_sync_status');
            if (!empty($item_description) && $zi_disable_itemdescription_sync != 'true') {
                // fwrite($fd, PHP_EOL . 'Item description update : ' . $item_description);
                $wpdb->update($tbl_prefix . 'posts', array('post_excerpt' => $item_description), array('ID' => $groupid), array('%s'), array('%d'));
            }

            // Tags
            if (!empty($item_tags)) {
                $final_tags = explode(',', $item_tags);
                wp_set_object_terms($groupid, $final_tags, 'product_tag');
            }

            // Brand
            if (!empty($item_brand)) {
                wp_set_object_terms($groupid, $item_brand, 'product_brand');
            }

            // fwrite($fd, PHP_EOL . 'Query : ' . 'SELECT * FROM ' . $wpdb->prefix . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $groupid . "'");
            // find parent variable product
            $row = $wpdb->get_row('SELECT * FROM ' . $wpdb->prefix . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $groupid . "'");
            $group_id = $row->post_id;
            // fwrite($fd, PHP_EOL . 'Row Data : ' . print_r($row, true));
            // fwrite($fd, PHP_EOL . 'Row $group_id : ' . $group_id);

            $rowItem = $wpdb->get_row('SELECT * FROM ' . $wpdb->prefix . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $item_id . "'");
            $variation_id = $rowItem->post_id;
            if ($variation_id) { // updating existing variations
                $variation = new WC_Product_Variation($variation_id);
                ## Set/save all other data

                // fwrite($fd, PHP_EOL . 'SKU : ' . $item->sku);
                // SKU
                // if (!empty($item->sku))
                //     $variation->set_sku($item->sku);

                // fwrite($fd, PHP_EOL . 'Price : ' . $item->rate);
                // Prices
                if (!empty($item->rate)) {
                    $variation->set_price($item->rate);
                }
                // fwrite($fd, PHP_EOL . 'Regular Price : ' . $item->rate);
                $variation->set_regular_price($item->rate);
                // Stock
                if (!empty($item_stock)) {
                    $variation->set_stock_quantity($item_stock);
                    $variation->set_manage_stock(true);
                    $variation->set_stock_status('');
                } else {
                    // fwrite($fd, PHP_EOL . 'Available Stock : false');
                    $variation->set_manage_stock(false);
                }
                // featured image
                $zi_disable_itemimage_sync = get_option('zoho_disable_itemimage_sync_status');
                if (!empty($item_image) && $zi_disable_itemimage_sync != 'true') {
                    // fwrite($fd, PHP_EOL . 'Sync Image' );
                    $imageClass = new ImageClass();
                    $imageClass->args_attach_image($item_id, $item_name, $variation_id, $item_image, $admin_author_id);
                }

                $variation->save(); // Save the data
            } else {
                $attribute_name11 = $item->attribute_option_name1;
                $attribute_name12 = $item->attribute_option_name2;
                $attribute_name13 = $item->attribute_option_name3;

                if (!empty($attribute_name11)) {

                    $attribute_arr[$item->attribute_name1] = $attribute_name11;
                }
                if (!empty($attribute_name12)) {

                    $attribute_arr[$item->attribute_name2] = $attribute_name12;
                }
                if (!empty($attribute_name13)) {

                    $attribute_arr[$item->attribute_name3] = $attribute_name13;
                }
                $variation_data = array(
                    'attributes' => $attribute_arr,
                    'sku' => $item->sku,
                    'regular_price' => $item->rate,
                    'stock_qty' => $item_stock,
                );

                $status = ($item->status == 'active') ? 'publish' : 'draft';
                $variation_post = array(
                    'post_title' => $item->name,
                    'post_name' => $item->name,
                    'post_status' => $status,
                    'post_parent' => $group_id,
                    'post_type' => 'product_variation',
                    'guid' => get_the_permalink($group_id),
                );
                // Creating the product variation
                $variation_id = wp_insert_post($variation_post);

                // Get an instance of the WC_Product_Variation object
                $variation = new WC_Product_Variation($variation_id);

                // Iterating through the variations attributes
                foreach ($variation_data['attributes'] as $attribute => $term_name) {
                    update_post_meta($variation_id, 'attribute_' . strtolower(str_replace(' ', '-', $attribute)), trim($term_name));
                    update_post_meta($variation_id, 'group_id_store', $group_id);
                }

                // SKU
                // TODO: import the fix from cron script and add it here

                // Prices
                $variation->set_regular_price($variation_data['regular_price']);
                $variation_sale_price = get_post_meta($variation_id, '_sale_price', true);
                if (empty($variation_sale_price)) {
                    $variation->set_price($variation_data['regular_price']);
                }

                // featured image
                $zi_disable_itemimage_sync = get_option('zoho_disable_itemimage_sync_status');
                if (!empty($item_image) && $zi_disable_itemimage_sync != 'true') {
                    $imageClass = new ImageClass();
                    $imageClass->args_attach_image($item_id, $item_name, $variation_id, $item_image, $admin_author_id);
                }

                // Stock
                if (!empty($variation_data['stock_qty'])) {
                    $variation->set_stock_quantity($variation_data['stock_qty']);
                    $variation->set_manage_stock(true);
                    $variation->set_stock_status('');
                } else {
                    $variation->set_manage_stock(false);
                }
                $variation->set_weight(''); // weight (reseting)
                $variation->save(); // Save the data
                update_post_meta($variation_id, 'zi_item_id', $item_id);

                // End group item add process
                unset($attribute_arr);
            }
            if ($variation_id) {
                // weight & dimensions
                update_post_meta($variation_id, '_weight', $weight);
                update_post_meta($variation_id, '_length', $length);
                update_post_meta($variation_id, '_width', $width);
                update_post_meta($variation_id, '_height', $height);
                update_post_meta($variation_id, '_weight_unit', $details->weight_unit);
                update_post_meta($variation_id, '_dimension_unit', $details->dimension_unit);
            }

            // Update attributes of variation
            $group_attrs = get_post_meta($group_id, '_product_attributes', true);
            // fwrite($fd, PHP_EOL . '$group_attrs : ' . print_r($group_attrs, true));
            if (is_array($group_attrs)) {
                $z = 1;
                foreach ($group_attrs as $key => $g_attr) {
                    $attribute_option_name = '';
                    if ($z == 1) {
                        $attribute_option_name = trim($item->attribute_option_name1);
                    } elseif ($z == 2) {
                        $attribute_option_name = trim($item->attribute_option_name2);
                    } elseif ($z == 3) {
                        $attribute_option_name = trim($item->attribute_option_name3);
                    }
                    $group_attr_value = $g_attr['value'];
                    if (!empty($group_attr_value)) {
                        // Attribute has more than one value.
                        if (strpos($group_attr_value, '|')) {
                            $attr_array = explode('|', $group_attr_value);
                            $trim_attr_array = array();
                            // Remove white space from attribute array.
                            foreach ($attr_array as $arr_val) {
                                $trim_attr_array[] = trim($arr_val);
                            }
                            // Create unique list of attribute.
                            if (!empty($trim_attr_array)) {
                                $trim_attr_array = array_unique($trim_attr_array);
                            }
                            // Skip if attribute already exists in array.
                            if (!in_array($attribute_option_name, $trim_attr_array)) {
                                $trim_attr_array[] = $attribute_option_name;
                                $group_attrs[$key]['value'] = implode(' | ', $trim_attr_array);
                            }
                        } else {
                            // Attribute has one value. Check if attribute is an existing attribute value.
                            if ($group_attr_value != $attribute_option_name) {
                                $group_attrs[$key]['value'] = $group_attr_value . ' | ' . $attribute_option_name;
                            }
                        }
                    } elseif (!empty($attribute_option_name)) {

                        $group_attrs[$key]['value'] = $attribute_option_name;
                    }
                    $z++;
                }
            }
            update_post_meta($group_id, '_product_attributes', $group_attrs);
            unset($group_attrs);
            // end of grouped item creation
        } else {
            // fwrite($fd, PHP_EOL . 'Insite simple items');
            // fwrite($fd, PHP_EOL . 'Item description Simple : ' . $item_description);
            $rowItem = $wpdb->get_row('SELECT * FROM ' . $wpdb->prefix . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $item_id . "'");
            $mapped_product_id = $rowItem->post_id;
            // simple product
            // fwrite($fd, PHP_EOL . 'Before Match check');
            $pdt_id = '';
            if (!empty($mapped_product_id)) {
                $pdt_id = $mapped_product_id;
                // Sync product name if that is allowed.
                $product_class = new ProductClass();
                $product_class->update_product_name($pdt_id, $item_name);
            } elseif (empty($item->is_combo_product)) {
                // fwrite($fd, PHP_EOL . 'Inside create product');
                $current_user = wp_get_current_user();
                if (!empty($current_user) && $current_user->ID) {
                    $admin_author_id = $current_user->ID;
                    // get admin user id who started the cron job.
                } else {
                    $admin_author_id = get_option('zi_cron_admin');
                }
                $product_class = new ProductClass();
                $pdt_id = $product_class->zi_product_to_woocommerce($item, $item_name);
                // fwrite($fd, PHP_EOL . 'After adding it : ' . $pdt_id);
            }

            // If there is product id then update metadata.
            if (!empty($pdt_id)) {
                update_post_meta($pdt_id, 'zi_item_id', $item_id);
                // fwrite($fd, PHP_EOL . 'Insite mappping metadata');
                update_post_meta($pdt_id, '_sku', $item_sku);

                // fwrite($fd, PHP_EOL . '$item_price : ' . $item_price);
                // price
                $sale_price = get_post_meta($pdt_id, '_sale_price', true);
                update_post_meta($pdt_id, '_regular_price', $item_price);
                if (empty($sale_price)) {
                    // fwrite($fd, PHP_EOL . 'Update pricing');
                    update_post_meta($pdt_id, '_price', $item_price);
                }

                // description
                $zi_disable_itemdescription_sync = get_option('zoho_disable_itemdescription_sync_status');
                if (!empty($item_description) && $zi_disable_itemdescription_sync != 'true') {
                    $the_post = array(
                        'ID' => $pdt_id, //the ID of the Post
                        'post_excerpt' => $item_description,
                    );
                    wp_update_post($the_post);
                }

                // Tags
                if (!empty($item_tags)) {
                    $final_tags = explode(',', $item_tags);
                    wp_set_object_terms($pdt_id, $final_tags, 'product_tag');
                }

                // Brand
                if (!empty($item_brand)) {
                    wp_set_object_terms($pdt_id, $item_brand, 'product_brand');
                }

                // stock
                $zi_stock_sync = get_option('zoho_stock_sync_status');
                if ($zi_stock_sync != 'true') {
                    // fwrite($fd, PHP_EOL . 'Inside1');
                    if ('NULL' !== gettype($item_stock)) {
                        // fwrite($fd, PHP_EOL . 'Inside1.1');
                        update_post_meta($pdt_id, "_manage_stock", "yes");
                        update_post_meta($pdt_id, '_stock', number_format($item_stock, 0, '.', ''));
                        if ($item_stock > 0) {
                            // fwrite($fd, PHP_EOL . 'Inside2');
                            $status = 'instock';
                            update_post_meta($pdt_id, '_stock_status', wc_clean($status));
                            wp_set_post_terms($pdt_id, $status, 'product_visibility', true);
                        } else {
                            // fwrite($fd, PHP_EOL . 'Inside3');
                            $backorder_status = get_post_meta($pdt_id, '_backorders', true);
                            $status = ($backorder_status === 'yes') ? 'onbackorder' : 'outofstock';
                            update_post_meta($pdt_id, '_stock_status', wc_clean($status));
                            wp_set_post_terms($pdt_id, $status, 'product_visibility', true);
                        }
                    }
                }
                // fwrite($fd, PHP_EOL . 'After stock');
                // weight & dimensions
                update_post_meta($pdt_id, '_weight', $weight);
                update_post_meta($pdt_id, '_length', $length);
                update_post_meta($pdt_id, '_width', $width);
                update_post_meta($pdt_id, '_height', $height);
                update_post_meta($pdt_id, '_weight_unit', $details->weight_unit);
                update_post_meta($pdt_id, '_dimension_unit', $details->dimension_unit);
                // featured image
                $zi_disable_itemimage_sync = get_option('zoho_disable_itemimage_sync_status');
                if (!empty($item_image) && $zi_disable_itemimage_sync != 'true') {
                    $imageClass = new ImageClass();
                    $imageClass->args_attach_image($item_id, $item_name, $pdt_id, $item_image, $admin_author_id);
                }
                // category
                if (!empty($item_category) && empty($group_name)) {
                    $term = get_term_by('name', $item_category, 'product_cat');
                    $term_id = $term->term_id;
                    if (empty($term_id)) {
                        $term = wp_insert_term($item_category, 'product_cat',
                            array(
                                'description' => 'Imported from zoho',
                                'parent' => 0,
                            )
                        );
                        $term_id = $term->term_id;
                    }
                    if (!is_wp_error($term_id) && isset($term->term_id)) {
                        $existingTerms = wp_get_object_terms($pdt_id, 'product_cat');
                        if ($existingTerms && count($existingTerms) > 0) {
                            $isTermsExist = zi_check_terms_exists($existingTerms, $term_id);
                            if (!$isTermsExist) {
                                update_post_meta($pdt_id, 'zi_category_id', $item->category_id);
                                wp_add_object_terms($pdt_id, $term_id, 'product_cat');
                            }
                        } else {
                            update_post_meta($pdt_id, 'zi_category_id', $item->category_id);
                            wp_set_object_terms($pdt_id, $term_id, 'product_cat');
                        }
                    }
                }

                // Map taxes while syncing product from zoho.

                if ($pdt_id) {
                    $zi_common_class = new ZI_CommonClass();
                    $woo_tax_class = $zi_common_class->get_woo_tax_class_from_zoho_tax_id($item->tax_id);
                    $product = wc_get_product($pdt_id);
                    $product->set_tax_status('taxable');
                    $product->set_tax_class($woo_tax_class);
                    $product->save();
                }

            }
        }
        return array("code" => 200, "response" => "Success");
    } else {
        return array("code" => 300, "response" => "No product found");
    }
    // fclose($fd);
}

// Create seo-friendly post_name
function zi_convert_itemname($item_name)
{
    //Lower case everything
    $item_name = strtolower($item_name);
    //Make alphanumeric (removes all other characters)
    $item_name = preg_replace("/[^a-z0-9_\s-]/", "", $item_name);
    //Clean up multiple dashes or whitespaces
    $item_name = preg_replace("/[\s-]+/", " ", $item_name);
    //Convert whitespaces and underscore to dash
    $item_name = preg_replace("/[\s_]/", "-", $item_name);
    return $item_name;
}
