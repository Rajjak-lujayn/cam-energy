<?php

/**
 * All WooCommerce related functions.
 *
 * @package  WooZo_Inventory
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Function to be called by hook when new product is added in woocommerce.
 * This function sync item to zoho when admin adds / update any item in woocommerce.
 */
add_action('woocommerce_update_product', 'zi_product_sync_class', 10, 1);
add_action('wp_ajax_zi_product_sync_class', 'zi_product_sync_class');
function zi_product_sync_class($product_id)
{
    if (!is_admin()) {
        return;
    }
    if (!$product_id) {
        $product_id = $_POST['arg_product_data'];
    }
    $productHandler = new ProductClass();
    $productHandler->zi_product_sync($product_id);
}

/**
 * Bulk-action to sync products from WooCommerce to Zoho
 * @param: $bulk_array
 */
add_filter('bulk_actions-edit-product', 'zi_sync_all_items_to_zoho');
function zi_sync_all_items_to_zoho($bulk_array)
{
    $bulk_array['sync_item_to_zoho'] = 'Sync to Zoho';
    return $bulk_array;
}

add_filter('handle_bulk_actions-edit-product', 'zi_sync_all_items_to_zoho_handler', 10, 3);
function zi_sync_all_items_to_zoho_handler($redirect, $action, $object_ids)
{
    // let's remove query args first
    $redirect = remove_query_arg('sync_item_to_zoho_done', $redirect);

    // do something for "Make Draft" bulk action
    if ($action == 'sync_item_to_zoho') {

        foreach ($object_ids as $post_id) {
            $productHandler = new ProductClass();
            $productHandler->zi_product_sync($post_id);
        }

        // do not forget to add query args to URL because we will show notices later
        $redirect = add_query_arg('sync_item_to_zoho_done', count($object_ids), $redirect);

    }

    return $redirect;
}

// output the message of bulk action
add_action('admin_notices', 'sync_item_to_zoho_notices');
function sync_item_to_zoho_notices()
{
    if (!empty($_REQUEST['sync_item_to_zoho_done'])) {
        echo '<div id="message" class="updated notice is-dismissible">
			<p>Products Synced. If product is not synced, please click on Edit Product to see the API response.</p>
		</div>';
    }
}

/**
 * Function to be called by ajax hook when unmap button called.
 * This function remove zoho mapped id.
 */
add_action('wp_ajax_zi_product_unmap_hook', 'zi_product_unmap_hook');
function zi_product_unmap_hook($product_id)
{
    if (!$product_id) {
        $product_id = $_POST['product_id'];
    }

    if ($product_id) {
        $product = wc_get_product($product_id);
        // If this is variable items then unmap all of it's variations.
        if ($product->is_type('variable')) {
            $variations = $product->get_available_variations();
            if (isset($variations) && count($variations) > 0) {
                foreach ($variations as $child) {
                    delete_post_meta($child['variation_id'], 'zi_item_id');
                }
            }
        }
        delete_post_meta($product_id, 'zi_item_id');
    }
}

/**
 * Function to be called by ajax hook when unmap button called.
 * This function remove zoho mapped id.
 */
add_action('wp_ajax_zi_customer_unmap_hook', 'zi_customer_unmap_hook');
function zi_customer_unmap_hook($order_id)
{
    if (!$order_id) {
        $order_id = $_POST['order_id'];
    }

    $order = wc_get_order($order_id);
    $customer_id = $order->get_user_id();

    if ($customer_id) {
        delete_user_meta($customer_id, 'zi_contact_id');
        delete_user_meta($customer_id, 'zi_contact_persons_id');
        delete_user_meta($customer_id, 'zi_contactperson_id_0');
        delete_user_meta($customer_id, 'zi_created_time');
        delete_user_meta($customer_id, 'zi_last_modified_time');
        delete_user_meta($customer_id, 'zi_primary_contact_id');
        delete_user_meta($customer_id, 'zi_billing_address_id');
        delete_user_meta($customer_id, 'zi_shipping_address_id');

        $order->add_order_note('Zoho Sync: Customer is now unmapped. Please try syncing the order again');
        $order->save();
    }
}

/**
 * Add WordPress Meta box to show sync response
 */
function zoho_product_metabox()
{
    add_meta_box(
        'zoho-product-sync',
        __('Zoho Inventory'),
        'zoho_product_metabox_callback',
        'product',
        'side',
        'high'
    );
}
function zoho_product_metabox_callback($post)
{
    $response = get_post_meta($post->ID, 'zi_product_errmsg');
    echo 'API Response: ' . implode($response) . '<br>';
    echo '<br><a href="javascript:void(0)" style="width:100%; text-align: center;" class="button button-primary" onclick="zoho_admin_product_ajax(' . $post->ID . ')">Sync Product</a>';
    echo '<br><a href="javascript:void(0)" style="margin-top:10px; background:#b32d2e; border-color: #b32d2e; width:100%; text-align: center;" class="button button-primary" onclick="zoho_admin_unmap_product_ajax(' . $post->ID . ')">Unmap this Product</a>';
    $product = wc_get_product($post->ID);
    $product_type = $product->get_type();
    if ('variable' === $product_type || 'variable-subscription' === $product_type) {
        echo '<p class="howto" style="color:#b32d2e;"><strong>Important : </strong> Please ensure all variations have price and SKU</p>';
    }

    if ('simple' === $product_type || 'bundle' === $product_type) {
        $zi_product_id = get_post_meta($post->ID, 'zi_item_id', true);
        $zoho_inventory_oid = get_option('zoho_inventory_oid');
        $zoho_inventory_url = get_option('zoho_inventory_url');
        $get_url = $zoho_inventory_url . 'api/v1/items/' . $zi_product_id . '/?organization_id=' . $zoho_inventory_oid;
        if ($zi_product_id) {
            $executeCurlCallHandle = new ExecutecallClass();
            $json = $executeCurlCallHandle->ExecuteCurlCallGet($get_url);
            $code = $json->code;
            if ($code == 0 || $code == '0') {
                echo '<p> Available Stock via API: <strong>' . $json->item->available_stock . '</strong></p>
                <p> Zoho Category: <strong>' . $json->item->category_name . '</strong></p>';
            }
        }
    }
}
add_action('add_meta_boxes', 'zoho_product_metabox');

//Add Zoho Item ID field on Product Edit page
add_action('woocommerce_product_options_general_product_data', 'zoho_item_id_field');
add_action('woocommerce_variation_options_pricing', 'zoho_item_id_variation_field', 10, 3);
function zoho_item_id_field()
{
    woocommerce_wp_text_input(
        array(
            'id' => 'zi_item_id',
            'label' => __('Zoho Item ID'),
            'class' => 'readonly',
            'desc_tip' => true,
            'description' => __('This is the Zoho Item ID of this product. You cannot change this'),
        )
    );
}
function zoho_item_id_variation_field($loop, $variation_data, $variation)
{
    woocommerce_wp_text_input(array(
        'id' => 'zi_item_id[' . $loop . ']',
        'class' => 'readonly',
        'label' => __('Zoho Item ID'),
        'value' => get_post_meta($variation->ID, 'zi_item_id', true),
        'desc_tip' => true,
        'description' => __('This is the Zoho Item ID of this product. You cannot change this'),
    ));
}
// Now we save the value of the zoho item id
add_action('woocommerce_admin_process_product_object', 'zoho_item_id_field_save');
function zoho_item_id_field_save($product)
{
    // $fd =fopen(__DIR__.'/itemfield.txt','w+');
    // fwrite($fd,PHP_EOL.'$_POST : '.print_r($_POST,true));
    if (isset($_POST['zi_item_id'])) {
        // fwrite($fd,PHP_EOL.'ZI Item exists : '.$_POST['zi_item_id']);
        // $product->update_meta_data( 'zi_item_id', sanitize_text_field( $_POST['zi_item_id'] ) );
    } else {
        // fwrite($fd,PHP_EOL.'ZI Item not exists');
        // $product->delete_meta_data( 'zi_item_id' );
    }
    // fclose($fd);
}

// Update variation meta for variations of product when product variations updated.
function zoho_item_id_variation_save($variation, $i)
{
    if ($variation && $variation instanceof WC_Product_Variation) {
        $variation_id = $variation->get_id();
        $zi_zoho_item_id = $_POST['zi_item_id'][$i];
        if (isset($zi_zoho_item_id)) {
            update_post_meta($variation_id, 'zi_item_id', esc_attr($zi_zoho_item_id));
        }
    }
}
add_action('woocommerce_admin_process_variation_object', 'zoho_item_id_variation_save', 10, 2);

// Disable Guest Checkout
function zi_disable_guest_checkout()
{

    $zoho_sync_status = get_option('zoho_sync_status');
    if ($zoho_sync_status != 'true') {
        $value = 'no';
        return $value;
    }
}
add_filter('pre_option_woocommerce_enable_guest_checkout', 'zi_disable_guest_checkout');

// Show register form on checkout
add_action('woocommerce_before_checkout_form', 'zoho_register_form');
function zoho_register_form()
{

    $multicurrency_support = get_option('zoho_enable_multicurrency_status');
    if ($multicurrency_support != 'true') {
        return;
    }

    if (!is_user_logged_in()) {

        $registration_label_on_checkout = get_option('registration_label_on_checkout');

        ?>
		<div class="u-column2 col-2">

			<h2><?php esc_html_e('Register', 'woocommerce');?></h2>
			<p style="color:red;"><strong><?php esc_html_e($registration_label_on_checkout, 'woocommerce');?></strong></p>

			<form method="post" class="woocommerce-form woocommerce-form-register register">

				<?php do_action('woocommerce_register_form_start');?>

				<?php if ('no' === get_option('woocommerce_registration_generate_username')): ?>

					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
						<label for="reg_username"><?php esc_html_e('Username', 'woocommerce');?>&nbsp;<span class="required">*</span></label>
						<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo (!empty($_POST['username'])) ? esc_attr(wp_unslash($_POST['username'])) : ''; ?>" /><?php // @codingStandardsIgnoreLine
        ?>
					</p>

				<?php endif;?>

				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="reg_email"><?php esc_html_e('Email address', 'woocommerce');?>&nbsp;<span class="required">*</span></label>
					<input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo (!empty($_POST['email'])) ? esc_attr(wp_unslash($_POST['email'])) : ''; ?>" /><?php // @codingStandardsIgnoreLine
        ?>
				</p>

				<?php if ('no' === get_option('woocommerce_registration_generate_password')): ?>

					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
						<label for="reg_password"><?php esc_html_e('Password', 'woocommerce');?>&nbsp;<span class="required">*</span></label>
						<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" />
					</p>

				<?php endif;?>

				<?php do_action('woocommerce_register_form');?>

				<p class="woocommerce-FormRow form-row">
					<?php wp_nonce_field('woocommerce-register', 'woocommerce-register-nonce');?>
					<button type="submit" class="woocommerce-Button button" name="register" value="<?php esc_attr_e('Register', 'woocommerce');?>"><?php esc_html_e('Register', 'woocommerce');?></button>
				</p>

				<?php do_action('woocommerce_register_form_end');?>

			</form>

		</div>
		<?php
}
}

// Show currency code on checkout page
function zi_addPriceSuffix($format, $currency_pos)
{
    switch ($currency_pos) {
        case 'left':
            $currency = get_woocommerce_currency();
            $format = '%1$s%2$s&nbsp;<span class="currency_code">' . $currency . '</span>';
            break;
    }

    return $format;
}
function zi_addPriceSuffixAction()
{
    add_action('woocommerce_price_format', 'zi_addPriceSuffix', 1, 2);
}
add_action('woocommerce_review_order_before_order_total', 'zi_addPriceSuffixAction');

// Block wc fields in My-Account page to prevent broken sync
add_filter('woocommerce_billing_fields', 'zoho_readonly_billing_account', 25, 1);
function zoho_readonly_billing_account($billing_fields)
{
    // Only my account billing address for logged in users
    if (is_user_logged_in() && is_account_page()) {

        $readonly = ['readonly' => 'readonly'];

        $billing_fields['billing_first_name']['custom_attributes'] = $readonly;
        $billing_fields['billing_last_name']['custom_attributes'] = $readonly;
        $billing_fields['billing_email']['custom_attributes'] = $readonly;
    }
    return $billing_fields;
}

// If Product Bundle in cart, do not allow other types of products to be added in cart
/*
add_filter('woocommerce_add_to_cart_validation', 'zoho_add_to_cart_validation_callback', 10, 3);
function zoho_add_to_cart_validation_callback($passed, $product_id, $quantity)
{
    // HERE set your alert text message
    $message = __('Bundles should be purchased separately.', 'woocommerce');
    $product_ = wc_get_product($product_id);
    $product_type = $product_->get_type();
    if ($product_type == 'bundle') {
        if (!WC()->cart->is_empty()) {
            // Checking cart items if its not bundle 
            foreach (WC()->cart->get_cart() as $cart_item) {
                $products_ = wc_get_product($cart_item['product_id']);
                $products_type = $products_->get_type();
                if ($products_type != 'bundle') {
                    $passed = false;
                    wc_add_notice($message, 'error');
                    break;
                } else {
                    break;
                }
            }
        }
    } else {
        if (!WC()->cart->is_empty()) {
            // Checking cart items if its not bundle
            foreach (WC()->cart->get_cart() as $cart_item) {
                $products_ = wc_get_product($cart_item['product_id']);
                $products_type = $products_->get_type();
                if ($products_type == 'bundle') {
                    $passed = false;
                    wc_add_notice($message, 'error');
                    break;
                } else {
                    break;
                }
            }
        }
    }

    return $passed;
}
*/

/**
 * Adds 'Zoho Sync' column header to 'Products' page.
 *
 * @param string[] $columns
 * @return string[] $new_columns
 */
function zi_sync_column_products_overview($columns)
{

    $new_columns = array();

    foreach ($columns as $column_name => $column_info) {

        $new_columns[$column_name] = $column_info;

        if ('product_cat' === $column_name) {
            $new_columns['zoho_sync'] = __('Zoho Sync', 'my-textdomain');
        }
    }

    return $new_columns;
}
add_filter('manage_edit-product_columns', 'zi_sync_column_products_overview', 20);

/**
 * Adds 'Zoho Sync' column header to 'Orders' page immediately after 'Total' column.
 *
 * @param string[] $columns
 * @return string[] $new_columns
 */
function zi_sync_column_orders_overview($columns)
{

    $new_columns = array();

    foreach ($columns as $column_name => $column_info) {

        $new_columns[$column_name] = $column_info;

        if ('order_total' === $column_name) {
            $new_columns['zoho_sync'] = __('Zoho Sync', 'my-textdomain');
        }
    }

    return $new_columns;
}
add_filter('manage_edit-shop_order_columns', 'zi_sync_column_orders_overview', 20);

if (!function_exists('zi_helper_get_order_meta')):

    /**
     * Helper function to get meta for an order.
     *
     * @param \WC_Order $order the order object
     * @param string $key the meta key
     * @param bool $single whether to get the meta as a single item. Defaults to `true`
     * @param string $context if 'view' then the value will be filtered
     * @return mixed the order property
     */
    function zi_helper_get_order_meta($order, $key = 'zi_order_id', $single = true, $context = 'edit')
{
        $value = $order->get_meta($key, $single, $context);

        return $value;
    }

endif;

/**
 * Adds 'Zoho Sync' column content.
 *
 * @param string[] $column name of column being displayed
 */
function zi_add_zoho_column_content($column)
{
    global $post;
    $post_type = get_post_type($post);

    if ('zoho_sync' === $column && 'shop_order' === $post_type) {

        $order = wc_get_order($post->ID);
        $zi_order_id = zi_helper_get_order_meta($order, 'zi_salesorder_id');
        $zi_url = get_option('zoho_inventory_url');
        $url = $zi_url . 'app#/salesorders/' . $zi_order_id;
        if ($zi_order_id) {
            echo '<span class="dashicons dashicons-yes-alt" style="color:green;"></span><a href="' . esc_url($url) . '" target="_blank"> <span class="dashicons dashicons-external" style="color:green;"></span> </a>';
        } else {
            echo '<span class="dashicons dashicons-dismiss" style="color:red;"></span>';
        }
    } elseif ('zoho_sync' === $column && 'product' === $post_type) {
        $product_id = $post->ID;
        $zi_product_id = get_post_meta($product_id, 'zi_item_id');
        if ($zi_product_id) {
            echo '<span class="dashicons dashicons-yes-alt" style="color:green;"></span>';
        } else {
            echo '<span class="dashicons dashicons-dismiss" style="color:red;"></span>';
        }
    }

}
add_action('manage_shop_order_posts_custom_column', 'zi_add_zoho_column_content');
add_action('manage_product_posts_custom_column', 'zi_add_zoho_column_content');

// function zi_update_vat_exempt_boolean( $order_id ) {
//     $order = new WC_Order( $order_id );
//     $tax = $order->get_tax_total();
//     if(empty($tax)){
//       update_post_meta( $order_id, 'is_vat_exempt', 'yes' );
//     }
//  }
//  add_action( 'woocommerce_checkout_update_order_meta', 'zi_update_vat_exempt_boolean' );