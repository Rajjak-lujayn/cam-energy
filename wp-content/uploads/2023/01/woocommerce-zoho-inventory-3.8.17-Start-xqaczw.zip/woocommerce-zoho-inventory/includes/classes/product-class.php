<?php
/**
 * Class for All Product Data from Woo To Zoho
 *
 * @package  WooZo Inventory
 */

class ProductClass
{

    public function __construct()
    {
        $config = [

            'ProductZI' => [
                'OID' => get_option('zoho_inventory_oid'),
                'APIURL' => get_option('zoho_inventory_url'),
            ],

        ];

        return $this->config = $config;
    }

    public function zi_product_sync($post_id)
    {

        // $fd = fopen(__DIR__.'/product_class.txt','w+');
        // fwrite($fd,PHP_EOL.'$post_id : '.$post_id);
        // Send category only if category ID available.

        // get category to filter by category
        /*
        $zi_category_id = $this->get_prod_updated_category($post_id);
        $opt_category = get_option('zoho_item_category');
        if ($opt_category) {
        $opt_category = unserialize($opt_category);
        } else {
        $opt_category = array();
        }
         */
        // fwrite($fd,PHP_EOL.'Category Ids to be mapped : ');
        // This condition is to check if the selected product category is allowed to sync from cron settings page.
        /*
        if(!in_array($zi_category_id, $opt_category)) {
        update_post_meta($post_id, 'zi_product_errmsg', 'Product with selected category is not allowed to sync');
        return;
        }
         */

        if ('publish' !== get_post_status($post_id)) {
            return;
        }

        $product = wc_get_product($post_id);
        if ($product->is_type('bundle')) {
            // fwrite($fd,PHP_EOL.'Inside bundle: ');
            $this->zi_bundle_product_to_zoho($post_id);
        } elseif ($product->is_type('variable')) {
            // fwrite($fd,PHP_EOL.'Inside variable: ');
            $this->zi_variation_product_to_zoho($post_id);
        } else {
            // fwrite($fd,PHP_EOL.'Inside Regular: ');
            // Simple product.
            $rate = $product->get_regular_price();
            $rateS = $product->get_sale_price();
            /*
            if ($rateS) {
            $rate = $rateS;
            } else {
            $rate = $rateR;
            } */
            // parse the name
            $item_name = $product->get_name();
            $name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);

            $sku = $product->get_sku();
            $in_stock = ($product->get_stock_quantity()) ? $product->get_stock_quantity() : 0;
            // fwrite($fd,PHP_EOL.'$product->get_stock_quantity() : '.$product->get_stock_quantity());
            $in_stock_rate = $in_stock * (int)$rate;

            $tax_rates = WC_Tax::get_base_tax_rates($product->get_tax_class());
            $tax_id_key = '';
            foreach ($tax_rates as $tax_key => $tax_value) {
                $tax_id_key = $tax_key;
                break;
            }
            $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
            $tax_id = explode('##', $tax_option)[0];

            $zi_status = ('publish' === get_post_status($post_id)) ? 'active' : 'inactive';
            // request data for adding/updating value to zoho.
            $zi_disable_itemname_sync = get_option('zoho_disable_itemname_sync_status');
            $zoho_itemId = get_post_meta($post_id, 'zi_item_id', true);

            $zidata = '';
            if (empty($zoho_itemId) || 'true' != $zi_disable_itemname_sync) {
                $zidata .= '"name" : "' . $name . '",';
            }

            if ($product->is_virtual('yes')) {
                $zidata .= '"product_type" : "service",';
                $zidata .= '"item_type" : "sales",';
            } else {
                $zidata .= '"product_type" : "goods",';
                $zidata .= '"item_type" : "inventory",';
            }

            $zidata .= '"sku" : "' . $sku . '",';
            $zidata .= '"unit" : "pcs",';
            $zidata .= '"status" : "' . $zi_status . '",';
            // Initial stock update only if item sync for first time.
            if (empty($zoho_itemId)) {
                $zidata .= '"initial_stock" : ' . $in_stock . ',';
                $zidata .= '"initial_stock_rate" : "' . $in_stock_rate . '",';
            }
            $zidata .= '"rate" : "' . $rate . '",';
            $zidata .= '"tax_id" : "' . $tax_id . '",';
            //$zidata .= '"image_name" : "' . $image . '",';

            if ($this->zi_dimension_sync_allowed()) {
                $dimensions = (object) array();
                $dimensions->length = $product->get_length();
                $dimensions->width = $product->get_width();
                $dimensions->height = $product->get_height();
                $dimensions->weight = $product->get_weight();
                $zidata .= '"package_details" : ' . json_encode($dimensions) . ',';
            }

            // Send category only if category ID available.
            $zi_category_id = $this->get_prod_updated_category($post_id);
            if ($zi_category_id) {
                $zidata .= '"category_id" : "' . $zi_category_id . '"';
            }

            // $zidata .= '"image_type" : "' . $ext . '"';
            if (!empty($zoho_itemId)) {
                // fwrite($fd,PHP_EOL.'Inside Update: ');
                $this->product_zoho_update_inventory_post($post_id, $zoho_itemId, $zidata);
            } else {
                // fwrite($fd,PHP_EOL.'Inside Create ');
                $zoho_inventory_oid = $this->config['ProductZI']['OID'];
                $zoho_inventory_url = $this->config['ProductZI']['APIURL'];

                $data = array(
                    'JSONString' => '{' . $zidata . '}',
                    'organization_id' => $zoho_inventory_oid,
                );
                $url = $zoho_inventory_url . 'api/v1/items';

                $executeCurlCallHandle = new ExecutecallClass();
                $json = $executeCurlCallHandle->ExecuteCurlCallPost($url, $data);

                $errmsg = $json->message;
                update_post_meta($post_id, 'zi_product_errmsg', $errmsg);

                $code = $json->code;
                // fwrite($fd,PHP_EOL.'JSON Response : '.print_r($json,true));
                // Check if the the given sku has product at zoho inventory.
                if ($code == '1001' || $code == 1001) {
                    // fwrite($fd,PHP_EOL.'Inside SKU Check');
                    $sku_check = str_replace(" ", "+", $sku);
                    $url = $zoho_inventory_url . 'api/v1/items?search_text=' . $sku_check . '&organization_id=' . $zoho_inventory_oid;
                    $getRequest = $executeCurlCallHandle->ExecuteCurlCallGet($url);
                    if ($getRequest->code === '0' || $getRequest->code === 0) {
                        $item_id = '';
                        foreach ($getRequest->items as $zohoItem) {
                            // fwrite($fd,PHP_EOL.'ZOHO Item : '.print_r($zohoItem, true));
                            if ($zohoItem->sku === $sku) {
                                // fwrite($fd,PHP_EOL.'SKU matched');
                                // Item sku is mached
                                // Assign mached zoho item to json so fields can be mapped.
                                $code = 0;
                                $json->item = $zohoItem;
                                update_post_meta($post_id, 'zi_product_errmsg', 'Product "' . $zohoItem->name . '" is mapped successfully with Zoho');
                                break;
                            }
                        }
                    }
                }
                // fwrite($fd,PHP_EOL.'After SKU Check : code '.$code);
                if ($code == '0' || $code == 0) {
                    foreach ($json->item as $key => $value) {
                        if ($key == 'item_id') {
                            $item_id = $value;
                        }
                        if ($key == 'purchase_account_id') {
                            $purchase_account_id = $value;
                        }
                        if ($key == 'account_id') {
                            $account_id = $value;
                        }
                        if ($key == 'account_name') {
                            $account_name = $value;
                        }
                        if ($key == 'inventory_account_id') {
                            $inventory_account_id = $value;
                        }
                        if ($key == 'category_id' && !empty($value)) {
                            update_post_meta($post_id, 'zi_category_id', $value);
                        }
                    }
                    update_post_meta($post_id, 'zi_item_id', $item_id);
                    update_post_meta($post_id, 'zi_purchase_account_id', $purchase_account_id);
                    update_post_meta($post_id, 'zi_account_id', $account_id);
                    update_post_meta($post_id, 'zi_account_name', $account_name);
                    update_post_meta($post_id, 'zi_inventory_account_id', $inventory_account_id);
                }
            }
        } // loop end
        // return;
        // fclose($fd);
    }

    /**
     * Function to update zoho item if already exists.
     *
     * @param number $proid - product number.
     * @param number $item_id - zoho item id.
     * @param mixed  $pdt3 - Zoho item object for post request.
     * @return string
     */
    protected function product_zoho_update_inventory_post($proid, $item_id, $pdt3, $bundle = '')
    {
        // $fd = fopen(__DIR__.'/product_class.txt','a+');
        // fwrite($fd,PHP_EOL.'Inside update : ');
        $errmsg = '';
        $zoho_inventory_oid = $this->config['ProductZI']['OID'];
        $zoho_inventory_url = $this->config['ProductZI']['APIURL'];

        $url = $zoho_inventory_url . 'api/v1/items/' . $item_id;
        // fwrite($fd,PHP_EOL.'JSON Data : '.'{' . $pdt3 . '}');
        $data = array(
            'JSONString' => '{' . $pdt3 . '}',
            'organization_id' => $zoho_inventory_oid,
        );

        $executeCurlCallHandle = new ExecutecallClass();
        $json = $executeCurlCallHandle->ExecuteCurlCallPut($url, $data);
        // fwrite($fd,PHP_EOL.'Update response : '.print_r($json,true));
        $code = $json->code;
        $errmsg = $json->message;
        update_post_meta($proid, 'zi_product_errmsg', $errmsg);
        // fclose($fd);
        return $errmsg;
    }

    /**
     * Create Add And Update Bundle producttype
     */
    protected function zi_get_bundle_item_meta_data($bundle_item_id, $bundle_id, $meta_key = '')
    {
        global $wpdb;
        $table_meta = $wpdb->prefix . 'woocommerce_bundled_itemmeta';
        $table_item = $wpdb->prefix . 'woocommerce_bundled_items';
        if ('' !== $meta_key) {
            $meta_key = "AND meta_key='$meta_key'";
        }
        $metadata = $wpdb->get_results("SELECT meta_key, meta_value FROM $table_meta, $table_item WHERE $table_meta.bundled_item_id = $table_item.bundled_item_id AND product_id=$bundle_item_id AND bundle_id = $bundle_id $meta_key");

        if (count($metadata) > 0) {
            return $metadata;
        } else {
            false;
        }
    }

    protected function zi_bundle_product_data_zoho($bundle_id)
    {

        $item = get_post($bundle_id);
        $bundle_childs = WC_PB_DB::query_bundled_items(
            array(
                'return' => 'id=>product_id', // 'objects'
                'bundle_id' => array($bundle_id),
            )
        );
        $allow_sync = true;

        // Allow Bundle Product

        $child_array = array();
        foreach ($bundle_childs as $child_id) {

            $meta_value = $this->zi_get_bundle_item_meta_data($child_id, $bundle_id, 'quantity_max');

            $zi_child_id = get_post_meta($child_id, 'zi_item_id', true);
            $json_child = (object) array(
                'item_id' => $zi_child_id,
                'quantity' => $meta_value[0]->meta_value,
            );
            array_push($child_array, $json_child);
        }
        $child_items = $child_array;

        return $child_items;
    }

    protected function zi_bundle_product_to_zoho($post_id)
    {

        $item = wc_get_product($post_id);
        if ($item->is_type('bundle')) {

            $child_items = $this->zi_bundle_product_data_zoho($post_id);
        }

        $priceR = $item->get_regular_price();
        $priceS = $item->get_sale_price();

        if ($priceS) {
            $rate = $priceS;
        } else {
            $rate = $priceR;
        }
        //$rate = 500;
        $proid = $item->ID;
        $item_name = $item->get_name();
        $name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);
        $sku = $item->get_sku();
        $in_stock = ($item->get_stock_quantity()) ? $item->get_stock_quantity() : 0;
        $in_stock_rate = ($in_stock * $rate);

        $product_type = 'goods';
        $item_type = 'inventory';
        $tax_rates = WC_Tax::get_base_tax_rates($item->get_tax_class());
        $tax_id_key = '';
        foreach ($tax_rates as $tax_key => $tax_value) {
            $tax_id_key = $tax_key;
            break;
        }
        $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
        $tax_id = explode('##', $tax_option)[0];
        if (!empty($tax_rates)) {
            $tax_rate = reset($tax_rates);
        }

        $pdt1 = '"name" : "' . $name . '","mapped_items":' . json_encode($child_items) . ', "product_type" : "' . $product_type . '","tax_id" : "' . $tax_id . '","rate" : "' . $rate . '","sku" : "' . $sku . '","unit" : "pcs","item_type" : "' . $item_type . '"';
        // If zoho category id is not mapped to product, then assign mapped product category with zoho.

        $zi_category_id = $this->get_prod_updated_category($post_id);
        if ($zi_category_id) {
            $zidata .= ',"category_id" : "' . $zi_category_id . '"';
        }

        $zoho_itemId = get_post_meta($post_id, 'zi_item_id', true);
        if (empty($zoho_itemId)) {
            $pdt1 .= ',"initial_stock" : ' . $in_stock . ',';
            $pdt1 .= '"initial_stock_rate" : "' . $in_stock_rate . '"';
        }

        // Dimensions data append to update call.
        if ($this->zi_dimension_sync_allowed()) {
            $dimensions = (object) array();
            $dimensions->length = $item->get_length();
            $dimensions->width = $item->get_width();
            $dimensions->height = $item->get_height();
            $dimensions->weight = $item->get_weight();
            $pdt1 .= ',"package_details" : ' . json_encode($dimensions) . ',';
        }

        $zoho_inventory_oid = $this->config['ProductZI']['OID'];
        $zoho_inventory_url = $this->config['ProductZI']['APIURL'];

        if ($zoho_itemId) {
            $url_p = $zoho_inventory_url . 'api/v1/compositeitems/' . $zoho_itemId;
        } else {
            $url_p = $zoho_inventory_url . 'api/v1/compositeitems';
        }

        $data_p = array(
            'JSONString' => '{' . $pdt1 . '}',
            'organization_id' => $zoho_inventory_oid,
        );

        $executeCurlCallHandle = new ExecutecallClass();

        if ($zoho_itemId) {

            $json = $executeCurlCallHandle->ExecuteCurlCallPut($url_p, $data_p);
            $errmsg = $json->message;
            update_post_meta($post_id, 'zi_product_errmsg', $errmsg);
        } else {

            $json = $executeCurlCallHandle->ExecuteCurlCallPost($url_p, $data_p);

            $code = $json->code;
            $errmsg = $json->message;
            update_post_meta($post_id, 'zi_product_errmsg', $errmsg);
            if ($code == '1001' || $code == 1001) {
                $sku_check = str_replace(" ", "+", $sku);
                $url = $zoho_inventory_url . 'api/v1/compositeitems/?search_text=' . $sku_check . '&organization_id=' . $zoho_inventory_oid;
                $getRequest = $executeCurlCallHandle->ExecuteCurlCallGet($url);
                if ($getRequest->code === '0' || $getRequest->code === 0) {
                    $item_id = '';
                    foreach ($getRequest->composite_items as $zoho_composite) {
                        // fwrite($fd,PHP_EOL.'ZOHO Item : '.print_r($zohoItem, true));
                        if ($zoho_composite->sku === $sku) {
                            $code = 0;
                            $json->composite_item = $zoho_composite;
                            update_post_meta($post_id, 'zi_product_errmsg', 'Product "' . $zoho_composite->name . '" is mapped successfully with Zoho');
                            break;
                        }
                    }
                }
            }
            if ($code == '0' || $code == 0) {
                foreach ($json->composite_item as $key => $value) {

                    if ($key == 'composite_item_id') {
                        $item_id = $value;
                    }
                    if ($key == 'purchase_account_id') {
                        $purchase_account_id = $value;
                    }
                    if ($key == 'account_id') {
                        $account_id = $value;
                    }
                    if ($key == 'account_name') {
                        $account_name = $value;
                    }
                    if ($key == 'inventory_account_id') {
                        $inventory_account_id = $value;
                    }
                    if ($key == 'category_id' && !empty($value)) {
                        update_post_meta($post_id, 'zi_category_id', $value);
                    }
                }
                update_post_meta($post_id, 'zi_item_id', $item_id);
                update_post_meta($post_id, 'zi_purchase_account_id', $purchase_account_id);
                update_post_meta($post_id, 'zi_account_id', $account_id);
                update_post_meta($post_id, 'zi_account_name', $account_name);
                update_post_meta($post_id, 'zi_inventory_account_id', $inventory_account_id);
            }
        }
        // fclose($fd);
    }

    //variation product post zoho start

    protected function zi_variation_product_to_zoho($post_id)
    {
        // $fd = fopen(__DIR__ . '/zi_variation_product_to_zoho.txt', 'w+');

        $product = wc_get_product($post_id);

        $item_name = $product->get_title();
        $name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);

        $tax_rates = WC_Tax::get_base_tax_rates($product->get_tax_class());
        $tax_id_key = '';
        foreach ($tax_rates as $tax_key => $tax_value) {
            $tax_id_key = $tax_key;
            break;
        }
        $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
        $tax_id = explode('##', $tax_option)[0];
        $zi_category_id = $this->get_prod_updated_category($post_id);

        $zidata = '"group_name" : "' . $name . '", "unit" : "pcs", "tax_id" : "' . $tax_id . '","category_id" : "' . $zi_category_id . '",';

        // attributes
        $zi_enable_attributes_sync = get_option('zoho_enable_attributes_sync_status');
        if ($zi_enable_attributes_sync) {
            $attributes = $product->get_attributes();
            // fwrite($fd, PHP_EOL . 'ATTRIBUTES : '. print_r($attributes, true));
            $attributeName1 = '';
            $attributeName2 = '';
            $attributeName3 = '';
            foreach ($attributes as $attribute) {
                $attrname = $attribute->get_name();
                if (!empty($attrname) && $attribute['variation']) {
                    if (empty($attributeName1)) {
                        $attributeName1 = $attrname;
                    } elseif (empty($attributeName2)) {
                        $attributeName2 = $attrname;
                    } elseif (empty($attributeName3)) {
                        $attributeName3 = $attrname;
                    }
                }
            }
            if (!empty($attributeName1)) {
                $zidata .= '"attribute_name1": "' . $attributeName1 . '",';
            }
            if (!empty($attributeName2)) {
                $zidata .= '"attribute_name2": "' . $attributeName2 . '",';
            }
            if (!empty($attributeName3)) {
                $zidata .= '"attribute_name3": "' . $attributeName3 . '",';
            }

        } // end of attributes sync check

        $available_variations = $product->get_available_variations();
        // If there is attributes variations then append that data to server.
        if (count($available_variations) > 0) {
            foreach ($available_variations as $child_data) {

                $product_variable = wc_get_product($child_data['variation_id']);
                $items[] = $this->variants_products($product_variable, $child_data['variation_id'], $attributeName1, $attributeName2, $attributeName3);
            }
        }

        // get category id
        // $zi_category_id = $this->get_prod_updated_category($post_id);
        // if ($zi_category_id) {
        //     $zidata .= '"category_id" : "' . $zi_category_id . '",';
        // }

        $zidata .= '"items" :[' . implode(',', $items) . ']';
        $data = array(
            'JSONString' => '{' . $zidata . '}',
        );

        // fwrite($fd, PHP_EOL . 'ZI Data JSON : ' . '{' . print_r($data, true) . '}');
        // fclose($fd);

        $zoho_inventory_oid = $this->config['ProductZI']['OID'];
        $zoho_inventory_url = $this->config['ProductZI']['APIURL'];
        $zoho_groupId = get_post_meta($post_id, 'zi_item_id', true);

        if (!empty($zoho_groupId)) {
            $item_name = $product->get_title();
            $name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);

            $url = $zoho_inventory_url . 'api/v1/itemgroups/' . $zoho_groupId . '?organization_id=' . $zoho_inventory_oid;

            $executeCurlCallHandle = new ExecutecallClass();
            $json_p = $executeCurlCallHandle->ExecuteCurlCallPut($url, $data);
            $code = $json_p->code;

            $errmsg = $json_p->message;
            update_post_meta($post_id, 'zi_product_errmsg', $errmsg);
        } else {
            $url = $zoho_inventory_url . 'api/v1/itemgroups?organization_id=' . $zoho_inventory_oid;

            $executeCurlCallHandle = new ExecutecallClass();
            $json = $executeCurlCallHandle->ExecuteCurlCallPost($url, $data);

            $errmsg = $json->message;
            update_post_meta($post_id, 'zi_product_errmsg', $errmsg);
            $code = $json->code;
            if ($code == '0' || $code == 0) {

                // This item will keep the copy of zoho item_id with respect to product.
                //  name as key synced to zoho.
                $childItems = array();
                foreach ($json->item_group as $key => $value) {
                    if ($key == 'group_id') {
                        $group_id = $value;
                    }

                    if ($key == 'items') {
                        foreach ($value as $key2 => $val2) {
                            $zi_name = str_replace(' ', '-', $val2->name);
                            //    echo '<br>';
                            $zi_name = $val2->name;
                            $childItems[$zi_name] = $val2->item_id;
                        }
                    }
                }
                if (!empty($group_id)) {
                    update_post_meta($post_id, 'zi_item_id', $group_id);
                }

                foreach ($available_variations as $child_data) {
                    $product_variable = wc_get_product($child_data['variation_id']);

                    $pname = '';
                    foreach ($product_variable->get_variation_attributes() as $taxonomy => $terms_slug) {

                        $pname .= $terms_slug;
                    }

                    $item_name = $product_variable->get_name();
                    $vname = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);
                    $product_key = $vname . '-' . $pname;
                    update_post_meta($child_data['variation_id'], 'zi_item_id', $childItems[$product_key]);
                }
            }
        }
        // End New Variable Product
    }

    /**
     * Function to sync variations of a product.
     *
     * @param  $post_id        - variation product_id.
     * @param  $zi_category_id - Zoho category id of parent of a variation.
     * @return void
     */
    protected function variants_products($product_variable, $post_id, $attr1 = '', $attr2 = '', $attr3 = '')
    {
        // $post_id = $product_variable->ID;
        // $fd = fopen(__DIR__.'/variations_products.txt','a+');
        // fwrite($fd,PHP_EOL.'-------------------------------');
        // fwrite($fd,PHP_EOL.'$attr1 : '.$attr1.' | $attr2 : '.$attr2.' | $attr3 : '.$attr3.' $post_id : '.$post_id);
        // Sync Attributes of Variable Products
        $zi_enable_attributes_sync = get_option('zoho_enable_attributes_sync_status');

        $attributes = $product_variable->get_variation_attributes();
        // fwrite($fd,PHP_EOL.'$variation_attributes : '.print_r($attributes,true));
        $arrtibuteString = '';
        if (!empty($attr1)) {
            $attr_key = strtolower($attr1);
            $attr_key = 'attribute_' . str_replace(' ','-', $attr_key);
            $arrtibuteString .= '"attribute_option_name1": "' . $attributes[$attr_key] . '",';
        }
        if (!empty($attr2)) {
            $attr_key = strtolower($attr2);
            $attr_key = 'attribute_' . str_replace(' ','-', $attr_key);
            $arrtibuteString .= '"attribute_option_name2": "' . $attributes[$attr_key] . '",';
        }
        if (!empty($attr3)) {
            $attr_key = strtolower($attr3);
            $attr_key = 'attribute_' . str_replace(' ','-', $attr_key);
            $arrtibuteString .= '"attribute_option_name3": "' . $attributes[$attr_key] . '",';
        }
        // fwrite($fd,PHP_EOL.'$arrtibuteString : '.$arrtibuteString);
        // fclose($fd);
        $zoho_itemId = get_post_meta($post_id, 'zi_item_id', true);

        // $product_variable      = wc_get_product($post_id);
        $pname = '';
        foreach ($product_variable->get_variation_attributes() as $taxonomy => $terms_slug) {

            $pname .= $terms_slug;
        }

        $item_name = $product_variable->get_name();
        $vname = preg_replace('/[^A-Za-z0-9\-]/', ' ', $item_name);
        if ($zi_enable_attributes_sync) {
            $name = $vname;
        } else {
            $name = $vname . '-' . $pname;
        }
        $rate = $product_variable->get_regular_price();
        // $rateS = $product_variable->get_sale_price();
        if ($product_variable->is_virtual('yes')) {
            $product_type = 'service';
            $item_type = 'sales';
        } else {
            $product_type = 'goods';
            $item_type = 'inventory';
        }

        $sku = $product_variable->get_sku();
        $in_stock = ($product_variable->get_stock_quantity()) ? $product_variable->get_stock_quantity() : 0;

        /*
        if ($rateS) {
        $rate = $rateS;
        } else {
        $rate = $rateR;
        } */

        $tax_rates = WC_Tax::get_base_tax_rates($product_variable->get_tax_class());
        $tax_id_key = '';
        foreach ($tax_rates as $tax_key => $tax_value) {
            $tax_id_key = $tax_key;
            break;
        }
        $tax_option = get_option('zoho_inventory_tax_rate_' . $tax_id_key);
        $tax_id = explode('##', $tax_option)[0];

        $zi_status = ('publish' === get_post_status($post_id)) ? 'active' : 'inactive';
        // request data for adding/updating value to zoho.
        $zidata = '';
        if (!empty($arrtibuteString) && $zi_enable_attributes_sync) {
            $zidata .= $arrtibuteString;
        }
        $zidata .= '"name" : "' . $name . '",';
        $zidata .= '"product_type" : "' . $product_type . '",';
        $zidata .= '"sku" : "' . $sku . '",';
        $zidata .= '"item_type" : "' . $item_type . '",';
        $zidata .= '"unit" : "pcs",';
        $zidata .= '"status" : "' . $zi_status . '",';
        if (empty($zoho_itemId) && $in_stock > 0) {
            $zidata .= '"purchase_rate" : "1",';
            $zidata .= '"initial_stock" : ' . $in_stock . ',';
            $zidata .= '"initial_stock_rate" : ' . $in_stock . ',';
        }
        $zidata .= '"rate" : "' . $rate . '",';
        $zidata .= '"tax_id" : "' . $tax_id . '",';

        if ($this->zi_dimension_sync_allowed()) {
            $dimensions = (object) array();
            $dimensions->length = $product_variable->get_length();
            $dimensions->width = $product_variable->get_width();
            $dimensions->height = $product_variable->get_height();
            $dimensions->weight = $product_variable->get_weight();
            if (!empty($dimensions)) {
                $zidata .= '"package_details" : ' . json_encode($dimensions);
            }
        }
        // $fd = fopen(__DIR__ . '/variations.txt', 'a+');
        // fwrite($fd,PHP_EOL.'Get data for $post_id '.$post_id);
        if (!empty($zoho_itemId)) {
            // fwrite($fd, PHP_EOL . 'Update Item');
            $update_error_msg = $this->product_zoho_update_inventory_post($post_id, $zoho_itemId, $zidata);
            $zidataa = '';
            // fwrite($fd, PHP_EOL . '{' . $zidata . '}');
            return $zidataa .= '{' . $zidata . '}';
        } else {
            // fwrite($fd, PHP_EOL . 'Create Item');
            // Check if the the given sku has product in zoho inventory.
            $zoho_inventory_oid = $this->config['ProductZI']['OID'];
            $zoho_inventory_url = $this->config['ProductZI']['APIURL'];
            $sku_check = str_replace(" ", "+", $sku);
            $url = $zoho_inventory_url . 'api/v1/items?search_text=' . $sku_check . '&organization_id=' . $zoho_inventory_oid;
            $executeCurlCallHandle = new ExecutecallClass();
            $getRequest = $executeCurlCallHandle->ExecuteCurlCallGet($url);
            $var_item_id = '';
            // fwrite($fd, PHP_EOL . '$getRequest->code : ' . $getRequest->code);
            if ($getRequest->code === '0' || $getRequest->code === 0) {
                foreach ($getRequest->items as $zohoItem) {
                    // fwrite($fd, PHP_EOL . '$zohoItem->sku : ' . $zohoItem->sku);
                    if ($zohoItem->sku === $sku) {
                        // fwrite($fd, PHP_EOL . 'Product found with same sku $zohoItem : ' . print_r($zohoItem, true));
                        $var_item_id = $zohoItem->item_id;
                        // Item sku is mached
                        // Assign mached zoho item to json so fields can be mapped.
                        break;
                    }
                }
            }
            $zidataa = '';
            if ($var_item_id) {
                update_post_meta($post_id, 'zi_item_id', $var_item_id);
            }
            // fwrite($fd, PHP_EOL . '$var_item_id : ' . $var_item_id);
            // fclose($fd);
            return $zidataa .= '{' . $zidata . '}';
        }
    }

    /**
     * Check if dimensions sync are allowed or not
     *
     * @return boolean
     */
    protected function zi_dimension_sync_allowed()
    {
        $details_sync_status = get_option('zoho_enable_details_sync_status');
        return ('true' === $details_sync_status) ? true : false;
    }

    /**
     * Check if category already exists and return updated one
     */
    protected function get_prod_updated_category($product_id)
    {
        // Check if product category already synced.
        $terms = get_the_terms($product_id, 'product_cat');
        if ($terms) {
            foreach ($terms as $term) {
                $product_cat_id = $term->term_id;
                $zoho_cat_id = get_option("zoho_id_for_term_id_{$product_cat_id}");
                if ($zoho_cat_id) {
                    break;
                }
            }
        }
        // Check if product has already mapped category.
        if (empty($zoho_cat_id)) {
            $zoho_cat_id = get_post_meta($product_id, 'zi_category_id', true);
        }

        if ($zoho_cat_id) {
            return $zoho_cat_id;
        } else {
            return false;
        }
    }

    /**
     * Update product name in zoho
     */
    public function update_product_name($product_id, $product_name)
    {
        $zi_disable_itemname_sync = get_option('zoho_disable_itemname_sync_status');
        if ($zi_disable_itemname_sync != 'true') {
            $name_update = array(
                'ID' => $product_id,
                'post_title' => $product_name,
                'post_name' => $this->zi_convert_itemname($product_name),
            );
            $update_resp = wp_update_post($name_update, false);
            if (is_wp_error($update_resp)) {
                $error_string = $update_resp->get_error_message();
            }
        }
    }

    /**
     * Create seo-friendly post_name
     */
    private function zi_convert_itemname($item_name)
    {
        //Lower case everything
        $item_name = strtolower($item_name);
        //Make alphanumeric (removes all other characters)
        $item_name = preg_replace("/[^a-z0-9_\s-]/", "", $item_name);
        //Clean up multiple dashes or whitespaces
        $item_name = preg_replace("/[\s-]+/", " ", $item_name);
        //Convert whitespaces and underscore to dash
        $item_name = preg_replace("/[\s_]/", "-", $item_name);
        return $item_name;
    }

    /**
     * Function for adding product from zoho to woocommerce.
     *
     * @param $prod - Product object for adding new product in woocommerce.
     * @param $user_id - Current Active user Id
     * @param string $type - product is composite item or not (composite)
     */
    public function zi_product_to_woocommerce($prod, $user_id, $type = '')
    {
        if ($prod->status == 'active') {
            $status = 'publish';
        } else {
            $status = 'draft';
        }

        $post = array(
            'post_author' => $user_id,
            'post_content' => '',
            'post_status' => $status,
            'post_title' => $prod->name,
            'post_parent' => '',
            'post_type' => 'product',
        );

        $post_id = wp_insert_post($post, $wp_error);
        update_post_meta($post_id, '_manage_stock', 'yes');
        // Map composite items metadata to convert product as bundle product.
        if ('composite' === $type) {
            update_post_meta($post_id, '_wc_pb_layout_style', 'default');
            update_post_meta($post_id, '_wc_pb_add_to_cart_form_location', 'default');
            wp_set_object_terms($post_id, 'bundle', 'product_type');
        }
        return $post_id;
    }
}
