<?php
/**
 * Class to import Products from Zoho to WooCommerce
 *
 * @package  WooZo Inventory
 */

class ImportProductClass
{

    public function __construct()
    {
        $config = [

            'ProductZI' => [
                'OID' => get_option('zoho_inventory_oid'),
                'APIURL' => get_option('zoho_inventory_url'),
            ],

        ];

        return $this->config = $config;
    }

    /**
     * Function for adding product from zoho to woocommerce.
     * @param $prod - Product object for adding new product in woocommerce.
     * @param $user_id - Current Active user Id
     * @param string $type - product is composite item or not (composite)
     */
    public function zi_product_to_woocommerce($prod, $user_id, $type = '')
    {
        if ($prod->status == 'active') {
            $status = 'publish';
        } else {
            return;
        }

        $post = array(
            'post_author' => $user_id,
            'post_content' => '',
            'post_status' => $status,
            'post_title' => $prod->name,
            'post_parent' => '',
            'post_type' => 'product',
        );

        $post_id = wp_insert_post($post, true);
        if (!is_wp_error($post_id)) {
            update_post_meta($post_id, '_manage_stock', 'yes');
            if ('composite' === $type) {
                update_post_meta($post_id, '_wc_pb_layout_style', 'default');
                update_post_meta($post_id, '_wc_pb_add_to_cart_form_location', 'default');
                wp_set_object_terms($post_id, 'bundle', 'product_type');
            }
        } else {
            echo $post_id->get_error_message();
        }

        return $post_id;
    }

    /**
     * Function to retrieve item details and sync items.
     *
     * @param string $url - URL to get details.
     * @return mixed return true if data false if error.
     */
    public function zi_item_bulk_sync($url, $is_composite = false)
    {
        // $fd = fopen(__DIR__ . '/manual_item_updated.txt', 'a+');
        // fwrite($fd, PHP_EOL . '$url :' . $url);
        global $wpdb;
        // Check if item is for syncing purpose.

        $executeCurlCallHandle = new ExecutecallClass();
        $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
        $code = $json->code;

        /* Conditional code to load file only if source is cron. */
        $current_user = wp_get_current_user();
        $admin_author_id = $current_user->ID;
        if (empty($current_user)) {
            $admin_author_id = '1';
        }

        // $message = $json->message;
        // fwrite($fd, PHP_EOL . '$json->item : ' . print_r($json, true));
        if (0 == $code || '0' == $code) {

            foreach ($json->items as $arr) {
                $item_tags_hash = $arr->custom_field_hash;
                $item_tags = $item_tags_hash->cf_tags;

                // fwrite($fd, PHP_EOL . '$arr : ' . print_r($arr, true));
                if (!empty($arr->item_id)) {
                    // fwrite($fd, PHP_EOL . 'Item Id found : ' . $arr->item_id);

                    $tbl = $wpdb->prefix;
                    $product_res = $wpdb->get_row('SELECT * FROM ' . $tbl . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $arr->item_id . "'");
                    if (!empty($product_res->post_id)) {
                        // fwrite($fd, PHP_EOL . 'Product Already there ');
                        $pdt_id = $product_res->post_id;
                    }

                    if (!empty($pdt_id)) {
                        $zi_disable_itemdescription_sync = get_option('zoho_disable_itemdescription_sync_status');
                        if (!empty($arr->description) && $zi_disable_itemdescription_sync != 'true') {
                            $wpdb->update($tbl . 'posts', array('post_excerpt' => $arr->description), array('ID' => $pdt_id), array('%s'), array('%d'));
                        }

                        if (!empty($arr->status)) {
                            $status = $arr->status == 'active' ? 'publish' : 'draft';
                            $wpdb->update($tbl . 'posts', array('post_status' => $status), array('ID' => $pdt_id), array('%s'), array('%d'));
                        }

                        $zi_disable_itemname_sync = get_option('zoho_disable_itemname_sync_status');
                        if (($zi_disable_itemname_sync != 'true') && !empty($arr->name)) {
                            $wpdb->update($tbl . 'posts', array('post_title' => stripslashes($arr->name)), array('ID' => $pdt_id), array('%s'), array('%d'));
                        }

                        if (!empty($arr->sku)) {
                            update_post_meta($pdt_id, '_sku', $arr->sku);
                        }

                        $zi_disable_itemprice_sync = get_option('zoho_disable_itemprice_sync_status');
                        if (!empty($arr->rate) && $zi_disable_itemprice_sync != 'true') {
                            update_post_meta($pdt_id, '_regular_price', $arr->rate);
                            // fwrite($fd, PHP_EOL . 'Product Price updated of'.  $pdt_id);
                            $sale_price = get_post_meta($pdt_id, '_sale_price', true);
                            if (empty($sale_price)) {
                                update_post_meta($pdt_id, '_price', $arr->rate);
                            }
                        }

                        if (!empty($item_tags)) {
                            $final_tags = explode(',', $item_tags);
                            wp_set_object_terms($pdt_id, $final_tags, 'product_tag');
                        }

                        if (!empty($arr->image_document_id)) {
                            $imageClass = new ImageClass();
                            $imageClass->args_attach_image($arr->item_id, $arr->name, $pdt_id, $arr->image_name, $admin_author_id);
                        }

                        $details = $arr->package_details;
                        update_post_meta($pdt_id, '_weight', floatval($details->weight));
                        update_post_meta($pdt_id, '_length', floatval($details->length));
                        update_post_meta($pdt_id, '_width', floatval($details->width));
                        update_post_meta($pdt_id, '_height', floatval($details->height));
                        update_post_meta($pdt_id, '_weight_unit', $details->weight_unit);
                        update_post_meta($pdt_id, '_dimension_unit', $details->dimension_unit);

                        // To check status of stock sync option.
                        $zi_stock_sync = get_option('zoho_stock_sync_status');
                        if ($zi_stock_sync != 'true') {
                            // Update stock
                            $accounting_stock = get_option('zoho_enable_accounting_stock_status');
                            // Stock mode check
                            if ($accounting_stock) {
                                $stock = $arr->available_for_sale_stock;
                            } else {
                                $stock = $arr->actual_available_for_sale_stock;
                            }
                            if (!empty($stock)) {
                                // fwrite($fd, PHP_EOL . 'True 1');
                                update_post_meta($pdt_id, "_manage_stock", "yes");
                                $stock_quantity = $stock < 0 ? 0 : $stock;
                                update_post_meta($pdt_id, '_stock', number_format($stock_quantity, 0, '.', ''));
                                if ($stock_quantity > 0) {
                                    // fwrite($fd, PHP_EOL . 'True2');
                                    $status = 'instock';
                                    update_post_meta($pdt_id, '_stock_status', wc_clean($status));
                                    wp_set_post_terms($pdt_id, $status, 'product_visibility', true);
                                } else {
                                    // fwrite($fd, PHP_EOL . 'True 3');
                                    $backorder_status = get_post_meta($pdt_id, '_backorders', true);
                                    $status = ($backorder_status === 'yes') ? 'onbackorder' : 'outofstock';
                                    update_post_meta($pdt_id, '_stock_status', wc_clean($status));
                                    wp_set_post_terms($pdt_id, $status, 'product_visibility', true);
                                }
                            }
                        }

                        if (!empty($arr->tax_id)) {
                            $zi_common_class = new ZI_CommonClass();
                            $woo_tax_class = $zi_common_class->get_woo_tax_class_from_zoho_tax_id($arr->tax_id);
                            $product = wc_get_product($pdt_id);
                            $product->set_tax_status('taxable');
                            $product->set_tax_class($woo_tax_class);
                            $product->save();
                        }

                        wc_delete_product_transients($pdt_id); // Clear/refresh cache

                    }
                }
            }
        } else {
            return false;
        }
        // Return if synced.
        return true;
        // fclose($fd);
    }

    /**
     * Function to add items recursively by cron job.
     *
     * @param [number] $page  - Page number for getting item with pagination.
     * @param [number] $category - Category id to get item of specific category.
     * @param [string] $source - Source from where function is calling : 'cron'/'sync'.
     * @return mixed
     */
    public function sync_item_recursively($data)
    {
        // $fd = fopen(__DIR__ . '/simple-items-sync.txt', 'a+');
        if ($data->page && $data->category) {
            $page = $data->page;
            $category = $data->category;

            // Keep backup of current syncing page of particular category.
            update_option('simple_item_sync_page_cat_id_' . $category, $page);

            /* Conditional code to load file only if source is cron. */
            $current_user = wp_get_current_user();
            $admin_author_id = $current_user->ID;
            if (empty($current_user)) {
                $admin_author_id = '1';
            }

            $zoho_inventory_oid = $this->config['ProductZI']['OID'];
            $zoho_inventory_url = $this->config['ProductZI']['APIURL'];

            $urlitem = $zoho_inventory_url . 'api/v1/items?organization_id=' . $zoho_inventory_oid . '&category_id=' . $category . '&page=' . $page . '&per_page=100&sort_column=last_modified_time';
            $executeCurlCallHandle = new ExecutecallClass();
            $json = $executeCurlCallHandle->ExecuteCurlCallGet($urlitem);

            $code = $json->code;

            /* Response for item sync with sync button. For cron sync blank array will return. */
            $response_msg = array();
            if ($code == '0' || $code == 0) {
                $item_ids = [];
                if (0 == $code || '0' == $code) {
                    foreach ($json->items as $arr) {

                        $prod_id = $this->get_product_by_sku($arr->sku);
                        $is_bundle = $arr->is_combo_product;
                        $is_grouped = $arr->group_id;
                        // Flag to enable or disable sync.
                        $allow_to_import = false;
                        // Check if product exists with same sku.
                        if ($prod_id) {
                            $allow_to_import = false;
                            $zi_item_id = get_post_meta($prod_id, 'zi_item_id', true);
                            if (empty($zi_item_id)) {
                                // Map existing item with zoho id.
                                update_post_meta($prod_id, 'zi_item_id', $arr->item_id);
                            }
                        }

                        if ('' == $is_bundle && empty($is_grouped)) {
                            // If product not exists normal behavior of item sync.
                            $allow_to_import = true;
                        }
                        if (!empty($is_grouped)) {
                            $allow_to_import = false;
                            $this->sync_variation_of_group($arr);
                        }

                        global $wpdb;
                        $tbl = $wpdb->prefix;
                        $product_res = $wpdb->get_row('SELECT * FROM ' . $tbl . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $arr->item_id . "'");
                        if (!empty($product_res->post_id)) {
                            // fwrite($fd, PHP_EOL . 'Product Already there ');
                            $pdt_id = $product_res->post_id;
                        } elseif ($allow_to_import == true) {
                            // fwrite($fd, PHP_EOL . 'Product Import ');
                            $pdt_id = $this->zi_product_to_woocommerce($arr, $admin_author_id);
                            // fwrite($fd, PHP_EOL . 'After Import Done : ');
                            if ($pdt_id) {
                                // fwrite($fd, PHP_EOL . 'Update post meta');
                                update_post_meta($pdt_id, 'zi_item_id', $arr->item_id);
                            }
                        } else {
                            // fwrite($fd, PHP_EOL . 'Product import not allowed ');
                        }

                        if ($pdt_id) {
                            if (!empty($arr->category_name)) {
                                $term = get_term_by('name', $arr->category_name, 'product_cat');
                                $term_id = $term->term_id;
                                if (empty($term_id)) {
                                    $term = wp_insert_term(
                                        $arr->category_name,
                                        'product_cat',
                                        array(
                                            'description' => 'Imported from zoho',
                                            'parent' => 0,
                                        )
                                    );
                                    $term_id = $term['term_id'];
                                }
                                if ($term_id) {
                                    // update_post_meta($pdt_id, 'zi_category_id', $category);
                                    // wp_set_object_terms($pdt_id, $term_id, 'product_cat');
                                    $existingTerms = wp_get_object_terms($pdt_id, 'product_cat');
                                    if ($existingTerms && count($existingTerms) > 0) {
                                        $isTermsExist = $this->zi_check_terms_exists($existingTerms, $term_id);
                                        if (!$isTermsExist) {
                                            update_post_meta($pdt_id, 'zi_category_id', $category);
                                            wp_add_object_terms($pdt_id, $term_id, 'product_cat');
                                        }
                                    } else {
                                        update_post_meta($pdt_id, 'zi_category_id', $category);
                                        wp_set_object_terms($pdt_id, $term_id, 'product_cat');
                                    }
                                }
                            }

                            if (!empty($arr->brand)) {
                                wp_set_object_terms($pdt_id, $arr->brand, 'product_brand');
                            }
                            $item_ids[] = $arr->item_id;
                        } // end of wpdb post_id check
                    }
                    $item_id_str = implode(",", $item_ids);
                    // fwrite($fd, PHP_EOL . 'Before Bulk sync');
                    $item_details_url = "{$zoho_inventory_url}api/v1/itemdetails?item_ids={$item_id_str}&organization_id={$zoho_inventory_oid}";
                    $this->zi_item_bulk_sync($item_details_url);

                    foreach ($json->page_context as $key => $has_more) {
                        if ($key === 'has_more_page') {
                            if ($has_more) {
                                $data->page = $page++;
                                $this->sync_item_recursively($data);
                            } else {
                                // If there is no more page to sync last backup page will be starting from 1.
                                // This we have used because in shared hosting only 1000 records are syncing.
                                update_option('simple_item_sync_page_cat_id_' . $category, 1);
                            }
                        }
                    }
                } else {
                    array_push($response_msg, $this->zi_response_message($code, $json->message));
                }
                // fclose($fd);
                return $response_msg;
            }
        }
    }

    /**
     * Function to add group items recursively by manual sync
     *
     * @param [number] $page  - Page number for getting group item with pagination.
     * @param [number] $category - Category id to get group item of specific category.
     * @param [string] $source - Source from where function is calling : 'cron'/'sync'.
     * @return mixed
     */
    public function sync_groupitem_recursively($page, $source)
    {
        // $fd = fopen(__DIR__ . '/recursive_sync.txt', 'a+');
        // fwrite($fd, PHP_EOL . 'Test name Update ' . print_r($post_attributes, true));
        global $wpdb;

        // Conditional code to load file only if source is cron.
        $current_user = wp_get_current_user();
        $admin_author_id = $current_user->ID;
        // fwrite($fd, PHP_EOL . '$admin_author_id : ' . $admin_author_id);

        // Accounting stock mode check
        $accounting_stock = get_option('zoho_enable_accounting_stock_status');

        $zoho_inventory_oid = $this->config['ProductZI']['OID'];
        $zoho_inventory_url = $this->config['ProductZI']['APIURL'];

        $url = $zoho_inventory_url . 'api/v1/itemgroups/?organization_id=' . $zoho_inventory_oid . '&page=' . $page;
        // fwrite($fd, PHP_EOL . '$url : ' . $url);

        $executeCurlCallHandle = new ExecutecallClass();
        $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);

        $code = $json->code;
        // $message = $json->message;

        $response_msg = array();

        if ($code == '0' || $code == 0) {
            // fwrite($fd, PHP_EOL . '$json->itemgroups : ' . print_r($json->itemgroups, true));
            foreach ($json->itemgroups as $gpArr) {
                $zi_group_id = $gpArr->group_id;
                // fwrite($fd, PHP_EOL . '----------------');
                // fwrite($fd, PHP_EOL . 'Inside for each $zi_group_id : ' . $zi_group_id);
                // Create or update parent product and category.
                $zi_term_id = $this->sync_groupitem_category($zi_group_id, $page);
                // fwrite($fd, PHP_EOL . 'After term Id : ' . $zi_term_id);
                // if (intval($zi_term_id) > 0) {
                // fwrite($fd, PHP_EOL . 'Inside for each : after terms');

                // Get Group ID
                global $wpdb;
                $row = $wpdb->get_row('SELECT * FROM ' . $wpdb->prefix . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $zi_group_id . "'");
                $group_id = $row->post_id;
                array_push($response_msg, $this->zi_response_message('SUCCESS', 'Zoho variable synced for zoho Variable id ' . $zi_group_id, $group_id));
                /// end insert group product
                // variable items
                // fwrite($fd, PHP_EOL . 'Empty group Id $group_id ' . $group_id);
                if (!empty($group_id)) {
                    // fwrite($fd, PHP_EOL . 'Empty group Id');
                    $zi_disable_itemdescription_sync = get_option('zoho_disable_itemdescription_sync_status');
                    if (!empty($gpArr->description) && $zi_disable_itemdescription_sync != 'true') {
                        $wpdb->update($wpdb->prefix . 'posts', array('post_excerpt' => $gpArr->description), array('ID' => $group_id), array('%s'), array('%d'));
                    }
                    // Tags update.
                    $item_tags_hash = $gpArr->custom_field_hash;
                    $item_tags = $item_tags_hash->cf_tags;
                    // Tags
                    if (!empty($item_tags)) {
                        $final_tags = explode(',', $item_tags);
                        wp_set_object_terms($group_id, $final_tags, 'product_tag');
                    }

                    // fwrite($fd, PHP_EOL . 'Item JSON : ' . print_r($gpArr, true));
                    foreach ($gpArr->items as $itemArr) {
                        // fwrite($fd, PHP_EOL . '-------------For Each Item Array : ' . $itemArr->item_id);
                        // fwrite($fd, PHP_EOL . 'For Each Item Name : ' . $itemArr->name);
                        // fwrite($fd,PHP_EOL.'$itemArr->image_document_id : '.$itemArr->image_document_id);
                        global $wpdb;

                        $zi_item_id = $itemArr->item_id;
                        $rowItem = $wpdb->get_row('SELECT * FROM ' . $wpdb->prefix . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $zi_item_id . "'");
                        $variation_id = $rowItem->post_id;

                        if (!empty($variation_id)) {
                            $created_post = get_post($variation_id);
                        } else {
                            $created_post = null;
                        }
                        // Stock mode check
                        if ($accounting_stock) {
                            $stock = $itemArr->available_stock;
                        } else {
                            $stock = $itemArr->actual_available_stock;
                        }
                        // Sync variations if no variation Id or variation post is empty.
                        if (empty($variation_id) || (!empty($variation_id) && empty($created_post))) {
                            // fwrite($fd, PHP_EOL . '------Inside Create : ');
                            // Variation not exists please create variations.
                            if (!empty($variation_id)) {
                                $output = $wpdb->query($wpdb->prepare("DELETE FROM $wpdb->postmeta WHERE post_id='%s'", $variation_id));
                            }

                            $attribute_name11 = $itemArr->attribute_option_name1;
                            $attribute_name12 = $itemArr->attribute_option_name2;
                            $attribute_name13 = $itemArr->attribute_option_name3;

                            if (!empty($attribute_name11)) {

                                $attribute_arr[$gpArr->attribute_name1] = $attribute_name11;
                            }
                            if (!empty($attribute_name12)) {

                                $attribute_arr[$gpArr->attribute_name2] = $attribute_name12;
                            }
                            if (!empty($attribute_name13)) {

                                $attribute_arr[$gpArr->attribute_name3] = $attribute_name13;
                            }
                            // Create variation data
                            $variation_data = array(
                                'attributes' => $attribute_arr,
                                'sku' => $itemArr->sku,
                                'regular_price' => $itemArr->rate,
                                'stock_qty' => $stock,
                                'featured_image' => $itemArr->image_document_id,
                            );

                            $status = ($itemArr->status == 'active') ? 'publish' : 'draft';
                            $variation_post = array(
                                'post_title' => $itemArr->name,
                                'post_name' => $itemArr->name,
                                'post_status' => $status,
                                'post_parent' => $group_id,
                                'post_type' => 'product_variation',
                                'guid' => get_the_permalink($group_id),
                            );
                            if (!empty($variation_data['sku'])) {
                                $sku_prod_id = $this->get_product_by_sku($variation_data['sku']);
                                if (!empty($sku_prod_id)) {
                                    $created_post = get_post($sku_prod_id);
                                }
                                if (!empty($sku_prod_id) && !empty($created_post)) {
                                    // fwrite($fd, PHP_EOL . 'sku_prod_id :' . $sku_prod_id);
                                    $variation = new WC_Product_Variation($sku_prod_id);
                                    $variation_id = $sku_prod_id;
                                    // fwrite($fd, PHP_EOL . 'This is product having already exists sku: ' . print_r($variation, true));
                                } else {
                                    if (!empty($sku_prod_id)) {
                                        $output = $wpdb->query($wpdb->prepare("DELETE FROM $wpdb->postmeta WHERE post_id='%s'", $sku_prod_id));
                                    }

                                    // Creating the product variation
                                    $variation_id = wp_insert_post($variation_post);
                                    try {
                                        // Get an instance of the WC_Product_Variation object
                                        $variation = new WC_Product_Variation($variation_id);
                                        // fwrite($fd, PHP_EOL . 'Log 1: ');
                                        // Iterating through the variations attributes
                                        foreach ($variation_data['attributes'] as $attribute => $term_name) {
                                            update_post_meta($variation_id, 'attribute_' . strtolower(str_replace(' ', '-', $attribute)), trim($term_name));
                                            update_post_meta($variation_id, 'group_id_store', $group_id);
                                        }
                                        $variation->set_sku($variation_data['sku']);
                                    } catch (Exception $e) {
                                        // fwrite($fd, PHP_EOL . 'Exception Messages: ' . $e->getMessage());
                                    }
                                }
                            }
                            // fwrite($fd, PHP_EOL . 'Log 3: ');

                            // Prices
                            if (empty($variation_data['sale_price'])) {
                                $variation->set_price($variation_data['regular_price']);
                            }
                            // fwrite($fd, PHP_EOL . 'Before Image sync: ');
                            // Featured Image of variation
                            if (!empty($variation_data['featured_image'])) {
                                // fwrite($fd, PHP_EOL . 'Inside image sync: ');
                                $imageClass = new ImageClass();
                                $imageClass->args_attach_image($itemArr->item_id, $itemArr->name, $variation_id, $itemArr->image_name, $admin_author_id);
                            }
                            // fwrite($fd, PHP_EOL . 'Log 4: ');
                            $variation->set_regular_price($variation_data['regular_price']);
                            // fwrite($fd, PHP_EOL . 'Log 5: ');
                            // Stock
                            if (!empty($variation_data['stock_qty'])) {
                                $variation->set_stock_quantity($variation_data['stock_qty']);
                                $variation->set_manage_stock(true);
                                $variation->set_stock_status('');
                            } else {
                                $variation->set_manage_stock(false);
                            }
                            // fwrite($fd, PHP_EOL . 'Log 6: ');
                            $variation->set_weight(''); // weight (reseting)
                            $variation->save(); // Save the data
                            $zi_item_id = $itemArr->item_id;
                            update_post_meta($variation_id, 'zi_item_id', $zi_item_id);
                            // fwrite($fd, PHP_EOL . 'Log 7: ');
                            // End group item add process
                            array_push($response_msg, $this->zi_response_message('SUCCESS', 'Zoho variable item created for zoho item id ' . $zi_item_id, $variation_id));
                            // WC_Product_Variable::sync($group_id);
                            // fwrite($fd, PHP_EOL . 'Log 8: ');
                            unset($attribute_arr);
                            // fwrite($fd, PHP_EOL . 'Log 9: ');
                        } else {
                            // fwrite($fd, PHP_EOL . '--------Variations Available : ' . $variation_id);
                            // $zi_item_id = get_post_meta($variation_id, 'zi_item_id', true);
                            // if (intval($zi_item_id) == 0) {
                            // update_post_meta($variation_id, 'zi_item_id', $itemArr->item_id);
                            $variation = new WC_Product_Variation($variation_id);
                            ## Set/save all other data

                            // SKU
                            if (!empty($itemArr->sku)) {
                                $variation->set_sku($itemArr->sku);
                            }

                            // Prices
                            if (empty($itemArr->rate)) {
                                $variation->set_price($itemArr->rate);
                            }
                            $variation->set_regular_price($itemArr->rate);

                            // Stock
                            if (!empty($stock)) {
                                $variation->set_stock_quantity($stock);
                                $variation->set_manage_stock(true);
                                $variation->set_stock_status('');
                            } else {
                                $variation->set_manage_stock(false);
                            }

                            $variation->save(); // Save the data
                            // }
                            array_push($response_msg, $this->zi_response_message('SUCCESS', 'Zoho variable item synced for zoho item id ' . $zi_item_id, $variation_id));
                        }
                        // Create new variable product
                        $group_attrs = get_post_meta($group_id, '_product_attributes', true);
                        // fwrite($fd, PHP_EOL . '$group_attrs : ' . print_r($group_attrs, true));
                        if (is_array($group_attrs)) {
                            $z = 1;
                            foreach ($group_attrs as $key => $g_attr) {
                                $attribute_option_name = '';
                                if ($z == 1) {
                                    $attribute_option_name = trim($itemArr->attribute_option_name1);
                                } elseif ($z == 2) {
                                    $attribute_option_name = trim($itemArr->attribute_option_name2);
                                } elseif ($z == 3) {
                                    $attribute_option_name = trim($itemArr->attribute_option_name3);
                                }
                                $group_attr_value = $g_attr['value'];
                                if (!empty($group_attr_value)) {
                                    // Attribute has more than one value.
                                    if (strpos($group_attr_value, '|')) {
                                        $attr_array = explode('|', $group_attr_value);
                                        $trim_attr_array = array();
                                        // Remove white space from attribute array.
                                        foreach ($attr_array as $arr_val) {
                                            $trim_attr_array[] = trim($arr_val);
                                        }
                                        // Create unique list of attribute.
                                        if (!empty($trim_attr_array)) {
                                            $trim_attr_array = array_unique($trim_attr_array);
                                        }
                                        // Skip if attribute already exists in array.
                                        if (!in_array($attribute_option_name, $trim_attr_array)) {
                                            $trim_attr_array[] = $attribute_option_name;
                                            $group_attrs[$key]['value'] = implode(' | ', $trim_attr_array);
                                        }
                                    } else {
                                        // Attribute has one value. Check if attribute is an existing attribute value.
                                        if ($group_attr_value != $attribute_option_name) {
                                            $group_attrs[$key]['value'] = $group_attr_value . ' | ' . $attribute_option_name;
                                        }
                                    }
                                } elseif (!empty($attribute_option_name)) {

                                    $group_attrs[$key]['value'] = $attribute_option_name;
                                }
                                $z++;
                            }
                        }
                        update_post_meta($group_id, '_product_attributes', $group_attrs);
                        unset($group_attrs);
                    }
                } // end check if item exists

                // } //category id check
            } // end foreach group items
            foreach ($json->page_context as $key => $has_more) {
                if ($key === 'has_more_page') {
                    if ($has_more) {
                        // fwrite($fd, PHP_EOL . 'Has more called : ' . print_r($json->page_context, true));
                        $page++;
                        $this->sync_groupitem_recursively($page, $source);
                    }
                }
            }
        } else {
            array_push($response_msg, $this->zi_response_message($code, $json->message));
        }
        // fclose($fd);
        return $response_msg;
    }

    /**
     * Update or create variation in WooCommerce if Group-ID already exists in wpdB
     *
     * @param:  $arr - item object coming in from simple item recursive function
     * @return: void
     */
    public function sync_variation_of_group($itemArr)
    {
        // $fd = fopen(__DIR__ . '/sync_from_zoho.txt', 'a+');
        $item = $itemArr;
        // Stock mode check
        $accounting_stock = get_option('zoho_enable_accounting_stock_status');
        if ($accounting_stock) {
            $stock = $item->available_stock;
        } else {
            $stock = $item->actual_available_stock;
        }
        $item_id = $item->item_id;
        // $item_category = $item->category_name;
        $groupid = $item->group_id;
        $stock_quantity = $stock < 0 ? 0 : $stock;
        // fwrite($fd, PHP_EOL . 'Before group item sync : ' . $groupid);
        if (!empty($groupid)) {
            // fwrite($fd, PHP_EOL . 'Inside item sync : ' . $item_name);
            // find parent variable product
            global $wpdb;
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->postmeta WHERE meta_key='zi_item_id' AND meta_value='%s'", $groupid));
            $group_id = $row->post_id;
            // fwrite($fd, PHP_EOL . 'Row Data : ' . print_r($row, true));
            // fwrite($fd, PHP_EOL . 'Row $group_id : ' . $group_id);

            $item_tags_hash = $item->custom_field_hash;
            $item_tags = $item_tags_hash->cf_tags;
            $item_brand = $item->brand;

            // Tags
            if (!empty($item_tags)) {
                $final_tags = explode(',', $item_tags);
                wp_set_object_terms($group_id, $final_tags, 'product_tag');
            }
            // Brand
            if ($item_brand) {
                wp_set_object_terms($group_id, $item_brand, 'product_brand');
            }

            $rowItem = $wpdb->get_row($wpdb->prepare("SELECT * FROM $wpdb->postmeta WHERE meta_key='zi_item_id' AND meta_value='%s' LIMIT 1", $item_id));
            $variation_id = $rowItem->post_id;
            if ($variation_id) {
                // SKU - Imported
                if (!empty($item->sku)) {
                    update_post_meta($variation_id, '_sku', $item->sku);
                }

                // Price - Imported
                $zi_disable_itemprice_sync = get_option('zoho_disable_itemprice_sync_status');
                $variation_sale_price = get_post_meta($variation_id, '_sale_price', true);
                if (empty($variation_sale_price) && $zi_disable_itemprice_sync != 'true') {
                    update_post_meta($variation_id, '_price', $item->rate);
                    // $variation->set_price($itemArr->rate);
                }
                update_post_meta($variation_id, '_regular_price', $item->rate);

                // Stock Imported code
                update_post_meta($variation_id, '_stock', $stock_quantity);
                update_post_meta($variation_id, 'stock_qty', $stock_quantity);
                if ($stock_quantity > 0) {
                    $status = 'instock';
                    update_post_meta($variation_id, '_stock_status', wc_clean($status));
                    // wp_set_post_terms($variation_id, $status, 'product_visibility', true);
                    update_post_meta($variation_id, 'manage_stock', true);
                } else {
                    // $variation->set_manage_stock(false);
                    $backorder_status = get_post_meta($variation_id, '_backorders', true);
                    $status = ($backorder_status === 'yes') ? 'onbackorder' : 'outofstock';
                    update_post_meta($variation_id, '_stock_status', wc_clean($status));
                    // update_post_meta($variation_id, '_stock_status', wc_clean('outofstock'));
                    update_post_meta($variation_id, 'manage_stock', false);
                }
            } else {
                // create new variation
                // fwrite($fd, PHP_EOL . 'Variations not');

                $attribute_name11 = $item->attribute_option_name1;
                $attribute_name12 = $item->attribute_option_name2;
                $attribute_name13 = $item->attribute_option_name3;

                if (!empty($attribute_name11)) {

                    $attribute_arr[$item->attribute_name1] = $attribute_name11;
                }
                if (!empty($attribute_name12)) {

                    $attribute_arr[$item->attribute_name2] = $attribute_name12;
                }
                if (!empty($attribute_name13)) {

                    $attribute_arr[$item->attribute_name3] = $attribute_name13;
                }
                $variation_data = array(
                    'attributes' => $attribute_arr,
                    'sku' => $item->sku,
                    'regular_price' => $item->rate,
                    'stock_qty' => $stock_quantity,
                );

                $status = ($item->status == 'active') ? 'publish' : 'draft';
                $variation_post = array(
                    'post_title' => $item->name,
                    'post_name' => $item->name,
                    'post_status' => $status,
                    'post_parent' => $group_id,
                    'post_type' => 'product_variation',
                    'guid' => get_the_permalink($group_id),
                );

                // Map variation based on sku
                if (!empty($variation_data['sku'])) {
                    // here we do actual mapping based on same sku
                    // fwrite($fd, PHP_EOL . 'Before SKU :' . $variation_data['sku']);
                    $sku_prod_id = $this->get_product_by_sku($variation_data['sku']);
                    // fwrite($fd, PHP_EOL . 'Before $sku_prod_id :' . $sku_prod_id);
                    if (!empty($sku_prod_id)) {
                        // fwrite($fd, PHP_EOL . 'sku_prod_id :' . $sku_prod_id);
                        $variation_id = $sku_prod_id;
                        // fwrite($fd, PHP_EOL . 'This is product having already exists sku: ' . print_r($variation, true));
                    } else {
                        // here actually create new variation because sku not found
                        $variation_id = wp_insert_post($variation_post);
                        update_post_meta($variation_id, '_sku', $variation_data['sku']);
                        // fwrite($fd, PHP_EOL . '$variation_2 : ');
                    }
                }
                // Creating the product variation
                // $variation_id = wp_insert_post($variation_post);

                // fwrite($fd, PHP_EOL . 'This is Variations : ' . print_r($variation, true));
                // Iterating through the variations attributes
                foreach ($variation_data['attributes'] as $attribute => $term_name) {
                    update_post_meta($variation_id, 'attribute_' . strtolower(str_replace(' ', '-', $attribute)), trim($term_name));
                    update_post_meta($variation_id, 'group_id_store', $group_id);
                }

                // Prices
                // $variation->set_regular_price($variation_data['regular_price']);
                update_post_meta($variation_id, '_regular_price', $variation_data['regular_price']);
                $variation_sale_price = get_post_meta($variation_id, '_sale_price', true);
                if (empty($variation_sale_price)) {
                    // $variation->set_price($variation_data['regular_price']);
                    update_post_meta($variation_id, '_price', $variation_data['regular_price']);
                }
                // Stock
                update_post_meta($variation_id, '_stock', $stock_quantity);
                update_post_meta($variation_id, 'stock_qty', $stock_quantity);
                if (!empty($variation_data['stock_qty'])) {
                    // update_post_meta($variation_id, '_stock', $variation_data['stock_qty']);
                    update_post_meta($variation_id, 'manage_stock', true);
                    update_post_meta($variation_id, '_stock_status', 'instock');
                    // $variation->set_stock_status('');
                } else {
                    $backorder_status = get_post_meta($variation_id, '_backorders', true);
                    if ($backorder_status === 'yes') {
                        update_post_meta($variation_id, '_stock_status', 'onbackorder');
                    } else {
                        update_post_meta($variation_id, '_stock_status', 'outofstock');
                    }
                    update_post_meta($variation_id, 'manage_stock', false);
                }

                // $variation->set_weight(''); // weight (reseting)
                // $variation->save(); // Save the data
                update_post_meta($variation_id, 'zi_item_id', $item_id);

                // End group item add process
                wc_delete_product_transients($variation_id); // Clear/refresh the variation cache
                unset($attribute_arr);
            }
            // end of grouped item updating
        } else {
            // fwrite($fd, PHP_EOL . 'Group item empty');
        }
        // fwrite($fd, PHP_EOL . 'After group item sync');
        // fclose($fd);
    }

    /**
     * Function to get product_id from sku
     * @param [string] - sku of product
     * @return product_id
     */
    public function get_product_by_sku($sku)
    {
        global $wpdb;
        $product_id = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1", $sku));
        return $product_id;
    }

    // variable category check functionality
    public function sync_groupitem_category($zi_group_id, $page)
    {
        // $fd = fopen(__DIR__ . '/category.txt', 'w+');
        // fwrite($fd,PHP_EOL.'-----------------------');
        $term_id = 0;
        $attr = '';

        // Conditional code to load file only if source is cron.
        // $current_user    = wp_get_current_user();
        // $admin_author_id = $current_user->ID;

        $zoho_inventory_oid = $this->config['ProductZI']['OID'];
        $zoho_inventory_url = $this->config['ProductZI']['APIURL'];

        $url = $zoho_inventory_url . 'api/v1/itemgroups/' . $zi_group_id . '?organization_id=' . $zoho_inventory_oid;

        $executeCurlCallHandle = new ExecutecallClass();
        $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);

        $code = $json->code;
        $message = $json->message;

        // Response for item sync with sync button. For cron sync blank array will return.
        // $response_msg = array();
        // fwrite($fd, PHP_EOL . '$url  : ' . $url);
        // fwrite($fd, PHP_EOL . '$code  : ' . $code  . ' : ' . $message);
        // fwrite($fd, PHP_EOL . '$term_id : ' . $term_id . ' : ' . $zi_group_id);
        if ($code == '0' || $code == 0) {
            // fwrite($fd, PHP_EOL . '$json->item_group : ' . print_r($json->item_group,true));
            foreach ($json->item_group as $key => $arr) {
                // fwrite($fd, PHP_EOL . '$term_id 3 : ' . $term_id);
                // Code to skip sync with item already exists with same sku.

                // $opt_category = get_option('zoho_item_category');
                // if ($opt_category) {
                //     $opt_category = unserialize($opt_category);
                // } else {
                //     $opt_category = array();
                // }

                if ($key == 'category_id') {
                    $zi_category_id = $arr;
                }
                if ($key == 'category_name') {
                    $zi_category_name = $arr;
                }

                // fwrite($fd, PHP_EOL . '$zi_category_name : ' . $zi_category_name);
                // if (in_array($zi_category_id, $opt_category)) { // closing of category id check.
                // fwrite($fd, PHP_EOL . '$term_id 4 : ' . $term_id);
                global $wpdb;

                $tbl = $wpdb->prefix;
                $product_res = $wpdb->get_row('SELECT * FROM ' . $tbl . "postmeta WHERE meta_key='zi_item_id' AND meta_value='" . $zi_group_id . "'");

                $pdt_id = intval($product_res->post_id);
                if ($pdt_id == 0) {

                    if ($key == 'group_name') {

                        $group_name = $arr;
                    }

                    $post_data = array(
                        'post_title' => $group_name,
                        'post_status' => 'publish',
                        'post_author' => 1,
                        'post_type' => 'product',
                    );

                    // Lets insert the post now.
                    $pdt_id = wp_insert_post($post_data);

                    update_post_meta($pdt_id, 'zi_item_id', $zi_group_id);
                } // group insert
                // fwrite($fd,PHP_EOL.'$pdt_id : '.$pdt_id);
                if (trim($key) == 'attribute_name1') {

                    $attribute_name1 = $arr;
                }
                if (trim($key) == 'attribute_name2') {

                    $attribute_name2 = $arr;
                }
                if (trim($key) == 'attribute_name3') {

                    $attribute_name3 = $arr;
                }

                if (!empty($attribute_name1)) {

                    update_post_meta($pdt_id, 'attribute_name1', $attribute_name1);

                    $attr[$attribute_name1] = array('name' => $attribute_name1, 'value' => '', 'position' => '0', 'is_visible' => '1', 'is_variation' => '1', 'is_taxonomy' => '0');
                }
                if (!empty($attribute_name2)) {

                    update_post_meta($pdt_id, 'attribute_name2', $attribute_name2);

                    $attr[$attribute_name2] = array('name' => $attribute_name2, 'value' => '', 'position' => '1', 'is_visible' => '1', 'is_variation' => '1', 'is_taxonomy' => '0');
                }
                if (!empty($attribute_name3)) {

                    update_post_meta($pdt_id, 'attribute_name3', $attribute_name3);

                    $attr[$attribute_name3] = array('name' => $attribute_name3, 'value' => '', 'position' => '3', 'is_visible' => '1', 'is_variation' => '1', 'is_taxonomy' => '0');
                }

                update_post_meta($pdt_id, '_product_attributes', $attr);

                unset($attr);

                wp_set_object_terms($pdt_id, 'variable', 'product_type');

                if (!empty($pdt_id) && $zi_category_name != '') {
                    // fwrite($fd, PHP_EOL . '$term_id : 5' . $term_id);
                    // $category_id = get_cat_ID( $arr->category_name );
                    $term = get_term_by('name', $zi_category_name, 'product_cat');
                    $term_id = $term->term_id;
                    // fwrite($fd, PHP_EOL . 'Term Id by Name ' . $term_id);
                    if (empty($term_id)) {
                        $term = wp_insert_term(
                            $zi_category_name,
                            'product_cat',
                            array(
                                'description' => 'Imported from zoho',
                                'parent' => 0,
                            )
                        );
                        $term_id = $term->term_id;
                    }
                    // fwrite($fd, PHP_EOL . 'Term Id after insert ' . $term_id);
                    // If term id and zoho category id then import category.
                    if ($term_id && $zi_category_id) {
                        // update_post_meta($pdt_id, 'zi_category_id', $zi_category_id);
                        // update_post_meta($pdt_id, 'category_id', $term_id);
                        // $resp = wp_set_object_terms($pdt_id, $term_id, 'product_cat');
                        $existingTerms = wp_get_object_terms($pdt_id, 'product_cat');
                        if ($existingTerms && count($existingTerms) > 0) {
                            $isTermsExist = $this->zi_check_terms_exists($existingTerms, $term_id);
                            if (!$isTermsExist) {
                                update_post_meta($pdt_id, 'zi_category_id', $zi_category_id);
                                wp_add_object_terms($pdt_id, $term_id, 'product_cat');
                            }
                        } else {
                            update_post_meta($pdt_id, 'zi_category_id', $zi_category_id);
                            wp_set_object_terms($pdt_id, $term_id, 'product_cat');
                        }
                    }
                }
                // } // closing of category check.
            } // item for each end
        }
        // fwrite($fd, PHP_EOL . 'Return $term_id : ' . $term_id);
        // fclose($fd);
        return $term_id;
    }

/**
 * Helper Function to check if child of composite items already synced  or not
 *
 * @param string $composite_zoho_id - zoho composite item id to check if it's child are already synced.
 * @param string $zi_url - zoho api url.
 * @param string $zi_key - zoho access token.
 * @param string $zi_org_id - zoho organization id.
 * @return array of child id and metadata if child item already synced else will return false.
 */
    public function zi_check_if_child_synced_already($composite_zoho_id, $zi_url, $zi_org_id, $prod_id)
    {
        if ($prod_id) {
            $bundle_childs = WC_PB_DB::query_bundled_items(
                array(
                    'return' => 'id=>product_id',
                    'bundle_id' => array($prod_id),
                )
            );
        }
        global $wpdb;

        $url = $zi_url . 'api/v1/compositeitems/' . $composite_zoho_id . '?organization_id=' . $zi_org_id;

        $executeCurlCallHandle = new ExecutecallClass();
        $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
        $code = $json->code;
        // Flag to allow sync of parent composite item.
        $allow_sync = false;
        // Array of child object metadata.
        $product_array = array(); // [{prod_id:'',metadata:{key:'',value:''}},...].
        if ('0' === $code || 0 === $code) {
            foreach ($json->composite_item->mapped_items as $child_item) {
                $prod_meta = $wpdb->get_row('SELECT * FROM ' . $wpdb->postmeta . " WHERE meta_key='zi_item_id' AND meta_value='" . $child_item->item_id . "'");
                // If any child will not have zoho id in meta field then process will return false and syncing will be skipped for given item.
                if (!empty($prod_meta->post_id)) {

                    $allow_sync = true;
                    $prod_obj = (object) array(
                        'prod_id' => $prod_meta->post_id,
                        'metadata' => (object) array(
                            'quantity_min' => max(1, $child_item->quantity),
                            'quantity_max' => max(1, $child_item->quantity),
                            'stock_status' => ($child_item->stock_on_hand) ? 'in_stock' : 'out_of_stock',
                            'max_stock' => $child_item->stock_on_hand,
                        ),
                    );
                    $index = array_search($prod_meta->post_id, $bundle_childs);
                    unset($bundle_childs[$index]);
                    array_push($product_array, $prod_obj);
                } else {
                    // Stop execution
                    return false;
                }
            }
        }
        if ($bundle_childs && count($bundle_childs) > 0) {
            foreach ($bundle_childs as $item_id => $val) {
                WC_PB_DB::delete_bundled_item($item_id);
            }
        }
        if ($allow_sync) {
            return $product_array;
        }
        return false;
    }
/**
 * Mapping of bundled product
 *
 * @param number $product_id - Product id of child item of bundle product.
 * @param number $bundle_id  - BUndle id of product.
 * @param number $menu_order - Listing order of child product ($menu_order will useful at composite product details page).
 * @return void
 */
    public function add_bundle_product($product_id, $bundle_id, $menu_order = 0)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_bundled_items';
        $bundle_items = $wpdb->get_results("SELECT * FROM $table WHERE bundle_id = $bundle_id AND product_id = $product_id");

        if (count($bundle_items) > 0) {
            $wpdb->get_results("UPDATE $table SET menu_order = $menu_order WHERE product_id = $product_id AND bundle_id = $bundle_id");
            return $bundle_items[0]->bundled_item_id;
        } else {
            $wpdb->get_results("INSERT INTO $table (product_id, bundle_id, menu_order) VALUES ( $product_id, $bundle_id, $menu_order)");

            $bundle_items = $wpdb->get_results("SELECT * FROM $table WHERE bundle_id = $bundle_id AND product_id = $product_id");
            if (count($bundle_items) > 0) {
                return $bundle_items[0]->bundled_item_id;
            } else {
                return false;
            }
        }
    }

/**
 * Create or update bundle item metadata
 *
 * @param number $bundle_item_id bundle item id.
 * @param string $key - metadata key.
 * @param string $value - metadata value.
 * @return void
 */

    public function zi_update_bundle_meta($bundle_item_id, $key, $value)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_bundled_itemmeta';
        $metadata = $wpdb->get_results("SELECT * FROM $table WHERE bundled_item_id = $bundle_item_id AND meta_key = '$key'");
        if (count($metadata) > 0) {
            $wpdb->get_results("UPDATE $table SET meta_value = '$value' WHERE bundled_item_id = $bundle_item_id AND meta_key = '$key'");
        } else {
            $wpdb->get_results("INSERT INTO $table (bundled_item_id, meta_key, meta_value) VALUES ( $bundle_item_id, '$key', '$value')");
        }
    }

/**
 * Function to sync composite item from zoho to woocommerce
 *
 * @param number $page - Page number of composit item data.
 * @param string $category - Category id of composite data.
 * @param string $source - Source of calling function.
 * @return mixed - mostly array of response message.
 */
    public function recursively_sync_composite_item_from_zoho($page, $category, $source)
    {
        global $wpdb;
        $tbl_prefix = $wpdb->prefix;
        $zi_org_id = get_option('zoho_inventory_oid');
        $zi_url = get_option('zoho_inventory_url');
        // Conditional code to load file only if source is cron.
        if ('cron' === $source) {
            // get admin user id who started the cron job.
            $admin_author_id = get_option('zi_cron_admin');
        } else {
            $current_user = wp_get_current_user();
            $admin_author_id = $current_user->ID;
        }

        $url = $zi_url . 'api/v1/compositeitems/?organization_id=' . $zi_org_id . '&category_id=' . $category . '&page=' . $page;

        $executeCurlCallHandle = new ExecutecallClass();
        $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
        $code = $json->code;
        $message = $json->message;

        // To get cron class and skip log if cron for 1 min.
        // $zi_cron_class = get_option('zoho_inventory_cron_class');

        // Response for item sync with sync button. For cron sync blank array will return.
        $response_msg = array();
        if ($code == '0' || $code == 0) {
            if (empty($json->composite_items)) {
                array_push($response_msg, $this->zi_response_message('ERROR', 'No composite item to sync for category : ' . $category));
                return $response_msg;
            }
            // Accounting stock mode check
            $accounting_stock = get_option('zoho_enable_accounting_stock_status');
            foreach ($json->composite_items as $comp_item) {
                if ($accounting_stock) {
                    $stock = $comp_item->available_stock;
                } else {
                    $stock = $comp_item->actual_available_stock;
                }
                // ----------------- Create composite item in woocommerce--------------.
                // Code to skip sync with item already exists with same sku.
                $prod_id = $this->get_product_by_sku($comp_item->sku);
                // Flag to enable or disable sync.
                $allow_to_import = false;
                // Check if product exists with same sku.
                if ($prod_id) {
                    $zi_item_id = get_post_meta($prod_id, 'zi_item_id', true);
                    if ($zi_item_id) {
                        // If product is with same sku and zi_item_id mapped.
                        // Do not import ...
                        $allow_to_import = false;
                    } else {
                        // Map existing item with zoho id.
                        update_post_meta($prod_id, 'zi_item_id', $comp_item->item_id);
                        $allow_to_import = false;
                    }
                } else {
                    // If product not exists normal bahaviour of item sync.
                    $allow_to_import = true;
                }
                $zoho_comp_item_id = $comp_item->composite_item_id;
                if ($comp_item->composite_item_id) {
                    $child_items = $this->zi_check_if_child_synced_already($zoho_comp_item_id, $zi_url, $zi_org_id, $prod_id);
                    // Check if child items already synced with zoho.
                    if (!$child_items) {
                        array_push($response_msg, $this->zi_response_message('ERROR', 'Child not synced for composite item : ' . $zoho_comp_item_id));
                        continue;
                    }
                    $product_res = $wpdb->get_row('SELECT * FROM ' . $wpdb->postmeta . " WHERE meta_key='zi_item_id' AND meta_value='" . $zoho_comp_item_id . "'");
                    if (!empty($product_res->post_id)) {
                        $com_prod_id = $product_res->post_id;
                    } else {
                        // Check if item is allowed to import or not.
                        if ($allow_to_import) {
                            $com_prod_id = $this->zi_product_to_woocommerce($comp_item, $admin_author_id, 'composite');
                            update_post_meta($com_prod_id, 'zi_item_id', $zoho_comp_item_id);
                        } else {
                            // Import not allowed.
                        }
                    }
                }
                // Map composite items to database.
                if (!empty($com_prod_id)) {
                    wp_set_object_terms($com_prod_id, 'bundle', 'product_type');
                    foreach ($child_items as $child_prod) {
                        // Adding product to bundle.
                        $child_bundle_id = $this->add_bundle_product($child_prod->prod_id, $com_prod_id);
                        if ($child_bundle_id) {
                            foreach ($child_prod->metadata as $bundle_meta_key => $bundle_meta_val) {
                                $this->zi_update_bundle_meta($child_bundle_id, $bundle_meta_key, $bundle_meta_val);
                            }
                        }
                    }
                }
                // --------------------------------------------------------------------.

                $is_synced_flag = false; // loggin purpose only .

                // Tags update.
                if (!empty($com_prod_id)) {
                    $item_tags_hash = $comp_item->custom_field_hash;
                    $item_tags = $item_tags_hash->cf_tags;

                    if (!empty($item_tags)) {
                        $final_tags = explode(',', $item_tags);
                        wp_set_object_terms($com_prod_id, $final_tags, 'product_tag');
                    }
                }

                foreach ($comp_item as $key => $value) {
                    if ($key == 'status') {
                        if (!empty($com_prod_id)) {
                            $status = $value == 'active' ? 'publish' : 'draft';
                            $wpdb->update($tbl_prefix . 'posts', array('post_status' => $status), array('ID' => $com_prod_id), array('%s'), array('%d'));
                        }
                    }
                    if ($key == 'description') {
                        if (!empty($com_prod_id) && !empty($value)) {
                            $wpdb->update($tbl_prefix . 'posts', array('post_excerpt' => $value), array('ID' => $com_prod_id), array('%s'), array('%d'));
                        }
                    }
                    if ($key == 'name') {
                        if (!empty($com_prod_id)) {
                            $wpdb->update($tbl_prefix . 'posts', array('post_title' => $value), array('ID' => $com_prod_id), array('%s'), array('%d'));
                        }
                    }
                    if ($key == 'sku') {
                        if (!empty($com_prod_id)) {
                            update_post_meta($com_prod_id, '_sku', $value);
                        }
                    }
                    // Check if stock sync allowed by plugin.
                    if ($key === 'available_stock' || $key === 'actual_available_stock') {
                        $zi_stock_sync = get_option('zoho_stock_sync_status');
                        if ($zi_stock_sync != 'true') {
                            if ($stock) {
                                if (!empty($com_prod_id)) {
                                    // If value is less than 0 default 1.
                                    $stock_quantity = $stock < 0 ? 0 : $stock;
                                    update_post_meta($com_prod_id, '_stock', number_format($stock_quantity, 0, '.', ''));
                                    if ($stock_quantity > 0) {
                                        $status = 'instock';
                                    } else {
                                        $backorder_status = get_post_meta($com_prod_id, '_backorders', true);
                                        $status = ($backorder_status === 'yes') ? 'onbackorder' : 'outofstock';
                                    }
                                    update_post_meta($com_prod_id, '_stock_status', wc_clean($status));
                                    wp_set_post_terms($com_prod_id, $status, 'product_visibility', true);
                                    update_post_meta($com_prod_id, '_wc_pb_bundled_items_stock_status', wc_clean($status));
                                }
                            }
                        }
                    }
                    if ($key == 'rate') {
                        if (!empty($com_prod_id)) {
                            $sale_price = get_post_meta($com_prod_id, '_sale_price', true);
                            if (empty($sale_price)) {
                                update_post_meta($com_prod_id, '_price', $value);
                                update_post_meta($com_prod_id, '_regular_price', $value);
                                update_post_meta($com_prod_id, '_wc_pb_base_price', $value);
                                update_post_meta($com_prod_id, '_wc_pb_base_regular_price', $value);
                                update_post_meta($com_prod_id, '_wc_sw_max_regular_price', $value);
                            } else {
                                update_post_meta($com_prod_id, '_regular_price', $value);
                                update_post_meta($com_prod_id, '_wc_pb_base_price', $value);
                                update_post_meta($com_prod_id, '_wc_pb_base_regular_price', $value);
                                update_post_meta($com_prod_id, '_wc_sw_max_regular_price', $value);
                            }
                        }
                    } elseif ($key == 'image_document_id') {
                        if (!empty($com_prod_id) && $value) {
                            $imageClass = new ImageClass();
                            $imageClass->args_attach_image($comp_item->item_id, $comp_item->name, $com_prod_id, $comp_item->image_name, $admin_author_id);
                        }
                    } elseif ($key == 'category_name') {
                        if (!empty($com_prod_id) && $comp_item->category_name != '') {
                            $term = get_term_by('name', $comp_item->category_name, 'product_cat');
                            $term_id = $term->term_id;
                            if (empty($term_id)) {
                                $term = wp_insert_term(
                                    $comp_item->category_name,
                                    'product_cat',
                                    array(
                                        'description' => 'Imported from zoho',
                                        'parent' => 0,
                                    )
                                );
                                $term_id = $term['term_id'];
                            }
                            if ($term_id) {
                                // update_post_meta($com_prod_id, 'zi_category_id', $category);
                                // wp_set_object_terms($com_prod_id, $term_id, 'product_cat');
                                $existingTerms = wp_get_object_terms($com_prod_id, 'product_cat');
                                if ($existingTerms && count($existingTerms) > 0) {
                                    $isTermsExist = $this->zi_check_terms_exists($existingTerms, $term_id);
                                    if (!$isTermsExist) {
                                        update_post_meta($com_prod_id, 'zi_category_id', $category);
                                        wp_add_object_terms($com_prod_id, $term_id, 'product_cat');
                                    }
                                } else {
                                    update_post_meta($com_prod_id, 'zi_category_id', $category);
                                    wp_set_object_terms($com_prod_id, $term_id, 'product_cat');
                                }
                            }
                        }
                    }
                }

                // sync dimensions and weight
                $item_url = "{$zi_url}api/v1/compositeitems/{$comp_item->composite_item_id}?organization_id={$zi_org_id}";
                $this->zi_item_dimension_weight($item_url, $com_prod_id, true);

                // If item synced append to log : logging purpose only.
                if ($is_synced_flag) {
                    array_push($response_msg, $this->zi_response_message('SUCCESS', 'Composite item synced for id : ' . $comp_item->composite_item_id, $com_prod_id));
                }
            }
            foreach ($json->page_context as $key => $has_more) {
                if ($key === 'has_more_page') {
                    if ($has_more) {
                        $page++;
                        $this->recursively_sync_composite_item_from_zoho($page, $category, $source);
                    }
                }
            }
        } else {
            array_push($response_msg, $this->zi_response_message($code, $json->message));
        }
        return $response_msg;
    }

    /**
     * Function to retrieve item details, update weight and dimensions.
     *
     * @param string $url - URL to ge details.
     * @return mixed return true if data false if error.
     */
    public function zi_item_dimension_weight($url, $product_id, $is_composite = false)
    {
        // Check if item is for syncing purpose.
        $executeCurlCallHandle = new ExecutecallClass();
        $json = $executeCurlCallHandle->ExecuteCurlCallGet($url);
        $code = $json->code;
        $message = $json->message;
        if (0 == $code || '0' == $code) {
            if ($is_composite) {
                $details = $json->composite_item->package_details;
            } else {
                $details = $json->item->package_details;
            }
            update_post_meta($product_id, '_weight', floatval($details->weight));
            update_post_meta($product_id, '_length', floatval($details->length));
            update_post_meta($product_id, '_width', floatval($details->width));
            update_post_meta($product_id, '_height', floatval($details->height));
            update_post_meta($product_id, '_weight_unit', $details->weight_unit);
            update_post_meta($product_id, '_dimension_unit', $details->dimension_unit);
        } else {
            false;
        }
    }

    /**
     * Create response object based on data.
     *
     * @param mixed  $index_col - Index value error message.
     * @param string $message - Response message.
     * @return object
     */
    public function zi_response_message($index_col, $message, $woo_id = '')
    {
        return (object) array(
            'resp_id' => $index_col,
            'message' => $message,
            'woo_prod_id' => $woo_id,
        );
    }

    /**
     * Helper Function to check if terms already exists.
     */
    public function zi_check_terms_exists($existingTerms, $term_id)
    {
        foreach ($existingTerms as $woo_existing_term) {
            if ($woo_existing_term->term_id === $term_id) {
                return true;
            } else {
                return false;
            }
        }
    }

}
