<?php
/**
 * Plugin Name: WooCommerce Zoho Inventory - Start
 * Plugin URI:  https//roadmapstudios.com
 * Description: Connect your Zoho Inventory with your WooCommerce store in realtime to sync Customers, Items and Sales Orders. Manage your whole inventory from Zoho or from WooCommerce. Please follow the documentation "Getting Started" before you use this plugin.
 * Version:     3.8.17
 * Author:      Roadmap Studios
 * Author URI:  https://roadmapstudios.com
 * Requires PHP: 7.2
 * Domain Path: /languages
 * Text Domain: rmsZI

 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package WooZo_Inventory
 * @license GNU General Public License v3.0
 *
 * WC requires at least: 6.1.0
 * WC tested up to: 7.2.3
 */

if (!defined('ABSPATH')) {
    define('ABSPATH', '') or die('No script kiddies please!');
}
if (!defined('RMS_PLUGIN_NAME')) {
    define('RMS_PLUGIN_NAME', 'Zoho Inventory');

}
if (!defined('RMS_VERSION')) {
    define('RMS_VERSION', '3.8.17');

}
if (!defined('RMS_DIR_PATH')) {
    define('RMS_DIR_PATH', plugin_dir_path(__FILE__));

}
if (!defined('RMS_DIR_URL')) {
    define('RMS_DIR_URL', plugin_dir_url(__FILE__));

}
if (!defined('RMS_BASENAME')) {
    define('RMS_BASENAME', plugin_basename(__FILE__));

}
if (!defined('RMS_MENU_SLUG')) {
    define('RMS_MENU_SLUG', 'zoho-inventory');
}
if (!defined('RMS_DOCUMENTATION_URL')) {
    define('RMS_DOCUMENTATION_URL', 'https://support.roadmapstudios.com/portal/en/kb/zoho-inventory-woocommerce');
}
if (!defined('RMS_PLUGIN_URL')) {
    define('RMS_PLUGIN_URL', 'https://roadmapstudios.com/product/woocommerce-zoho-inventory/');
}

include_once RMS_DIR_PATH . 'includes/classes/auth.php';
include_once RMS_DIR_PATH . 'includes/classes/execute-curl-call-class.php';
include_once RMS_DIR_PATH . 'includes/classes/multi-currency-class.php';
include_once RMS_DIR_PATH . 'includes/classes/users-contact-class.php';
include_once RMS_DIR_PATH . 'includes/classes/package-saleorders-class.php';
include_once RMS_DIR_PATH . 'includes/classes/product-class.php';
include_once RMS_DIR_PATH . 'includes/classes/thankyou-order-class.php';
include_once RMS_DIR_PATH . 'includes/classes/class-common.php';
include_once RMS_DIR_PATH . 'includes/classes/import-items-class.php';
include_once RMS_DIR_PATH . 'includes/classes/import-image-class.php';
include_once RMS_DIR_PATH . 'includes/woo-functions.php';
include_once RMS_DIR_PATH . 'includes/class-loader.php';
include_once RMS_DIR_PATH . 'includes/class-client.php';
include_once RMS_DIR_PATH . 'includes/class-endpoints.php';
include_once RMS_DIR_PATH . 'includes/class-tgm-plugin-activation.php';
include_once RMS_DIR_PATH . 'includes/sync/order-backend.php';
include_once RMS_DIR_PATH . 'includes/sync/order-frontend.php';

include_once RMS_DIR_PATH . 'data-sync.php';
include_once RMS_DIR_PATH . 'lib/wp-background-process/wp-background-processing.php';

require_once __DIR__ . '/includes/config.php';
require __DIR__ . '/vendor/autoload.php';

global $zi_plugin_prod_id;
global $zi_plugin_version;

/* Check the minimum PHP version on activation hook */
if (!empty($GLOBALS['pagenow']) && 'plugins.php' === $GLOBALS['pagenow']) {
    add_action('admin_notices', 'woozo_check_admin_notices', 0);
}

function woozo_check_plugin_requirements()
{
    $php_min_version = '7.2';
    $errors = array();
    $php_current_version = phpversion();
    if (version_compare($php_min_version, $php_current_version, '>')) {
        $errors[] = "Your server is running PHP version $php_current_version but this plugin requires at least PHP $php_min_version. Please run an upgrade.";
    }

    return $errors;
}
function woozo_check_admin_notices()
{
    $errors = woozo_check_plugin_requirements();

    if (empty($errors)) {
        return;
    }

    // Suppress "Plugin activated" notice.
    unset($_GET['activate']);

    // this plugin's name
    $name = get_file_data(__FILE__, array('WooCommerce Zoho Inventory'), 'plugin');

    printf(
        '<div class="error"><p>%1$s</p>
        <p><i>WooCommerce Zoho Inventory</i> has been deactivated.</p></div>',
        join('</p><p>', $errors),
        $name[0]
    );
    deactivate_plugins(plugin_basename(__FILE__));
}

/**
 * Function for initializing plugin object.
 */
if (class_exists('WC_WooZo_Client')) {
    $wcam_lib = new WC_WooZo_Client(__FILE__, $zi_plugin_prod_id, $zi_plugin_version, 'plugin', 'https://roadmapstudios.com/', 'WooCommerce Zoho Inventory');

    if (is_admin() && isset($_GET['page']) && $_GET['page'] == 'zoho-inventory') {
        // Code to check plugin activation key validity.
        $api_key_option = get_option($wcam_lib->data_key);
        $args = array();
        if (!empty($api_key_option)) {
            $wc_am_instance_id = get_option($wcam_lib->data_key . '_instance');
            $wc_am_domain = str_ireplace(array('http://', 'https://'), '', home_url());

            $defaults = array(
                'request' => 'status',
                'product_id' => $wcam_lib->product_id,
                'instance' => $wc_am_instance_id,
                'object' => $wc_am_domain,
            );
            $wc_am_api_key = $api_key_option[$wcam_lib->data_key . '_api_key'];
            $args = array(
                'api_key' => $wc_am_api_key,
            );

            $args = wp_parse_args($defaults, $args);
            $target_url = esc_url_raw($wcam_lib->create_software_api_url($args));
            $request = wp_safe_remote_post($target_url, array('timeout' => 15));

            if (is_wp_error($request) || wp_remote_retrieve_response_code($request) != 200) {
                // Request failed
                return false;
            }

            $response = wp_remote_retrieve_body($request);
            $response = json_decode($response, true);
            if ($response['success'] == true) {
                if ($response['status_check'] == 'active') {
                    update_option($wcam_lib->data_key . '_activated', 'Activated');
                } else {
                    update_option($wcam_lib->data_key . '_activated', 'Deactivated');
                }
            }
        }
        // Closing of validation code.
    }
}

add_action('tgmpa_register', 'rmsZI_register_required_plugins');
/**
 * Register the required plugins for this plugin.
 *
 */
function rmsZI_register_required_plugins()
{
    if ( $zi_plugin_prod_id == 26532 ) {
        return;
    }
    /*
     * Array of plugin arrays. Required keys are name and slug.
     * If the source is NOT from the .org repo, then source is also required.
     */
    if ( $zi_plugin_prod_id == 20832 ) {
    $plugins = array(
        array(
            'name' => 'B2B for WooCommerce', // The plugin name.
            'slug' => 'b2b-for-woocommerce', // The plugin slug (typically the folder name).
            'required' => false, // If false, the plugin is only 'recommended' instead of required.
            'external_url' => 'https://woocommerce.com/products/b2b-for-woocommerce/', // If set, overrides default API URL and points to an external URL.
            'source' => 'https://woocommerce.com/products/b2b-for-woocommerce/',
        ),
        array(
            'name' => 'Product Bundles for WooCommerce',
            'slug' => 'product-bundles',
            'required' => false, // If false, the plugin is only 'recommended' instead of required.
            'external_url' => 'https://woocommerce.com/products/product-bundles/',
            'source' => 'https://woocommerce.com/products/product-bundles/',
        ),

        array(
            'name' => 'Custom Fields Sync of Zoho Products',
            'slug' => 'woocommerce-zoho-inventory-custom-fields',
            'required' => false, // If false, the plugin is only 'recommended' instead of required.
            'external_url' => 'https://roadmapstudios.com/product/woocommerce-zoho-inventory-custom-fields/',
            'source' => 'https://roadmapstudios.com/product/woocommerce-zoho-inventory-custom-fields/',
        ),

        // This is an example of how to include a plugin from the WordPress Plugin Repository.
        array(
            'name' => 'Custom Order Statuses for WooCommerce',
            'slug' => 'custom-order-statuses-woocommerce',
            'required' => true,
        ),

    ); 
    } else {
        $plugins = array(
            array(
                'name' => 'Custom Order Statuses for WooCommerce',
                'slug' => 'custom-order-statuses-woocommerce',
                'required' => true,
            ),
    
        ); 
    }

    $config = array(
        'id' => 'rmsZI', // Unique ID for hashing notices for multiple instances of TGMPA.
        'default_path' => '', // Default absolute path to bundled plugins.
        'menu' => 'tgmpa-install-plugins', // Menu slug.
        'parent_slug' => 'plugins.php', // Parent menu slug.
        'capability' => 'manage_options', // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
        'has_notices' => true, // Show admin notices or not.
        'dismissable' => true, // If false, a user cannot dismiss the nag message.
        'dismiss_msg' => '', // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => false, // Automatically activate plugins after installation or not.
        'strings'      => array(
            'page_title'                      => __( 'Install Recommended Plugins', 'theme-slug' ),
            'notice_can_install_recommended'  => _n_noop(
                /* translators: 1: plugin name(s). */
                'The Zoho Inventory plugin recommends the following plugin: %1$s.',
                'The Zoho Inventory plugin recommends the following plugins: %1$s.',
                'tgmpa'
            ), )
    );

    tgmpa($plugins, $config);

}

// Activate plugin.
register_activation_hook(__FILE__, array('rmsZI\WooCommerceCheckout', 'activate'));

// Init hooks.
\rmsZI\WooCommerceCheckout::initHooks();

/**
 * Scheduling multiple interval.
 */
if (!function_exists('rms_cron_schedules')) {
    function rms_cron_schedules($schedules)
    {
        if (!isset($schedules['1min'])) {
            $schedules['1min'] = array(
                'interval' => 60,
                'display' => __('Once every 1 minutes'),
            );
        }
        if (!isset($schedules['10min'])) {
            $schedules['10min'] = array(
                'interval' => 10 * 60,
                'display' => __('Once every 10 minutes'),
            );
        }
        if (!isset($schedules['1hour'])) {
            $schedules['1hour'] = array(
                'interval' => 60 * 60,
                'display' => __('Once every hour'),
            );
        }
        if (!isset($schedules['1day'])) {
            $schedules['1day'] = array(
                'interval' => 24 * 60 * 60,
                'display' => __('Once every day'),
            );
        }
        return $schedules;
    }
}

add_filter('cron_schedules', 'rms_cron_schedules');

/**
 * Create table if it is not available in plugin
 */
// if (!function_exists('zi_create_order_log_table')) {

//     function zi_create_order_log_table()
//     {
//         global $wpdb;
//         $charset_collate = $wpdb->get_charset_collate();
//         $zi_order_log_table = "{$wpdb->prefix}zoho_ordersale_error";
//         $zi_create_sql = "CREATE TABLE $zi_order_log_table ( ID bigint(20) PRIMARY KEY auto_increment, user_id bigint(20) NOT NULL, order_id bigint(20) NOT NULL, error_message TEXT NOT NULL, order_timestamp VARCHAR(20) NOT NULL, status int(10) NOT NULL )$charset_collate;";

//         require_once ABSPATH . 'wp-admin/includes/upgrade.php';
//         dbDelta($zi_create_sql);
//     }
// }
// register_activation_hook(__FILE__, 'zi_create_order_log_table');

register_uninstall_hook(__FILE__, 'rms_cron_unsubscribe');
/**
 * Unsunscribing cron at uninstall of hook.
 */
if (!function_exists('rms_cron_unsubscribe')) {
    function rms_cron_unsubscribe()
    {
        // wp_clear_scheduled_hook( 'rms_cron_schedule_hook' );
        $post_meta_keys = [
            'zi_item_id',
            'zi_purchase_account_id',
            'zi_account_id',
            'zi_account_name',
            'zi_inventory_account_id',
            'zi_salesorder_id',
            'zi_category_id',
        ];
        $user_meta_keys = [
            'zi_contact_id',
            'zi_primary_contact_id',
            'zi_created_time',
            'zi_last_modified_time',
            'zi_billing_address_id',
            'zi_shipping_address_id',
            'zi_contact_persons_id',
            'zi_currency_id',
            'zi_currency_code',
        ];
        $zi_option_keys = [
            'zi_cron_isactive',
            'zoho_inventory_cron_class',
            'zoho_sync_status',
            'zoho_item_category',
            'zoho_stock_sync_status',
            'zoho_item_name_sync_status',
            'zoho_enable_auto_no_status',
            'zoho_enable_details_sync_status',
            'zoho_disable_itemimage_sync_status',
            'zoho_enable_order_status',
            'wootozoho_custom_fields',
            'zoho_pricelist_id',
            'zoho_warehouse_id',
            'zoho_inventory_auth_code',
            'zoho_inventory_access_token',
            'zoho_inventory_refresh_token',
            'zoho_inventory_timestamp',
            'zoho_enable_attributes_sync_status',
            'rms_ck',
            'rms_cs',
        ];

        foreach ($zi_option_keys as $zi_option) {
            delete_option($zi_option);
        }

        foreach ($post_meta_keys as $post_key) {
            delete_post_meta_by_key($post_key);
        }

        $users = get_users();
        foreach ($users as $user) {
            foreach ($user_meta_keys as $user_key) {
                delete_user_meta($user->ID, $user_key);
            }
        }

        // deleting mapped categories
        global $wpdb;
        $table_name = $wpdb->prefix . 'options';
        $sql = $wpdb->get_results('SELECT * FROM ' . $table_name . ' WHERE option_name LIKE "%zoho_id_for_term_id_%"');
        foreach ($sql as $key => $row) {
            $option_name = $row->option_name;
            delete_option($option_name);
        }

    }
}
